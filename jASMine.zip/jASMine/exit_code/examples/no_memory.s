include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local h_heap:DWORD, buf_sz:DWORD
    mov [buf_sz], 1000000000
    invoke GetProcessHeap
    mov [h_heap], eax
    invoke HeapAlloc, [h_heap], 0, [buf_sz]
   ;invoke HeapAlloc, [h_heap], HEAP_GENERATE_EXCEPTIONS, [buf_sz]
    mov ebx, eax
    test eax, eax
    jnz .add_numbers
    cinvoke puts, err_HeapAlloc
    jmp .finish
.add_numbers:
    cinvoke puts, 'success'
.finish:
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local h_heap:DWORD
    invoke GetProcessHeap
    mov [h_heap], eax
    invoke HeapAlloc, [h_heap], 0, 100000
    invoke HeapAlloc, [h_heap], HEAP_GENERATE_EXCEPTIONS, eax
    
   ;invoke HeapReAlloc, [h_heap], 0, ebx, eax
    invoke HeapReAlloc, [h_heap], HEAP_GENERATE_EXCEPTIONS, ebx, eax
    ret
endp

proc resizable_dword_array uses ebx, init_sz, new_sz
    local h_heap:DWORD
    invoke GetProcessHeap
    mov [h_heap], eax
    mov eax, [init_sz]
    shl eax, 2
    invoke HeapAlloc, [h_heap], 0, eax
    invoke HeapAlloc, [h_heap], HEAP_GENERATE_EXCEPTIONS, eax
    mov ebx, eax
    test eax, eax
    jnz .add_numbers
    cinvoke puts, err_HeapAlloc
    jmp .finish
.add_numbers:
    cinvoke printf, fmt_x, ebx
    stdcall set_values, ebx, 0, [init_sz], 111, 222
    mov eax, [new_sz]
    shl eax, 2
   ;invoke HeapReAlloc, [h_heap], 0, ebx, eax
    invoke HeapReAlloc, [h_heap], HEAP_GENERATE_EXCEPTIONS, ebx, eax
    mov ebx, eax
    test eax, eax
    jnz .add_more_numbers
    cinvoke printf, err_HeapReAlloc
    jmp .finish
.add_more_numbers:
    cinvoke printf, fmt_x, ebx
    stdcall set_values, ebx, [init_sz], [new_sz], 333, 444
    stdcall print_elems, ebx, [init_sz], [new_sz]
    invoke HeapFree, [h_heap], 0, ebx
.finish:
    ret
endp

include 'boilerplate/footer_data.inc'
err_HeapAlloc       db 'err_HeapAlloc', 0
err_HeapReAlloc     db 'err_HeapReAlloc', 0

.idata
library kernel32,           'kernel32.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        GetProcessHeap,     'GetProcessHeap',\
        HeapAlloc,          'HeapAlloc',\
        HeapReAlloc,        'HeapReAlloc',\
        HeapFree,           'HeapFree',\
        ExitProcess,        'ExitProcess'
import  msvcrt,\
        printf,             'printf',\
        puts,               'puts'
