include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    hlt
    print_s 'done'
    ret
endp

include 'compiler/footer.inc'
