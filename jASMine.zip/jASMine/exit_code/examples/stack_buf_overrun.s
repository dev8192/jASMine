include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, esp
    invoke memset, buf1, 97, 3      ; -1073740791
    invoke puts, str1               ; -1073741819
   ;invoke printf, fmt_2d, 5, 10    ; -1073741819
    cinvoke printf, fmt_x, esp
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, esp
    sub esp, 12
    cinvoke printf, fmt_x, esp
    add esp, 12
    ret
endp

include 'boilerplate/footer_data.inc'
buf1        rb 8
str1        db 'hello', 0

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        memset,         'memset',\
        printf,         'printf',\
        puts,           'puts'
