include 'boilerplate/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    int3
    cinvoke puts, 'done'
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    int 3
    cinvoke puts, 'done'
    ret
endp

include 'boilerplate/footer.inc'
