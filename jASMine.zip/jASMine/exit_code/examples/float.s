format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_binary.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    local fpu_cw:WORD
    fstcw [fpu_cw]
    stdcall print_binary16, [fpu_cw]
    and [fpu_cw], 0xFFFE
    stdcall print_binary16, [fpu_cw]
    ret
endp

macro unmask_im_bit {
    fstcw [fpu_cw]
    and [fpu_cw], 0xFFFE
    fldcw [fpu_cw]
}

macro unmask_zm_bit {
    fstcw [fpu_cw]
    and [fpu_cw], 0xFFFB
    fldcw [fpu_cw]
}

macro unmask_dm_bit {
    fstcw [fpu_cw]
    and [fpu_cw], 0xFFFD
    fldcw [fpu_cw]
}

proc main2
    cinvoke puts, '*** main2 ***'
    locals
       ;num1        dq 25.0
        num1        dq -1.0
    endl
    local result:QWORD, fpu_cw:WORD
    finit
   ;unmask_im_bit
    fld [num1]
    fsqrt
    fstp [result]
    cinvoke printf, fmt_f, dword [result], dword [result+4]
    xor eax, eax
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    locals
        num1        dq 0.0
        num2        dq 1.0
       ;num2        dq 0.0
    endl
    local result:QWORD, fpu_cw:WORD
    finit
    unmask_im_bit
    fld [num1]
    fdiv [num2]
    fstp [result]
    cinvoke printf, fmt_f, dword [result], dword [result+4]
    xor eax, eax
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    locals
        num1        dq 7.5
       ;num2        dq 0.5
        num2        dq 0.0
    endl
    local result:QWORD, fpu_cw:WORD
    finit
    unmask_zm_bit
    fld [num1]
    fdiv [num2]
    fstp [result]
    cinvoke printf, fmt_f, dword [result], dword [result+4]
    xor eax, eax
    ret
endp

proc main
    cinvoke puts, '*** main5 ***'
    locals
       ;num1        dq 0.5
        num1        dq 0x0000000000000001
    endl
    local result:QWORD, fpu_cw:WORD
    finit
   ;unmask_dm_bit
    fld [num1]
    fld1
    faddp st1, st0
    fstp [result]
    cinvoke printf, fmt_f, dword [result], dword [result+4]
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
