include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local io_status:DWORD
    mov eax, [fs:0x30]
    mov eax, [eax + 0x10]
    mov eax, [eax + 0x1C]
   ;invoke NtWriteFile, eax, 0, 0, 0, addr io_status, str1, str1_len, 0, 0
    invoke NtWriteFile, eax, 0, 0, 0, 0, str1, str1_len, 0, 0
    print_d eax
    ret
endp

include 'compiler/footer_data.inc'
str1        db 'abc123', 13, 10
str1_len    = $ - str1

.idata
library kernel32,       'kernel32.dll',\
        ntdll,          'ntdll.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        Sleep,          'Sleep',\
        ExitProcess,    'ExitProcess'
import  ntdll,\
        NtWriteFile,    'NtWriteFile'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
