include 'boilerplate/header.x86.inc'
include 'util/print_vector.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    movaps xmm0, xword [vec2]
    movaps xword [vec0], xmm0
    stdcall print_4floats, vec0
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    movapd xmm0, xword [vec3]
    movapd xword [vec0], xmm0
    stdcall print_2doubles, vec0
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    movdqa xmm0, [vec1]
    movdqa [vec0], xmm0
    stdcall print_4dwords, vec0
    ret
endp

.data
include 'util/print_vector.data.inc'
vec0            rb 16
align_breaker   db 0
align 16
vec1            dd 101, 102, 103, 104
vec2            dd 201.2, 202.2, 203.2, 204.2
vec3            dq 301.3, 302.3

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        vprintf,        'vprintf',\
        _scprintf,      '_scprintf',\
        vsprintf,       'vsprintf',\
        printf,         'printf',\
        puts,           'puts'
