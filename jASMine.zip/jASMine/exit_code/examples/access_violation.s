include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    mov eax, [0]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    mov [num1], 0xBB
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    std
    ret
endp

section '.data' data readable
num1    dd 0xAA

include 'compiler/footer.inc'
