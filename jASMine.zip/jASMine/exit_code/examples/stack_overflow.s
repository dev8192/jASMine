format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_dn          db '%d', 10, 0
    fmt_xn          db '%x', 10, 0
    fmt_esp         db 'esp: %x', 10, 0
    fmt_func        db '%d: 0x%x - 0x%x = %d', 10, 0
    fmt_done        db 'done', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    local low_limit:DWORD
    local high_limit:DWORD
    invoke GetCurrentThreadStackLimits, addr low_limit, addr high_limit
    cinvoke printf, fmt_xn, [low_limit]
    cinvoke printf, fmt_xn, esp
    cinvoke printf, fmt_xn, [high_limit]
    ret
endp

proc main11
    cinvoke puts, '*** main11 ***'
    local stack_size:DWORD
    mov [stack_size], 4096 * 50
   ;invoke SetThreadStackGuarantee, addr stack_size
    stdcall .func, 0, esp, 10091 ; ok
   ;stdcall .func, 0, esp, 10092 ; stack overflow
    cinvoke printf, fmt_done
    ret
endp

proc .func, counter, initial_esp, upper_bound
    local current_esp:DWORD
    inc [counter]
    mov [current_esp], esp
    mov eax, [initial_esp]
    sub eax, [current_esp]
    cinvoke printf, fmt_func, [counter], [initial_esp], [current_esp], eax
    mov eax, [upper_bound]
    cmp [counter], eax
    jae .exit
    stdcall .func, [counter], [initial_esp], [upper_bound]
.exit:
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall .func, esp
    cinvoke printf, fmt_done
    ret
endp

proc .func, initial_esp
   ;local buf1[16224]:BYTE ; ok
    local buf1[16225]:BYTE ; access violation
    local current_esp:DWORD
    mov [current_esp], esp
    mov eax, [initial_esp]
    sub eax, [current_esp]
    cinvoke printf, fmt_func, 0, [initial_esp], [current_esp], eax
    ret
endp

proc main3 uses ebx
    cinvoke puts, '*** main3 ***'
   ;mov ebx, 16240 ; ok
    mov ebx, 16241 ; access violation
    sub esp, ebx
    mov [esp], eax
    cinvoke printf, fmt_done
    add esp, ebx
    ret
endp

proc main
    push ebp
    mov ebp, esp
    cinvoke puts, '*** main4 ***'
.loop:
    sub esp, 4
    mov [esp], eax
    cinvoke printf, fmt_esp, esp
    jmp .loop
    cinvoke printf, fmt_done
    mov esp, ebp
    pop ebp
    ret
endp

proc main41
    cinvoke puts, '*** main41 ***'
    local low_limit:DWORD
    local high_limit:DWORD
    invoke GetCurrentThreadStackLimits, addr low_limit, addr high_limit
    mov eax, 0xa4d58
    sub eax, [low_limit]
    cinvoke printf, fmt_dn, eax
    ret
endp

section '.idata' import data readable
    library kernel32,                       'kernel32.dll',\
            msvcrt,                         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,                    'ExitProcess',\
            GetCurrentThreadStackLimits,    'GetCurrentThreadStackLimits',\
            SetThreadStackGuarantee,        'SetThreadStackGuarantee'
    import  msvcrt,\
            printf,                         'printf',\
            puts,                           'puts'
