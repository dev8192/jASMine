include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    local low_limit:DWORD
    local high_limit:DWORD
    local old_esp:DWORD
    invoke GetCurrentThreadStackLimits, addr low_limit, addr high_limit
    print_x [low_limit]
    print_x esp
    print_x [high_limit]
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    local low_limit:DWORD
    local high_limit:DWORD
    local old_esp:DWORD
    invoke GetCurrentThreadStackLimits, addr low_limit, addr high_limit
    mov [old_esp], esp
    mov eax, [high_limit]
   ;sub eax, 4
    mov esp, eax
    mov dword [esp], 123
    mov esp, [old_esp]
    print_s 'done'
    ret
endp

include 'compiler/footer_data.inc'

.idata
library kernel32,                       'kernel32.dll',\
        msvcrt,                         'msvcrt.dll'
import  kernel32,\
        ExitProcess,                    'ExitProcess',\
        GetCurrentThreadStackLimits,    'GetCurrentThreadStackLimits'
import  msvcrt,\
        printf,                         'printf',\
        puts,                           'puts'
