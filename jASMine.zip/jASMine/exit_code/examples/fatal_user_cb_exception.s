format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    wc                  WNDCLASS
    msg                 MSG
    class_name          db 'ExampleWindow', 0
    window_title        db 'Example Window', 0

section '.text' code readable executable
start:
    invoke  GetModuleHandle, 0
    mov     [wc.hInstance], eax
    mov     [wc.lpfnWndProc], window_proc
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW + 1
    mov     [wc.lpszClassName], class_name
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, window_title,\
            WS_OVERLAPPEDWINDOW + WS_VISIBLE,\
            CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
            0, 0, [wc.hInstance], 0

.msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      .end_loop
    invoke  DispatchMessage, msg
    jmp     .msg_loop
.end_loop:
    invoke  ExitProcess, [msg.wParam]

proc window_proc hwnd, wmsg, wparam, lparam
    mov eax, [0]
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy
    invoke  DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            ExitProcess,        'ExitProcess',\
            GetModuleHandle,    'GetModuleHandleA'
    import  user32,\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            DispatchMessage,    'DispatchMessageA',\
            GetMessage,         'GetMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage',\
            RegisterClass,      'RegisterClassA'
    import  msvcrt,\
            printf,             'printf'
