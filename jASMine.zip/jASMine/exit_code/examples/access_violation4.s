include 'compiler/header.x86.inc'

proc main uses ebx esi edi
    cinvoke puts, '*** main1 ***'
    invoke GetProcessHeap
    mov ebx, eax
    invoke HeapAlloc, ebx, 0, 16
    mov esi, eax
    lea edi, [eax + 16]
    mov ecx, 16
    xor eax, eax
    rep stosb
    cinvoke puts, 'msg1'
    invoke HeapFree, ebx, 0, esi
    cinvoke puts, 'msg2'
    ret
endp

; no error
proc main2 uses ebx esi
    cinvoke puts, '*** main2 ***'
    invoke GetProcessHeap
    mov ebx, eax
    invoke HeapAlloc, ebx, 0, 16
    mov esi, eax
    cinvoke puts, 'msg1'
    invoke HeapFree, ebx, 0, esi
    cinvoke puts, 'msg2'
    invoke HeapFree, ebx, 0, esi
    cinvoke puts, 'msg3'
    ret
endp

include 'compiler/footer_data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        GetProcessHeap, 'GetProcessHeap',\
        HeapAlloc,      'HeapAlloc',\
        HeapFree,       'HeapFree',\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
