include 'boilerplate/header.x64.inc'
include 'kernel32/winnt.inc'

proc main
    cinvoke puts, '*** main5 ***'
    local tp_env:TP_CALLBACK_ENVIRON
    local tp_work:QWORD
    cinvoke memset, addr tp_env, 0, sizeof.TP_CALLBACK_ENVIRON
   ;mov [tp_env.Version], 3
    invoke CreateThreadpool, 0
    mov [tp_env.Pool], rax
    test rax, rax
    jnz .set_threadpool_thread_maximum
    cinvoke printf, err_CreateThreadpool
    jmp .exit
.set_threadpool_thread_maximum:
    invoke SetThreadpoolThreadMaximum, [tp_env.Pool], -1
    invoke SetThreadpoolThreadMinimum, [tp_env.Pool], -1
    test eax, eax
    jnz .create_threadpool_work
    cinvoke printf, err_SetThreadpoolThreadMinimum
    invoke CloseThreadpool, [tp_env.Pool]
    jmp .exit
.create_threadpool_work:
    invoke CreateThreadpoolWork, thread_callback, 0, addr tp_env
    mov [tp_work], rax
    test rax, rax
    jnz .submit_threadpool_work
    cinvoke printf, err_CreateThreadpoolWork
    invoke CloseThreadpool, [tp_env.Pool]
    jmp .exit
.submit_threadpool_work:
    invoke SubmitThreadpoolWork, [tp_work]
    invoke WaitForThreadpoolWorkCallbacks, [tp_work], 0
    mov [tp_env.Version], 0
    invoke CloseThreadpoolWork, [tp_work]
    invoke CloseThreadpool, [tp_env.Pool]
    cinvoke printf, msg_done
.exit:
    ret
endp

proc thread_callback instance, context, work
    cinvoke printf, msg_callback
    ret
endp

.data
msg_done                        db 'done', 10, 0
msg_callback                    db 'callback', 10, 0
err_CreateThreadpool            db 'err_CreateThreadpool', 10, 0
err_SetThreadpoolThreadMinimum  db 'err_SetThreadpoolThreadMinimum', 10, 0
err_CreateThreadpoolWork        db 'err_CreateThreadpoolWork', 10, 0

.idata
library kernel32,                       'kernel32.dll',\
        msvcrt,                         'msvcrt.dll'
import  kernel32,\
        CreateThreadpool,               'CreateThreadpool',\
        CloseThreadpool,                'CloseThreadpool',\
        SetThreadpoolThreadMaximum,     'SetThreadpoolThreadMaximum',\
        SetThreadpoolThreadMinimum,     'SetThreadpoolThreadMinimum',\
        CreateThreadpoolWork,           'CreateThreadpoolWork',\
        CloseThreadpoolWork,            'CloseThreadpoolWork',\
        SubmitThreadpoolWork,           'SubmitThreadpoolWork',\
        WaitForThreadpoolWorkCallbacks, 'WaitForThreadpoolWorkCallbacks',\
        ExitProcess,                    'ExitProcess'
import  msvcrt,\
        memset,                         'memset',\
        printf,                         'printf',\
        puts,                           'puts'
