include 'compiler/header.x86.inc'

proc func.name
    jmp func.name.print.msg2
.print.msg1:
    cinvoke puts, 'msg1'
    jmp .exit
.print.msg2:
    cinvoke puts, 'msg2'
.exit:
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall func.name
    stdcall func.name.print.msg1
    ret
endp

include 'compiler/footer.inc'
