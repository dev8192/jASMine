include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall control_flow__test, control_flow1, '*** control_flow1 ***'
    stdcall control_flow__test, control_flow2, '*** control_flow2 ***'
    stdcall control_flow__test, control_flow3, '*** control_flow3 ***'
    ret
endp

proc control_flow__test, func, name
    cinvoke puts, [name]
    stdcall [func], 0, 0, 0
    stdcall [func], 1, 0, 0
    stdcall [func], 1, 1, 0
    stdcall [func], 1, 1, 1
    ret
endp

proc dummy_func result
    mov eax, [result]
    ret
endp

proc control_flow1 step1, step2, step3
.do_step1:
    stdcall dummy_func, [step1]
    test eax, eax
    jnz .do_step2
    cinvoke puts, 'Error: Step 1'
    jmp .exit
.do_step2:
    stdcall dummy_func, [step2]
    test eax, eax
    jnz .do_step3
    cinvoke puts, 'Error: Step 2'
    jmp .exit
.do_step3:
    stdcall dummy_func, [step3]
    test eax, eax
    jnz .print_result
    cinvoke puts, 'Error: Step 3'
    jmp .exit
.print_result:
    cinvoke puts, 'success'
.exit:
    ret
endp

proc control_flow2 step1, step2, step3
    stdcall dummy_func, [step1]
    test eax, eax
    jnz @f
    cinvoke puts, 'Error: Step 1'
    jmp .exit
@@:
    stdcall dummy_func, [step2]
    test eax, eax
    jnz @f
    cinvoke puts, 'Error: Step 2'
    jmp .exit
@@:
    stdcall dummy_func, [step3]
    test eax, eax
    jnz @f
    cinvoke puts, 'Error: Step 3'
    jmp .exit
@@:
    cinvoke puts, 'success'
.exit:
    ret
endp

proc control_flow3 step1, step2, step3
    stdcall dummy_func, [step1]
    test eax, eax
    jz .err_step1
    stdcall dummy_func, [step2]
    test eax, eax
    jz .err_step3
    stdcall dummy_func, [step3]
    test eax, eax
    jz .err_step3
    cinvoke puts, 'success'
    jmp .exit
.err_step1:
    cinvoke puts, 'Error: Step 1'
    jmp .exit
.err_step2:
    cinvoke puts, 'Error: Step 2'
    jmp .exit
.err_step3:
    cinvoke puts, 'Error: Step 3'
.exit:
    ret
endp

include 'compiler/footer.inc'
