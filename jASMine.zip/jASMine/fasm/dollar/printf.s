format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    msg1       db "aaa", 0
    msg1_len = $ - msg1 - 1

    msg2       db "bbbb", 0
    msg2_len = $ - msg2 - 1

    msg3       db "ccccc", 0
    msg3_len = $ - msg3 - 1

    fmt     db "%s: %d", 10, 0

section '.code' code readable executable
start:
    cinvoke printf, fmt, msg1, msg1_len
    cinvoke printf, fmt, msg2, msg2_len
    cinvoke printf, fmt, msg3, msg3_len

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
           exit, 'exit',\
           printf, 'printf'
