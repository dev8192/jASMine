format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num1        db 255
                rb 7
    num2        dw 65535
                rb 6
    num3        dd 4294967295
                rb 4
    num4        dq 18446744073709551615

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall print_bytes, num1, 8
    stdcall print_bytes, num2, 8
    stdcall print_bytes, num3, 8
    stdcall print_bytes, num4, 8
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    locals
        num1        db 255
                    rb 7
        num2        dw 65535
                    rb 6
        num3        dd 4294967295
                    rb 4
        num4        dq 18446744073709551615
    endl
    stdcall print_bytes, addr num1, 8
    stdcall print_bytes, addr num2, 8
    stdcall print_bytes, addr num3, 8
    stdcall print_bytes, addr num4, 8
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
