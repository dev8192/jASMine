
macro main {
    display '*** main1 ***', 10
    four equ 'hello world'
    irp item, 'one', 'two' # ' three', four \{
        display item, 10
    \}
    display 'done'
}

main
