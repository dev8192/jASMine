include 'boilerplate/header.x86.inc'
include 'util/introspection.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall wrapper1, [printf]
    stdcall wrapper2, printf
    ret
endp

proc wrapper1 func
    ccall [func], fmt_x, 255
    ret
endp

proc wrapper2 func
    mov eax, [func]
    mov eax, [eax]
    mov [func], eax
    cinvoke func, fmt_x, 255
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, printf
    cinvoke printf, fmt_x, [printf]
    mov eax, [printf]
    cinvoke printf, fmt_x, eax
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    jmp .intro_end
.intro1:
    mov eax, printf
.intro2:
    mov eax, 0x403084
.intro_end:
    stdcall introspect, .intro1, .intro2
    stdcall introspect, .intro2, .intro_end
    ret
endp

; call      stdcall     invoke
; call      ccall       cinvoke
proc main4
    cinvoke puts, '*** main4 ***'
    cinvoke printf, fmt_d, 123
    mov eax, [printf]
    ccall eax, fmt_d, 123
    ret
endp

include 'boilerplate/footer.inc'
