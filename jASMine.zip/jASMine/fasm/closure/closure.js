
function add(a, b) {
    return a + b
}
function subtract(a, b) {
    return a - b
}

const add_and_print = compute_and_print(add)
const subtract_and_print = compute_and_print(subtract)
function compute_and_print(func) {
    return function(a, b) {
        const result = func(a, b)
        console.log(result)
    }
}

add_and_print(5, 3)
subtract_and_print(5, 3)

// function compute_and_print1(a, b) {
//     const result = add(a, b)
//     console.log(result)
// }
// function compute_and_print2(a, b) {
//     const result = subtract(a, b)
//     console.log(result)
// }
