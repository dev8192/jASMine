format PE console
entry start

include 'win32ax.inc'

macro compute_and_print wrapper_func, orig_func {
    proc wrapper_func num1, num2
        stdcall orig_func, [num1], [num2]
        cinvoke printf, fmt_d, eax
        ret
    endp
}

compute_and_print add_and_print, add_func
compute_and_print sub_and_print, sub_func

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc add_func num1, num2
    mov eax, [num1]
    add eax, [num2]
    ret
endp

proc sub_func num1, num2
    mov eax, [num1]
    sub eax, [num2]
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall add_func, 5, 3
    cinvoke printf, fmt_d, eax
    stdcall sub_func, 5, 3
    cinvoke printf, fmt_d, eax
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall add_and_print, 5, 3
    stdcall sub_and_print, 5, 3
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
