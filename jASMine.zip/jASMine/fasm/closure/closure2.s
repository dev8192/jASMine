format PE
entry start

include 'win32ax.inc'

macro define_alias alias_name, func {
    macro alias_name num1, num2 \{
        stdcall compute_and_print, func, num1, num2
    \}
}

define_alias add_and_print, add_func
define_alias sub_and_print, sub_func

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc add_func num1, num2
    mov eax, [num1]
    add eax, [num2]
    ret
endp

proc sub_func num1, num2
    mov eax, [num1]
    sub eax, [num2]
    ret
endp

proc compute_and_print func, num1, num2
    stdcall [func], [num1], [num2]
    cinvoke printf, fmt_d, eax
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall compute_and_print, add_func, 5, 3
    stdcall compute_and_print, sub_func, 5, 3
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    add_and_print 5, 3
    sub_and_print 5, 3
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
