format PE
entry start

include 'win32ax.inc'

section '.data' data readable writable
    fmt_llx     db '%llx', 10, 0
    fmt_llu     db '%llu', 10, 0
    fmt_lld     db '%lld', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    locals
        num1 dq 0x11223344_55667788
        num2 dd 0x55667788, 0x11223344
        num3 dw 0x7788, 0x5566, 0x3344, 0x1122
        num4 db 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11
    endl
    cinvoke printf, fmt_llx, double [num1]
    cinvoke printf, fmt_llx, double [num2]
    cinvoke printf, fmt_llx, double [num3]
    cinvoke printf, fmt_llx, double [num4]
    stdcall print_bytes, addr num1, 8
    stdcall print_bytes, addr num2, 8
    stdcall print_bytes, addr num3, 8
    stdcall print_bytes, addr num4, 8
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    locals
        num1 dq 18446744073709551615
    endl
    cinvoke printf, fmt_llx, double [num1]
    cinvoke printf, fmt_llu, double [num1]
    cinvoke printf, fmt_lld, double [num1]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
