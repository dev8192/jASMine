format PE
entry start

include 'win32ax.inc'

; (0 0) (0 1) (0 2)
; (1 0) (1 1) (1 2)
; (2 0) (2 1) (2 2)
; (3 0) (3 1) (3 2)

section '.data' data readable writeable
    fmt_cell    db '(%d %d) ', 0
    newline     db 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_grid, 3, 4
   ;stdcall print_grid, 1, 1
   ;stdcall print_grid, 0, 0
   ;stdcall print_grid, 10, 0
   ;stdcall print_grid, 0, 10
    ret
endp

proc print_grid1 uses esi edi, height, width
    mov eax, [width]
    test eax, eax
    jz .outer_loop_end
    xor esi, esi
.outer_loop:
    cmp esi, [height]
    jae .outer_loop_end
    xor edi, edi
.inner_loop:
    cmp edi, [width]
    jae .inner_loop_end
    cinvoke printf, fmt_cell, esi, edi
    inc edi
    jmp .inner_loop
.inner_loop_end:
    cinvoke printf, newline
    inc esi
    jmp .outer_loop
.outer_loop_end:
    ret
endp

proc print_grid uses esi edi, height, width
    mov esi, [height]
    test esi, esi
    jz .done
    mov edi, [width]
    test edi, edi
    jz .done
.outer_loop:
    mov edi, [width]
.inner_loop:
    mov eax, [height]
    sub eax, esi
    mov ecx, [width]
    sub ecx, edi
    cinvoke printf, fmt_cell, eax, ecx
    dec edi
    jnz .inner_loop
    cinvoke printf, newline
    dec esi
    jnz .outer_loop
.done:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
