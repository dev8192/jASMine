include 'compiler/header.x86.inc'
include 'loop1.inc'
include 'loop2.inc'
include 'loop3.inc'

proc main
   ;print_s '*** main1 ***'
    stdcall do_while_inc, 5
    stdcall do_while_inc, 0
    stdcall do_while_dec, 5
   ;stdcall do_while_dec, 0
    ret
endp

proc main2
   ;print_s '*** main2 ***'
    stdcall while_inc1, 5
    stdcall while_inc1, 0
    stdcall while_dec1, 5
    stdcall while_dec1, 0
    ret
endp

proc main3
   ;print_s '*** main3 ***'
    stdcall while_inc2, 5
    stdcall while_inc2, 0
    stdcall while_dec2, 5
    stdcall while_dec2, 0
    ret
endp

include 'compiler/footer.inc'
