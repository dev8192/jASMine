format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    jmp $
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
   ;stdcall GenerateCpuPattern, 5000, 1000
    stdcall GenerateCpuPattern, 5000, 5000
    ret
endp

proc GenerateCpuPattern uses ebx, workMs, restMs
.pattern_loop:
    invoke GetTickCount
    mov ebx, eax
    add ebx, [workMs]
.busy_work_loop:
    invoke GetTickCount
    cmp eax, ebx
    jb .busy_work_loop
    invoke Sleep, [restMs]
    jmp .pattern_loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetTickCount,   'GetTickCount',\
            Sleep,          'Sleep',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
