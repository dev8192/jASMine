; TAGS: little endian, size override
format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    buf1            db 0
    buf2            db 0
    buf3            db 0
    buf4            db 0
    fmt_4x          db '%02x %02x %02x %02x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_buffers
    movzx eax, [buf4]
    push eax
    movzx eax, [buf3]
    push eax
    movzx eax, [buf2]
    push eax
    movzx eax, [buf1]
    push eax
    push fmt_4x
    call [printf]
    add esp, 20
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'

    inc [buf1]
    stdcall print_buffers

    inc byte [buf1]
    stdcall print_buffers

    inc word [buf1]
    stdcall print_buffers

    inc dword [buf1]
    stdcall print_buffers

    ret
endp

proc main
    cinvoke puts, '*** main2 ***'

    dec [buf1]
    stdcall print_buffers
    inc [buf1]

    dec byte [buf1]
    stdcall print_buffers
    inc byte [buf1]

    dec word [buf1]
    stdcall print_buffers
    inc word [buf1]

    dec dword [buf1]
    stdcall print_buffers
    inc dword [buf1]

    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
