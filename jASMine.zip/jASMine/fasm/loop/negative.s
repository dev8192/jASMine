include 'boilerplate/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    mov ebx, -3
.loop:
    cinvoke printf, fmt_d, ebx
    inc ebx
    cmp ebx, 3
   ;jl .loop
    jb .loop
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    mov ebx, 3
.loop:
    cinvoke printf, fmt_d, ebx
    dec ebx
    cmp ebx, -3
   ;jg .loop
    ja .loop
    ret
endp

include 'boilerplate/footer.inc'
