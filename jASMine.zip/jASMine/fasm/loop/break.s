format PE
entry start

include 'win32a.inc'

DWORD_SIZE = 4

section '.data' data readable writeable
    fmt_d           db '%d', 10, 0
    arr1            dd 0, 0, 0, 1, 0
    arr1_len        = ($ - arr1) / DWORD_SIZE
    arr2            dd 0, 0, 0, 0, 0
    arr2_len        = ($ - arr2) / DWORD_SIZE

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    stdcall .index_of, arr1, arr1_len, '1'
    cinvoke printf, fmt_d, eax
    stdcall .index_of, arr2, arr2_len, '1'
    cinvoke printf, fmt_d, eax
    ret
endp
    
proc .index_of uses ebx esi, pArray, length, ch
    mov esi, [pArray]
    mov ecx, [length]
    mov ebx, [ch]
    test ecx, ecx
    je .not_found
    xor ecx, ecx
.loop:
    cmp [esi + DWORD_SIZE], ebx
    je .found
    add esi, DWORD_SIZE
    inc ecx
    cmp ecx, [length]
    jl .loop
.not_found:
    mov eax, -1
    ret
.found:
    mov eax, ecx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
