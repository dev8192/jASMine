format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_u       db '%u', 10, 0
    fmt_3x      db '%08x %08x %08x', 10, 0
    num_0       db 0x00, 0, -256
    num_1       db 0x01, 1, -255
    num_2       db 0x02, 2, -254
    num_126     db 0x7e, 126, -130
    num_127     db 0x7f, 127, -129
    num_128     db 0x80, 128, -128
    num_129     db 0x81, 129, -127
    num_254     db 0xfe, 254, -2
    num_255     db 0xff, 255, -1

include '../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall print_bytes, num_0, 3
    stdcall print_bytes, num_1, 3
    stdcall print_bytes, num_2, 3
    stdcall print_bytes, num_126, 3
    stdcall print_bytes, num_127, 3
    stdcall print_bytes, num_128, 3
    stdcall print_bytes, num_129, 3
    stdcall print_bytes, num_254, 3
    stdcall print_bytes, num_255, 3
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    locals
        num_0       db 0x00, 0, -256    ; ?
        num_1       db 0x01, 1, -255    ; ?
        num_2       db 0x02, 2, -254    ; ?
        num_126     db 0x7e, 126, -130  ; ?
        num_127     db 0x7f, 127, -129  ; ?
        num_128     db 0x80, 128, -128
        num_129     db 0x81, 129, -127
        num_254     db 0xfe, 254, -2
        num_255     db 0xff, 255, -1
    endl
    stdcall print_bytes, addr num_0, 3
    stdcall print_bytes, addr num_1, 3
    stdcall print_bytes, addr num_2, 3
    stdcall print_bytes, addr num_126, 3
    stdcall print_bytes, addr num_127, 3
    stdcall print_bytes, addr num_128, 3
    stdcall print_bytes, addr num_129, 3
    stdcall print_bytes, addr num_254, 3
    stdcall print_bytes, addr num_255, 3
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    cinvoke printf, fmt_3x, 0x00000000,          0, -4294967296 ; ?
    cinvoke printf, fmt_3x, 0x00000001,          1, -4294967295 ; ?
    cinvoke printf, fmt_3x, 0x00000002,          2, -4294967294 ; ?
    cinvoke printf, fmt_3x, 0x7FFFFFFE, 2147483646, -2147483650 ; ?
    cinvoke printf, fmt_3x, 0x7FFFFFFF, 2147483647, -2147483649 ; ?
    cinvoke printf, fmt_3x, 0x80000000, 2147483648, -2147483648
    cinvoke printf, fmt_3x, 0x80000001, 2147483649, -2147483647
    cinvoke printf, fmt_3x, 0xFFFFFFFE, 4294967294,          -2
    cinvoke printf, fmt_3x, 0xFFFFFFFF, 4294967295,          -1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
