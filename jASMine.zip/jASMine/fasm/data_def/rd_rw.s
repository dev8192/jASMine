format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%x', 10, 0
    fmt4    db '%x %x %x %x', 10, 0
    buf1    rb  16
    buf2    rw  8
    buf3    rd  4

section '.text' code readable executable
start:
    stdcall test20
    cinvoke printf, fmt, esp
    stdcall test30
    cinvoke printf, fmt, esp
    invoke ExitProcess, 0
    
proc test10
    lea eax, [buf1]
    cinvoke printf, fmt, eax
    lea eax, [buf1 + 1]
    cinvoke printf, fmt, eax
    lea eax, [buf1 + 2]
    cinvoke printf, fmt, eax

    lea eax, [buf2]
    cinvoke printf, fmt, eax
    lea eax, [buf2 + 1]
    cinvoke printf, fmt, eax
    lea eax, [buf2 + 2]
    cinvoke printf, fmt, eax

    lea eax, [buf3]
    cinvoke printf, fmt, eax
    lea eax, [buf3 + 1]
    cinvoke printf, fmt, eax
    lea eax, [buf3 + 2]
    cinvoke printf, fmt, eax

    ret
endp
    
proc test20
    mov [buf1], 0x12
    mov [buf1 + 1], 0x34
    mov [buf1 + 2], 0x56
    mov [buf1 + 3], 0x78

    mov [buf2], 0x12
    mov [buf2 + 2], 0x34
    mov [buf2 + 4], 0x56
    mov [buf2 + 6], 0x78

    mov [buf3], 0x12
    mov [buf3 + 4], 0x34
    mov [buf3 + 8], 0x56
    mov [buf3 + 12], 0x78

    ret
endp
    
proc test30
    movzx eax, [buf1 + 3]
    push eax
    movzx eax, [buf1 + 2]
    push eax
    movzx eax, [buf1 + 1]
    push eax
    movzx eax, [buf1]
    push eax
    push fmt4
    cinvoke printf
    add esp, 5 * 4

    movzx eax, [buf2 + 6]
    push eax
    movzx eax, [buf2 + 4]
    push eax
    movzx eax, [buf2 + 2]
    push eax
    movzx eax, [buf2]
    push eax
    push fmt4
    cinvoke printf
    add esp, 5 * 4

    cinvoke printf, fmt4, [buf3], [buf3 + 4], [buf3 + 8], [buf3 + 12]

    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
