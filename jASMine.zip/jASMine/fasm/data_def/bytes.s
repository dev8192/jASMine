format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num1      dq 0
    num2      dq -1
    num3      dq 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_bytes, num1, 24
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
