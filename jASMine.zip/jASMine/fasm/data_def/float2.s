format PE

include 'compiler_old.inc'
include 'win32ax.inc'

stdcall main
invoke ExitProcess, 0

include 'util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    locals
        float1      dd 15.75
        float2      dd ?
        float3      dd ?
    endl
    mov [float2], 15.75
    mov eax, 15.75
    mov [float3], eax
    stdcall print_bytes, addr float1, 4
    stdcall print_bytes, addr float2, 4
    stdcall print_bytes, addr float3, 4
    push 15.75
    mov eax, esp
    stdcall print_bytes, eax, 4
    add esp, 4
    ret
endp

.data
include 'util/format.data.inc'
include 'util/print_bytes.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
