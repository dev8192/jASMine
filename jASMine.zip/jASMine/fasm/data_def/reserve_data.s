format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buf_rb            rb 10
    buf_rb_sz         = $ - buf_rb
    buf_rb_sz_fmt     db 'rb: %d', 10, 0

    buf_rw            rw 10
    buf_rw_sz         = $ - buf_rw
    buf_rw_sz_fmt     db 'rw: %d', 10, 0

    buf_rd            rd 10
    buf_rd_sz         = $ - buf_rd
    buf_rd_sz_fmt     db 'rd: %d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0
    
proc test10
    cinvoke printf, buf_rb_sz_fmt, buf_rb_sz
    cinvoke printf, buf_rw_sz_fmt, buf_rw_sz
    cinvoke printf, buf_rd_sz_fmt, buf_rd_sz
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
