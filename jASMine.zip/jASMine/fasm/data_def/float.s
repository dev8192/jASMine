include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main1
    print_s '*** main1 ***'
    locals
        num1        dq 0.1
        num2        dq 0x3FB999999999999A
    endl
    print_f [num1]
    print_f [num2]
    print_llx [num1]
    print_llx [num2]
    stdcall print_bytes, addr num1, 8
    stdcall print_bytes, addr num2, 8
    ret
endp

proc main2
    print_s '*** main2 ***'
    locals
        float1      dd 15.75
        double1     dq 15.75
        double2     dq ?
    endl
    print_f [double1]
    movss xmm0, [float1]
    cvtss2sd xmm0, xmm0
    movsd [double2], xmm0
    print_f [double2]
    stdcall print_bytes, addr float1, 4
    stdcall print_bytes, addr double1, 8
    stdcall print_bytes, addr double2, 8
    ret
endp

proc main
    print_s '*** main3 ***'
    locals
        double1     dq 15.25
        double2     dq 15.5
    endl
    print_x esp
    stdcall print_float1, addr double1
    stdcall print_float2, double [double2]
    stdcall print_float2, double 15.75
    print_x esp
    ret
endp

proc print_float1, num
    mov eax, [num]
    print_f [eax]
    ret
endp

proc print_float2, num:QWORD
    print_f [num]
    ret
endp

include 'compiler/footer.inc'
