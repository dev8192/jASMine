format PE console 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ; arr dd 7 dup(?)

    ; Option 1: 28 initialized bytes (Value: 0)
    array_db   db 28 dup (0)

    ; Option 2: 7 initialized double-words (Value: 0)
    ; 7 * 4 bytes = 28 bytes total
    array_dd   dd 7 dup (0)

    ; Option 3: 28 reserved bytes (Uninitialized)
    ; This does not take up space in the .exe file on disk
    array_rb   rb 28

    fmt        db 'Array Type: %s | Total Size: %d bytes', 0ah, 0
    type1      db 'db 28 dup (0)', 0
    type2      db 'dd 7 dup (0)', 0
    type3      db 'rb 28', 0

section '.bss' readable writeable
    ; Option 4: The explicit BSS method
    ; This stays out of the file's raw data
    buffer_bss rb 28

section '.code' code readable executable
start:
    ; Show size of Option 1
    cinvoke printf, fmt, type1, 28

    ; Show size of Option 2
    cinvoke printf, fmt, type2, 7 * 4

    ; Show size of Option 3
    cinvoke printf, fmt, type3, 28

    ; Demonstration: Write a value to the reserved buffer
    mov byte [array_rb], 0xFF

    ; Show the address of the BSS array
    cinvoke printf, fmt, buffer_bss

    ; Prove it is writeable
    cinvoke printf, msg
    mov byte [buffer_bss], 0xFF
    
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf', \
           _getch, '_getch'
