format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    buf1        du 'abc123', 0
    buf1_sz     = $ - buf1
    buf2        dw 'a', 'b', 'c', '1', '2', '3', 0
    buf2_sz     = $ - buf2
    buf33        dw 'ab', 'c1', '23', 0
    buf33_sz     = $ - buf33
    
    fmt_x       db '%x', 10, 0
    fmt_d       db '%d', 10, 0
    fmt_ls      db '"%ls"', 10, 0
    fmt_s_wide  du '"%s"', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall print_bytes, buf1, buf1_sz
    stdcall print_bytes, buf2, buf2_sz
    stdcall print_bytes, buf33, buf33_sz
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_ls, buf1
    cinvoke printf, fmt_ls, buf2
    cinvoke wprintf, fmt_s_wide, buf1
    cinvoke wprintf, fmt_s_wide, buf2
    ret
endp

func1:
    cinvoke printf, fmt_d, buf1_sz
    cinvoke printf, fmt_d, buf2_sz
    ret

func2:
    movzx   eax, byte [buf1 + 0]
    cinvoke printf, fmt_x, eax
    movzx   eax, byte [buf1 + 1]
    cinvoke printf, fmt_x, eax
    movzx   eax, byte [buf1 + 2]
    cinvoke printf, fmt_x, eax
    movzx   eax, byte [buf1 + 3]
    cinvoke printf, fmt_x, eax
    ret

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            wprintf,        'wprintf',\
            puts,           'puts'
