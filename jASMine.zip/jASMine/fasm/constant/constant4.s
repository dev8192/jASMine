format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    month1      db 'january', 0
    fmt1        db 'fmt1: %s', 10, 0
    month2      db 'JANUARY', 0
    fmt2        db 'fmt2: %s', 10, 0
    print       = print1

section '.text' code readable executable
start:
    stdcall test1
    invoke ExitProcess, 0

proc print1
    cinvoke printf, fmt1, month1
    ret
endp

proc print2
    cinvoke printf, fmt2, month2
    ret
endp

proc test1
    stdcall print1
    stdcall print2
    stdcall print
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
