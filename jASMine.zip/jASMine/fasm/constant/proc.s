format PE
entry start

include 'win32ax.inc'

num11 equ 100
num12 equ 200
num13 equ 300

num21 = 100
num22 = 200
num23 = 300

section '.data' data readable writeable
    fmt_3d      db '%d %d %d', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt_3d, num11, num12, num13
    cinvoke printf, fmt_3d, num21, num22, num23
    stdcall main
    invoke ExitProcess, 0

num11 equ 111
num21 = 111

proc update_num2
num12 equ 222
num22 = 222
    ret
endp

proc update_num3
num13 equ 333
num23 = 333
    ret
endp

proc main
    stdcall update_num2
    cinvoke printf, fmt_3d, num11, num12, num13
    cinvoke printf, fmt_3d, num21, num22, num23
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
