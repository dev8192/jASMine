format PE
entry start

include 'win32a.inc'

section '.data' data readable
    fmt3 db '%d %d %d', 10, 0
    fmt4 db '%d %d %d %d', 10, 0

section '.text' code executable
start:
NUM1 = 111
NUM3 equ 333
    cinvoke printf, fmt3, NUM1, NUM2, NUM3
;    cinvoke printf, fmt4, NUM1, NUM2, NUM3, NUM4
NUM2 = 222
;NUM4 equ 444
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'
    import kernel32, ExitProcess, 'ExitProcess'
    import msvcrt,   printf, 'printf'
