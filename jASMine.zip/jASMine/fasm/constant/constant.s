include 'compiler/header.x86.inc'

proc main
   ;print_s '*** main1 ***'
    stdcall main1_1
    stdcall main1_2
    ret
endp

num0 = 0
num1 = 0x61
num2 = 0x6162
num3 = 0x616263
num4 = 0x61626364
num5 = 0x61626364_65
num6 = 0x61626364_6566
num7 = 0x61626364_656667
num8 = 0x61626364_65666768

proc main1_1
    print_s '*** main1_1 ***'
    print_x num0
    print_x num1
    print_x num2
    print_x num3
    print_x num4
    print_llx num5
    print_llx num6
    print_llx num7
    print_llx num8
    ret
endp

str0 = ''
str1 = 'a'
str2 = 'ab'
str3 = 'abc'
str4 = 'abcd'
str5 = 'abcde'
str6 = 'abcdef'
str7 = 'abcdefg'
str8 = 'abcdefgh'

proc main1_2
    print_s '*** main1_2 ***'
    print_x str0
    print_x str1
    print_x str2
    print_x str3
    print_x str4
    print_llx str5
    print_llx str6
    print_llx str7
    print_llx str8
    ret
endp

include 'compiler/footer.inc'
