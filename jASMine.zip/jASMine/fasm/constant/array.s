format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    pen_styles dd PS_SOLID, PS_DASH, PS_DOT, PS_DASHDOT, PS_DASHDOTDOT
    fmt     db '%x', 10, 0

section '.text' code readable executable
func1:
    cinvoke printf, fmt, PS_GEOMETRIC or PS_SOLID
    cinvoke printf, fmt, PS_GEOMETRIC or PS_DASH
    cinvoke printf, fmt, PS_GEOMETRIC or PS_DOT
    cinvoke printf, fmt, PS_GEOMETRIC or PS_DASHDOT
    cinvoke printf, fmt, PS_GEOMETRIC or PS_DASHDOTDOT
    ret

func2:
    xor esi, esi
@@:
    mov eax, PS_GEOMETRIC
    lea ebx, [pen_styles + esi * 4]
    or eax, [ebx]
    cinvoke printf, fmt, eax
    inc esi
    cmp esi, 5
    jl @b
    ret

start:
    call func1
    call func2
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
