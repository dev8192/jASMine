format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    main1_data:
    .fmt_xn         db '%x', 10, 0
    .fmt_Xn         db '%X', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'

    FMT_STR = main1_data.fmt_xn
    cinvoke printf, FMT_STR, 0xABC

    FMT_STR = main1_data.fmt_Xn
    cinvoke printf, FMT_STR, 0xABC

    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'

    UPPERCASE = 0
    if UPPERCASE = 1
        cinvoke printf, main1_data.fmt_Xn, 0xABC
    else
        cinvoke printf, main1_data.fmt_xn, 0xABC
    end if

    UPPERCASE = 1
    if UPPERCASE = 1
        cinvoke printf, main1_data.fmt_Xn, 0xABC
    else
        cinvoke printf, main1_data.fmt_xn, 0xABC
    end if

    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    UPPERCASE = 0
    stdcall print_num, 0xABC
    ret
endp

proc print_num, num
    if UPPERCASE = 1
        cinvoke printf, main1_data.fmt_Xn, [num]
    else
        cinvoke printf, main1_data.fmt_xn, [num]
    end if
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
