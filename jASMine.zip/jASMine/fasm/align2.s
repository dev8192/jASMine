include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    print_x num1
    print_x num2
    print_x num3
    ret
endp

include 'compiler/footer_data.inc'
align 16
num1 rb 1
align 16
num2 rb 1
align 16
align 16
num3 rb 1

include 'compiler/footer_idata.inc'
