include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
   ;stdcall main1_1
   ;stdcall main1_2
   ;stdcall main1_3
    stdcall main1_4
    ret
endp

proc main1_1
    mov eax, [sized3]
    mov ax, [sized2]
    mov al, [sized1]
    cinvoke printf, fmt_x, eax
    ret
endp

proc main1_2
    xor eax, eax
    mov al, [unsized1]
    cinvoke printf, fmt_x, eax
    xor eax, eax
    mov al, [unsized2]
    cinvoke printf, fmt_x, eax
    xor eax, eax
    mov al, [unsized3]
    cinvoke printf, fmt_x, eax
    ret
endp

proc main1_3
    xor eax, eax
    mov ax, [unsized1]
    cinvoke printf, fmt_x, eax
    xor eax, eax
    mov ax, [unsized2]
    cinvoke printf, fmt_x, eax
    xor eax, eax
    mov ax, [unsized3]
    cinvoke printf, fmt_x, eax
    ret
endp

proc main1_4
    mov eax, [unsized1]
    cinvoke printf, fmt_x, eax
    mov eax, [unsized2]
    cinvoke printf, fmt_x, eax
    mov eax, [unsized3]
    cinvoke printf, fmt_x, eax
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke puts, hello
    cinvoke puts, hello1
    cinvoke puts, hello2
    cinvoke puts, hello3
    ret
endp

include 'compiler/footer_data.inc'
sized1      db 0x11
sized2      dw 0x2222
sized3      dd 0x44444444
unsized1:   db 0x11
unsized2:   dw 0x2222
unsized3:   dd 0x44444444

hello1:
hello2 = $
hello db 'hello', 0
hello3 = hello

include 'compiler/footer_idata.inc'
