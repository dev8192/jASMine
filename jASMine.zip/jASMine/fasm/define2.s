
macro main1 {
    display '*** main1 ***', 10
    define msg1 97
    msg2 = 98
    msg3 equ 99

    display msg1, msg2, msg3
}

macro main {
    display '*** main1 ***', 10
    ;define msg1 'hello'
    if defined msg1
        display msg1
    else
        display 'default'
    end if
}

main
