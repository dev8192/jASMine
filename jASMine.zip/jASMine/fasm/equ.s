include 'boilerplate/header.x86.inc'

num equ hello
num = 333

proc main
    cinvoke puts, '*** main1 ***'
    print_d hello
    ret
endp

include 'boilerplate/footer.inc'
