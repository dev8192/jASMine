include 'compiler/header.x86.inc'

proc main1
    print_s '*** main1 ***'
    local num1:DWORD, num2:DWORD
    stdcall split_75_25, 100, addr num1, addr num2
    print_d [num1]
    print_d [num2]
    ret
endp

proc split_75_25 mem_size, num1, num2
    mov eax, [mem_size]
    mov edx, eax
    shr edx, 2
    mov ecx, eax
    sub ecx, edx
    mov eax, [num1]
    mov [eax], ecx
    mov eax, [num2]
    mov [eax], edx
    ret
endp

proc main2
    print_s '*** main2 ***'
    stdcall visualize_mem_alloc, 100, 500
    ret
endp

proc visualize_mem_alloc, mem_size, start_addr
    local memory_start:DWORD, memory_end:DWORD
    local additional_memory:DWORD, additional_memory_end:DWORD

    stdcall split_75_25, [mem_size], addr memory_end, addr additional_memory_end
    mov eax, [start_addr]
    mov [memory_start], eax
    add eax, [memory_end]
    mov [memory_end], eax
    mov [additional_memory], eax
    add [additional_memory_end], eax

    print_2d [memory_start], [memory_end]
    print_2d [additional_memory], [additional_memory_end]
    ret
endp

proc main
    print_s '*** main3 ***'
    print_d 0x4000
    print_d 0x10000
    stdcall retry_loop, 0x10000
    ret
endp

proc memory_allocator mem_size
    print_s0 'memory_allocator'
    print_colon_space
    print_d [mem_size]
    mov eax, 0
    ret
endp

proc retry_loop uses ebx, mem_size
    mov ebx, [mem_size]
.allocate_memory:
    stdcall memory_allocator, ebx
    or eax, eax
    jz .not_enough_memory
    print_s 'success'
    jmp .exit
.not_enough_memory:
    shr ebx, 1
    cmp ebx, 0x4000
    jae .allocate_memory
.exit:
    ret
endp

include 'compiler/footer.inc'
