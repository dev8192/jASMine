include 'compiler/header.x86.inc'
include 'dep1.inc'
include 'compiler/footer.inc'
