include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    print_x 0x12345678
    ret
endp

include 'compiler/footer.inc'
