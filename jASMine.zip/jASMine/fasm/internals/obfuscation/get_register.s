include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main
    print_s '*** main1 ***'
    stdcall test_runner, get_register1
    stdcall test_runner, get_register2
    ret
endp

;  0  1  2  3   4  5  6  7   8  9 10 11  12 13 14 15  16 17 18 19
; 33 33 33 33  33 33 33 33  33 33 33 33  33 33 33 33  33 33 33 33
; 00 00 00 00  00 00 00 00  44 00 01 33  00 00 33 33  00 00 00 00
proc test_runner uses esi edi, func
    local src[1]:BYTE, dst[20]:BYTE
    mov [src], 0x44
    cinvoke memset, addr dst, 0x33, 20
    lea edi, [dst]
    lea esi, [src]
    print_2x esi, edi
    stdcall [func], addr dst, addr src
    print_2x esi, edi
    stdcall print_bytes, addr dst, 20
    ret
endp

proc get_register1
    mov byte [edi+9], 0
    and word [edi+12], 0
    lods byte [esi]
    mov [edi+8], al
    mov byte [edi+10], 1
    xor eax, eax
    mov [edi+16], eax
    stos dword [edi]
    stos dword [edi]
    add edi, 0Ch
    ret
endp

proc get_register2
    cinvoke memset, edi, 0, 20
    lods byte [esi]
    mov [edi+8], al
    mov byte [edi+10], 1
    add edi, 20
    ret
endp

include 'compiler/footer_data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        memset,         'memset',\
        printf,         'printf',\
        puts,           'puts'
