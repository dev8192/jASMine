include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    stdcall recoverable_misuse, 0
   ;stdcall recoverable_misuse, 5
    ret
endp

proc recoverable_misuse error_line
    cmp [error_line], 0
    jne .ignore_misuse
    print_s 'invalid_use_of_symbol'
.ignore_misuse:
    ret
endp

include 'compiler/footer.inc'
