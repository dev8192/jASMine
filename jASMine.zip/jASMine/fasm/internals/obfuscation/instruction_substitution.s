include 'compiler/header.x86.inc'

proc main1 uses ebx esi edi
    print_s '*** main1 ***'
    local buf[27]:BYTE
    lea edi, [buf]
    mov esi, alphabet
    mov ebx, 13
.loop:
    mov ax, [esi]
    mov [edi], ax
    add esi, 2
    scasw
    dec ebx
    jnz .loop
    mov byte [edi], 0
    print_s addr buf
    ret
endp

proc main
    print_s '*** main2 ***'
    stdcall .func, main2_1
    stdcall .func, main2_2
    ret
endp

proc .func func
    stdcall [func], 2
    stdcall [func], 4
    stdcall [func], 8
    stdcall [func], 10
    print_newline
    ret
endp

proc recoverable_misuse
    print_s0 'recoverable_misuse'
    ret
endp

proc main2_1 value_size
    mov eax, [value_size]
    cmp al, 2
    je .convert_fp_word
    cmp al, 4
    je .convert_fp_dword
    test al, not 8
    jz .convert_fp_qword
    call recoverable_misuse
    jmp .exit
.convert_fp_qword:
    print_s0 'convert_fp_qword'
    jmp .exit
.convert_fp_word:
    print_s0 'convert_fp_word'
    jmp .exit
.convert_fp_dword:
    print_s0 'convert_fp_dword'
.exit:
    print_space
    ret
endp

proc main2_2 value_size
    mov eax, [value_size]
    cmp al, 2
    je .convert_fp_word
    cmp al, 4
    je .convert_fp_dword
    cmp al, 8
    je .convert_fp_qword
    call recoverable_misuse
    jmp .exit
.convert_fp_qword:
    print_s0 'convert_fp_qword'
    jmp .exit
.convert_fp_word:
    print_s0 'convert_fp_word'
    jmp .exit
.convert_fp_dword:
    print_s0 'convert_fp_dword'
.exit:
    print_space
    ret
endp

include 'compiler/footer_data.inc'
include 'util/alphabet.data.inc'
include 'compiler/footer_idata.inc'
