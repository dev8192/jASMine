include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    print_d 5 - 1
    print_d 5 -- 1
    print_d 5 --- 1
    ret
endp

include 'compiler/footer.inc'
