include 'compiler/header.x86.inc'

proc main1
   ;print_s '*** main1 ***'
   ;stdcall main1_1
    stdcall main1_2
    stdcall main1_3
    ret
endp

proc main1_1
    print_s '*** main1_1 ***'
   ;print_d 0x1000
    stdcall round_down, 4095
    stdcall round_down, 4096
    stdcall round_down, 8191
    stdcall round_down, 8192
    ret
endp

proc round_down num
    mov eax, [num]
    and eax, not 0xFFF
    print_d eax
    ret
endp

proc main1_2
    print_s '*** main1_2 ***'
    mov eax, 0xFFFFFFFF
    add eax, 0x1000 - 0x10000
    print_x eax
    mov eax, 0xFFFFFFFF
    sub eax, 0x1000 * 15
    print_x eax
    ret
endp

proc main1_3
    print_s '*** main1_3 ***'
    print_d 0x1000 * 15
    print_d 0x10000 - 0x1000
    ret
endp

proc main2
    print_s '*** main2 ***'
    print_x esp
    ret

    stdcall setup_stack_limit1
    push eax
    print_d [stack_limit]
    stdcall setup_stack_limit2
    push eax
    print_d [stack_limit]
    pop eax
    pop ecx
    sub eax, ecx
    print_d eax
    ret
endp

proc setup_stack_limit1
    mov eax, esp
    and eax, not 0xFFF
    add eax, 0x1000 - 0x10000
    mov [stack_limit], eax
    ret
endp

proc setup_stack_limit2
    mov eax, esp
    sub eax, 64000
    mov [stack_limit], eax
    ret
endp

proc main
    print_s '*** main3 ***'
    print_x esp
    stdcall setup_stack_limit1
    stdcall recursive_fun, 20000
    print_s 'done'
    ret
endp

proc recursive_fun buf_sz
    mov eax, esp
    sub eax, [stack_limit]
    cmp eax, 100h
    jb .stack_overflow
    mov eax, [buf_sz]
    dec eax
    stdcall recursive_fun, eax
    jmp .done
.stack_overflow:
    print_x esp
    print_x [stack_limit]
    print_d [buf_sz]
.done:
    ret
endp

include 'compiler/footer_data.inc'
stack_limit dd ?

include 'compiler/footer_idata.inc'
