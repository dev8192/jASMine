include 'compiler/header.x86.inc'

proc main1
    print_s '*** main1 ***'
    jmp .print_data
.local_data:
    dd 0x12345678
.print_data:
    mov eax, [.local_data]
    print_x eax
    ret
endp

proc main
    print_s '*** main2 ***'
    mov eax, [3.14]
    print_x eax
    ret
endp

include 'compiler/footer.inc'
