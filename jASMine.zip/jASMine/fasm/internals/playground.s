include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main1
    print_s '*** main1 ***'
    mov eax, '0'
    print_08x eax
    mov eax, '0' shl 8
    print_08x eax
    mov eax, 1 + '0' shl 8
    print_08x eax
    ret
endp

proc main
    print_s '*** main2 ***'
    mov edi, locals_counter
    mov eax, 1 + '0' shl 8
    stos word [edi]
    stdcall print_bytes, locals_counter, 8
    print_llx [locals_counter]
    ret
endp

include 'compiler/footer_data.inc'
locals_counter rb 8

include 'compiler/footer_idata.inc'
