include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    local current_line:DWORD, error_line:DWORD

    mov [current_line], 123
    push [current_line]
    pop [error_line]
    print_d [error_line]

    mov [current_line], 456
    mov eax, [current_line]
    mov [error_line], eax
    print_d [error_line]

    ret
endp

include 'compiler/footer.inc'
