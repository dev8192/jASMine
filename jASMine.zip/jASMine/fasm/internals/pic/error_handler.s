include 'compiler/header.x86.inc'

proc error_func
    print_s 'error_func'
    ret
endp

proc main1
    print_s '*** main1 ***'
    local error:DWORD
    print_x esp
    mov [error], error_func
    call error_handler
error_handler:
    mov eax, [error]
    sub eax, error_handler
    add [esp], eax
    print_x error_func
    print_x dword [esp]
    add esp, 4
    stdcall error_func
    print_x esp
    ret
endp

proc main2
    print_s '*** main2 ***'
    local error:DWORD
    print_x esp
    mov [error], error_func
    call error_handler
error_handler:
    mov eax, [error]
    sub eax, error_handler
    add [esp], eax
    ret
    print_x esp
    ret
endp

proc main
    print_s '*** main3 ***'
    print_x esp
    stdcall main3_1
    print_x esp
    ret
endp

proc main3_1
   ;print_s '*** main3_1 ***'
    push error_func
    ret
endp

include 'compiler/footer.inc'
