include 'compiler/header.x86.inc'


; 0x01 byte_number
; 0x02 word_number
; 0x04 dword_number
; 0x08 qword_number
; 0x10 register
; 0x11 label
; 0xF0 rva
; 0xF1 plt
; 0xD0 not
; 0xE0 bsf
; 0xE1 bsr
; 0x83 neg
; 0x80 add
; 0x81 sub
; 0x90 mul
; 0x91 div
; 0xA0 mod
; 0xB0 and
; 0xB1 or
; 0xB2 xor
; 0xC0 shl
; 0xC1 shr


proc main
    print_s '*** main1 ***'
    locals
        token_str db 0
        token_float db '.'
        token_other db 5
    endl
    stdcall calculate_expression, addr token_str
    stdcall calculate_expression, addr token_float
    stdcall calculate_expression, addr token_other
    ret
endp

proc calculate_expression data
    mov esi, [data]
    cmp byte [esi], 0
    je .get_string_value
    cmp byte [esi], '.'
    je .convert_fp
.calculation_loop:
    print_s 'other'
    jmp .exit
    jmp .calculation_loop
.convert_fp:
    print_s 'float'
    jmp .exit
.get_string_value:
    print_s 'string'
.exit:
    ret
endp

include 'compiler/footer.inc'
