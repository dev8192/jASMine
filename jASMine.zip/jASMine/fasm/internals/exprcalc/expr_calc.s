include 'compiler/header.x86.inc'

struct EVAL_STACK_FRAME
    value                   dq ?    ; +0
    base_reg                db ?    ; +8
    index_reg               db ?    ; +9
    base_reg_multiplier     db ?    ; +10
    index_reg_multiplier    db ?    ; +11
    reloc_type              db ?    ; +12
    sign_extension_bit      db ?    ; +13
    padding                 rb 2    ; +14
    section_idx             dd ?    ; +16
ends                                ; +20

proc main
    print_s '*** main1 ***'
    stdcall calculate_expression
    ret
endp

proc calculate_expression
    print_d sizeof.EVAL_STACK_FRAME
    ret
endp



include 'compiler/footer.inc'
