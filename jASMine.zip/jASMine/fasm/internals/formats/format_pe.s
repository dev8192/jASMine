include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    print_x 3 + 10 shl 16   ; 000a_0003
    print_x 5 + 0 shl 16    ; 0000_0005
    ret
endp

include 'compiler/footer.inc'
