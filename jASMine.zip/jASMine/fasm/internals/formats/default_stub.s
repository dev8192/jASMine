include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    jmp .print_info

.default_stub:
    use16
    push cs
    pop ds
    mov dx, .stub_message - .default_stub
    mov ah, 9
    int 21h
    mov ax, 4C01h
    int 21h
.stub_message db 'This program cannot be run in DOS mode.', 0Dh, 0Ah, 24h
    rq 1
.default_stub_end:
    use32

.print_info:
    print_x .default_stub_end - .default_stub
    print_d .default_stub_end - .default_stub
    ret
endp

include 'compiler/footer.inc'
