include 'compiler/header.x86.inc'
include 'symbol.data.inc'

proc main
    print_s '*** main1 ***'
    stdcall print_table, 8
    ret
endp

proc print_table uses ebx esi edi, num
    local h_out:DWORD, chars_written:DWORD
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [h_out], eax
    mov edi, [num]
    dec edi
    movzx esi, word [symbols + edi * 4]
    add esi, symbols
    movzx ebx, word [symbols + edi * 4 + 2]
    inc edi
.loop:
    invoke WriteConsoleA, [h_out], esi, edi, addr chars_written, 0
    print_newline
    add esi, edi
    add esi, 2
    dec ebx
    jnz .loop
    ret
endp

proc main2 uses ebx
    print_s '*** main2 ***'
    lea ebx, [symbols + 2]
.loop:
    movzx eax, word [ebx]
    print_d eax
    add ebx, 4
    cmp ebx, symbols_1
    jb .loop
    ret
endp

proc main3
    print_s '*** main3 ***'
    stdcall count_symbols
    print_d eax ; 328
    ret
endp

proc count_symbols
    xor eax, eax
    lea edx, [symbols + 2]
.loop:
    movzx ecx, word [edx]
    add eax, ecx
    add edx, 4
    cmp edx, symbols_1
    jb .loop
    ret
endp

include 'compiler/footer.inc'
