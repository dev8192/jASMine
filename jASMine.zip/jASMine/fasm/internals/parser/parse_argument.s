include 'compiler/header.x86.inc'

; parse_argument SOURCE\PARSER.INC

proc main1
    print_s '*** main1 ***'
    stdcall main1_1, 743 ; (743 + 256) - 1000 = 999 - 1000 = -1 ok
    stdcall main1_1, 744 ; (744 + 256) - 1000 = 1000 - 1000 = 0 out_of_memory
    stdcall main1_1, 745 ; (745 + 256) - 1000 = 1001 - 1000 = 1 out_of_memory
    ret
endp

proc main1_1 uses edi, mem
    local labels_list:DWORD
    mov [labels_list], 1000
    mov edi, [mem]
    lea eax, [edi + 0x100]
    cmp eax, [labels_list]
    jae .out_of_memory ; jnc (jump if not carry)
    print_s 'ok'
    jmp .exit
.out_of_memory:
    print_s 'out_of_memory'
.exit:
    ret
endp

proc main
    print_s '*** main2 ***'
    mov eax, 5 \ add eax, 10
    print_d eax
    ret
endp

include 'compiler/footer.inc'
