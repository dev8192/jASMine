
local_symbols
locals_counter

