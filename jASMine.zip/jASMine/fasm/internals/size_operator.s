include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    print_x 0x12345678
    ret
endp

; get_size_operator
; cmp al, 11h

include 'compiler/footer.inc'
