include 'compiler/header.x86.inc'

dummy = main2

proc main uses ebx esi
    print_s '*** main1 ***'
    print_d next_3 - bytecode
    print_d instruction_handler + print_char - next_1
    print_d instruction_handler + print_char - next_2
    print_d instruction_handler + exit_vm - next_3

    print_d print_char
    print_d exit_vm
    ret
endp

proc main2 uses ebx esi
    print_s '*** main2 ***'
    local char_buffer:WORD
    mov [char_buffer + 1], 0

    mov esi, bytecode

dispatch_anchor:
    call instruction_handler
instruction_handler:
    movzx ebx, word [esi]
    mov al, [esi+2]
    add esi, 3
    add [esp], ebx
    ret

print_char:
    mov byte [char_buffer], al
    print_s addr char_buffer
    jmp dispatch_anchor

exit_vm:
    ret
endp

include 'compiler/footer_data.inc'
    
bytecode:
    dw (print_char - next_1) , 'A'    ; Jump to print_char, arg = 'A'
next_1:
    dw (print_char - next_2) , 'B'    ; Jump to print_char, arg = 'B'
next_2:
    dw (exit_vm - next_3)    , 0      ; Jump to exit_vm,    arg = 0
next_3:

include 'compiler/footer_idata.inc'
