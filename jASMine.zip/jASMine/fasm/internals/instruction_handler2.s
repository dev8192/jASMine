format PE console
entry start

section '.code' code readable executable

start:
    ; Set up ESI to point to our mock instruction bytecode
    mov esi, instruction_stream

    ; Execute our threaded code routine
    call instruction_handler

    ; The routine modifies the return address on the stack.
    ; Instead of returning here, it jumps forward by the value in EBX.
    ; For this demo, EBX will be 0x0005, jumping over the trapping instruction.
    
    ; This instruction will be skipped if the pattern works correctly
    mov eax, 0xDEADBEEF 

target_destination:
    mov ecx, 0x1337

    ; Exit the program
    push 0
    call [ExitProcess]

; --- The requested pattern ---
instruction_handler:
    movzx ebx, word [esi]   ; Load 2 bytes into EBX (0x0005 from our stream)
    mov al, [esi+2]         ; Load 1 byte into AL (0xAA from our stream)
    add esi, 3              ; Move ESI past this 3-byte data block
    add [esp], ebx          ; Alter the return address on the stack by EBX bytes
    ret                     ; Jump to the newly calculated return address


section '.data' data readable writeable
    instruction_stream db 0x05, 0x00, 0xAA


section '.idata' import data readable

    library kernel32, 'kernel32.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'
