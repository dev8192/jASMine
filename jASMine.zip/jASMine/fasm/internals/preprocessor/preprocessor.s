include 'compiler/header.x86.inc'

struct SYMBOL_NODE
    next_symbol     dd ?    ; +0
    symbol_name     dd ?    ; +4
    macro_body      dd ?    ; +8
    defined_line    dd ?    ; +12
ends                        ; +16

proc main
    print_s '*** main1 ***'
    print_d sizeof.SYMBOL_NODE
    ret
endp

include 'compiler/footer.inc'
