include 'compiler/header.x86.inc'

; --------------- SOURCE\WIN32\FASM.ASM ---------------

proc main
    print_s '*** main1 ***'
    stdcall get_params                          ; 16
    stdcall preprocessor                        ; 36
    ret
endp

proc get_params                                 ; 80 - 323
    mov esi, command_line1
    lodsb
    or al, al
    jz .all_params
    jmp .exit
.all_params:
    mov [definitions_pointer], predefinitions
    stdcall convert_definition_option
    mov [initial_definitions], predefinitions   ; 271
.exit:
    ret
endp

proc convert_definition_option
    ret
endp

; --------------- SOURCE\PREPROCE.INC ---------------

proc preprocessor uses esi
    mov esi, [initial_definitions]
    test esi, esi
    jz .predefinitions_ok
    print_s 'process_predefinitions'
    jmp .exit
.predefinitions_ok:
    print_s 'predefinitions_ok'
.exit:
    ret
endp

include 'compiler/footer_data.inc'
definitions_pointer dd ?
initial_definitions dd ?
predefinitions rb 1000h

command_line1 db 0, 'hello', 0

include 'compiler/footer_idata.inc'
