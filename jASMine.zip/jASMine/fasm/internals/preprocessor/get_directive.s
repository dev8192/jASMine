include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    stdcall get_directive__test, 'match', 5
    stdcall get_directive__test, 'hello', 5
    print_s 'done'
    ret
endp

proc get_directive__test str_ptr, str_len
    stdcall get_directive, [str_ptr], [str_len]
    test eax, eax
    jz .exit
   ;stdcall eax
    print_x eax
    print_x match_directive
.exit:
    ret
endp

proc get_directive uses ebx esi edi, str_ptr, str_len
    mov esi, [str_ptr]
    mov edi, preprocessor_directives
.scan_directives:
    mov esi, [str_ptr]
    movzx eax, byte [edi]
    test eax, eax
    jz .no_directive
    mov ecx, [str_len]
    inc edi
    mov ebx, edi
    add ebx, eax
    cmp ecx, eax
    jne .next_directive
    repe cmps byte [esi], [edi]
    jb .no_directive
    je .directive_found
.next_directive:
    mov edi, ebx
    add edi, 4
    jmp .scan_directives
.no_directive:
    xor eax, eax
    jmp exit
.directive_found:
    mov eax, [ebx]
exit:
    ret
endp

proc define_symbolic_constant
    print_s 'define_symbolic_constant'
    ret
endp

proc include_file
    print_s 'include_file'
    ret
endp

proc irp_directive
    print_s 'irp_directive'
    ret
endp

proc irps_directive
    print_s 'irps_directive'
    ret
endp

proc irpv_directive
    print_s 'irpv_directive'
    ret
endp

proc define_macro
    print_s 'define_macro'
    ret
endp

proc match_directive
    print_s 'match_directive'
    ret
endp

proc postpone_directive
    print_s 'postpone_directive'
    ret
endp

proc purge_macro
    print_s 'purge_macro'
    ret
endp

proc rept_directive
    print_s 'rept_directive'
    ret
endp

proc restore_equ_constant
    print_s 'restore_equ_constant'
    ret
endp

proc purge_struc
    print_s 'purge_struc'
    ret
endp

proc define_struc
    print_s 'define_struc'
    ret
endp

include 'compiler/footer_data.inc'
preprocessor_directives:
    db 6,'define'
    dd define_symbolic_constant
    db 7,'include'
    dd include_file
    db 3,'irp'
    dd irp_directive
    db 4,'irps'
    dd irps_directive
    db 4,'irpv'
    dd irpv_directive
    db 5,'macro'
    dd define_macro
    db 5,'match'
    dd match_directive
    db 8,'postpone'
    dd postpone_directive
    db 5,'purge'
    dd purge_macro
    db 4,'rept'
    dd rept_directive
    db 7,'restore'
    dd restore_equ_constant
    db 7,'restruc'
    dd purge_struc
    db 5,'struc'
    dd define_struc
    db 0

include 'compiler/footer_idata.inc'

section '.reloc' fixups data readable discardable
