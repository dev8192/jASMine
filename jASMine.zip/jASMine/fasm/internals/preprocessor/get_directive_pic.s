include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    stdcall get_directive__test, 'match', 5
    stdcall get_directive__test, 'hello', 5
    ret
endp

proc get_directive__test str_ptr, str_len
    stdcall get_directive, [str_ptr], [str_len]
    jz .exit
    stdcall eax
.exit:
    ret
endp

proc get_directive uses ebx esi edi, str_ptr, str_len
    mov esi, [str_ptr]
    mov edi, preprocessor_directives
.scan_directives:
    mov esi, [str_ptr]
    movzx eax, byte [edi]
    test eax, eax
    jz .no_directive
    mov ecx, [str_len]
    inc edi
    mov ebx, edi
    add ebx, eax
    cmp ecx, eax
    jne .next_directive
    repe cmps byte [esi], [edi]
    jb .no_directive
    je .directive_found
.next_directive:
    mov edi, ebx
    add edi, 2
    jmp .scan_directives
.no_directive:
    xor eax, eax
    jmp .exit
.directive_found:
    call ..directive_handler
..directive_handler:
    pop eax
    movzx ecx, word [ebx]
    add eax, ecx
.exit:
    ret
endp

proc define_symbolic_constant
    print_s 'define_symbolic_constant'
    ret
endp

proc include_file
    print_s 'include_file'
    ret
endp

proc irp_directive
    print_s 'irp_directive'
    ret
endp

proc irps_directive
    print_s 'irps_directive'
    ret
endp

proc irpv_directive
    print_s 'irpv_directive'
    ret
endp

proc define_macro
    print_s 'define_macro'
    ret
endp

proc match_directive
    print_s 'match_directive'
    ret
endp

proc postpone_directive
    print_s 'postpone_directive'
    ret
endp

proc purge_macro
    print_s 'purge_macro'
    ret
endp

proc rept_directive
    print_s 'rept_directive'
    ret
endp

proc restore_equ_constant
    print_s 'restore_equ_constant'
    ret
endp

proc purge_struc
    print_s 'purge_struc'
    ret
endp

proc define_struc
    print_s 'define_struc'
    ret
endp

include 'compiler/footer_data.inc'
preprocessor_directives:
    db 6,'define'
    dw define_symbolic_constant - ..directive_handler
    db 7,'include'
    dw include_file - ..directive_handler
    db 3,'irp'
    dw irp_directive - ..directive_handler
    db 4,'irps'
    dw irps_directive - ..directive_handler
    db 4,'irpv'
    dw irpv_directive - ..directive_handler
    db 5,'macro'
    dw define_macro - ..directive_handler
    db 5,'match'
    dw match_directive - ..directive_handler
    db 8,'postpone'
    dw postpone_directive - ..directive_handler
    db 5,'purge'
    dw purge_macro - ..directive_handler
    db 4,'rept'
    dw rept_directive - ..directive_handler
    db 7,'restore'
    dw restore_equ_constant - ..directive_handler
    db 7,'restruc'
    dw purge_struc - ..directive_handler
    db 5,'struc'
    dw define_struc - ..directive_handler
    db 0

include 'compiler/footer_idata.inc'
