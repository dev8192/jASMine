include 'compiler/header.x86.inc'

proc main1 uses ebx esi
    print_s '*** main1 ***'
    local h_out:DWORD, chars_written:DWORD
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [h_out], eax
    mov esi, preproc_directives1
.loop:
    movzx ebx, byte [esi]
    test ebx, ebx
    jz .exit
    inc esi
    invoke WriteConsoleA, [h_out], esi, ebx, addr chars_written, 0
    add esi, ebx
    print_space
    movzx eax, word [esi]
    lea eax, [directive_handler + eax]
    stdcall eax
    add esi, 2
    jmp .loop
.exit:
    ret
endp

struct PREPROC_DIRECTIVE
    name    dd ?
    handler dd ?
ends

proc main uses ebx esi
    print_s '*** main2 ***'
    mov esi, preproc_directives2
    mov ebx, preproc_directives2_len
    test ebx, ebx
    jz .exit
.loop:
    print_s0 [esi + PREPROC_DIRECTIVE.name]
    print_space
    stdcall [esi + PREPROC_DIRECTIVE.handler]
    add esi, sizeof.PREPROC_DIRECTIVE
    dec ebx
    jnz .loop
.exit:
    ret
endp

directive_handler:

proc define_symbolic_constant
    print_s 'define_symbolic_constant'
    ret
endp

proc include_file
    print_s 'include_file'
    ret
endp

proc irp_directive
    print_s 'irp_directive'
    ret
endp

proc irps_directive
    print_s 'irps_directive'
    ret
endp

proc irpv_directive
    print_s 'irpv_directive'
    ret
endp

include 'compiler/footer_data.inc'
preproc_directives1:
    db 6,'define'
    dw define_symbolic_constant-directive_handler
    db 7,'include'
    dw include_file-directive_handler
    db 3,'irp'
    dw irp_directive-directive_handler
    db 4,'irps'
    dw irps_directive-directive_handler
    db 4,'irpv'
    dw irpv_directive-directive_handler
    db 0

str_define  db 'define', 0
str_include db 'include', 0
str_irp     db 'irp', 0
str_irps    db 'irps', 0
str_irpv    db 'irpv', 0

preproc_directives2:
    PREPROC_DIRECTIVE str_define, define_symbolic_constant
    PREPROC_DIRECTIVE str_include, include_file
    PREPROC_DIRECTIVE str_irp, irp_directive
    PREPROC_DIRECTIVE str_irps, irps_directive
    PREPROC_DIRECTIVE str_irpv, irpv_directive
preproc_directives2_len = ($ - preproc_directives2) / sizeof.PREPROC_DIRECTIVE

include 'compiler/footer_idata.inc'
