include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc create_lookup_table
    mov edi, characters
    xor al, al
.make_characters_table:
    stosb
    inc al
    jnz .make_characters_table

    mov esi, characters + 'a'
    mov edi, characters + 'A'
    mov ecx, 26
    rep movsb

    mov edi, characters
    mov esi, symbol_characters + 1
    movzx ecx, byte [esi - 1]
    xor eax, eax
.mark_symbol_characters:
    lodsb
    mov byte [edi + eax], 0
    loop .mark_symbol_characters
    ret
endp

proc lower_case uses ebx esi edi, buf, buf_sz
    mov esi, [buf]
    mov ecx, [buf_sz]
    mov edi, converted
    mov ebx, characters
.convert_case:
    lods byte [esi]
    xlat byte [ebx]
    stos byte [edi]
    loop .convert_case
    ret
endp

proc main1
    print_s '*** main1 ***'
    stdcall create_lookup_table
    
    stdcall lower_case, str1, 3
    print_s converted

    stdcall lower_case, str1, 4
    print_s converted
    ret
endp

proc main
    print_s '*** main2 ***'
    movzx eax, [symbol_characters]
    print_d eax
    print_d symbol_characters_len - 1
    ret
endp

include 'compiler/footer_data.inc'
characters  rb 0x100
converted   rb 0x100
symbol_characters db 27
    db 9,0Ah,0Dh,1Ah,20h,'+-/*=<>()[]{}:,|&~#`;\'
symbol_characters_len = $ - symbol_characters

str1        db 'ABCDEF', 0

include 'compiler/footer_idata.inc'
