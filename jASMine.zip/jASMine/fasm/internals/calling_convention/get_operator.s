include 'compiler/header.x86.inc'

; push esi ecx
; sub esi, 2
; mov edi, single_operand_operators
; call get_operator
; pop ecx esi

proc main
    print_s '*** main1 ***'
    stdcall main1_1
    stdcall main1_2
    stdcall main1_3
    ret
endp

proc main1_1 uses edi
    mov edi, 111
    push edi
    mov edi, 123
    call main1_1_1
    pop edi
    print_d edi
    ret
endp

proc main1_1_1
    print_d0 edi
    print_space
    ret
endp

proc main1_2 uses edi
    mov edi, 111
    stdcall main1_2_1, 123
    print_d edi
    ret
endp

proc main1_2_1 num
    print_d0 [num]
    print_space
    ret
endp

proc main1_3 uses edi
    mov edi, 111
    stdcall main1_3_1, 123
    print_d edi
    ret
endp

proc main1_3_1 uses edi, num
    mov edi, [num]
    print_d0 edi
    print_space
    ret
endp

include 'compiler/footer.inc'
