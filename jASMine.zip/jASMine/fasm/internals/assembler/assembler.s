include 'compiler/header.x86.inc'

proc main1 uses ebx
    print_s '*** main1 ***'
    mov ebx, 5
.pass_loop:
    dec ebx
    stdcall .assemble_line, ebx
    jnc .pass_loop
    ret
endp

proc .assemble_line count
    print_d [count]
    sub [count], 1
    ret
endp

proc main2 uses ebx
    print_s '*** main2 ***'
    xor ebx, ebx
.pass_loop:
    inc ebx
    stdcall .assemble_line, ebx
    jnc .pass_loop
    ret
endp

proc .assemble_line count
    print_d [count]
    add [count], 0 - 5
    ret
endp

proc main uses ebx
    print_s '*** main3 ***'
    xor ebx, ebx
.pass_loop:
    inc ebx
    stdcall .assemble_line, ebx
    jnc .pass_loop
    ret
endp

proc .assemble_line count
    print_d [count]
    cmp [count], 5
    jb .continue
    stc
    jmp .exit
.continue:
    clc
.exit:
    ret
endp

include 'compiler/footer.inc'
