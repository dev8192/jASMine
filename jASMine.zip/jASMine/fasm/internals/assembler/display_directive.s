; TODO: When and how are messages actually "displayed"?
; Is it display_user_messages?

display 'hello'

; display 'world    ; nothing is printed
display abc         ; 'hello' is printed
