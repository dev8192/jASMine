include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main
    print_s '*** main1 ***'
    stdcall print_word, 0x12345678
    stdcall print_word, 0x00001234
    stdcall print_word, 0x00000012
    ret
endp

proc print_word mem
    stdcall print_bytes, addr mem, 4
    and [mem], 0xFFFF
    print_x [mem]
    ret
endp

include 'compiler/footer.inc'
