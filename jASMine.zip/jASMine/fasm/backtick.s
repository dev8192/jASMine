include 'compiler/header.x86.inc'

macro print1 arg {
    cinvoke puts, arg
}

macro print2 arg {
    cinvoke puts, `arg
}

proc main
    cinvoke puts, '*** main1 ***'
    print1 'hello'
    print2 hello
    ret
endp

include 'compiler/footer.inc'
