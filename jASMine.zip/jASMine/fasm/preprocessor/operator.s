include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    print_d 10 + 5
    print_d 13 / 5
    print_d 13 mod 5
   ;print_d 13 / 0
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    print_08x 0xFF
    print_08x not 0xFF
    print_08x 0xFF or not 0xFF
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    print_08x 0xFF            ; 000000ff
    print_08x 0xFF shl  8     ; 0000ff00
    print_08x 0xFF shl 16     ; 00ff0000
    print_08x 0xFF shl 24     ; ff000000
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    print_llx 0x11223344_55667788
    print_llx2 0x55667788, 0x11223344
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    print_016llx 0xFF
    print_016llx 0xFF shl  8
    print_016llx 0xFF shl 16
    print_016llx 0xFF shl 24
    print_016llx 0xFF shl 32
    print_016llx 0xFF shl 40
    print_016llx 0xFF shl 48
    print_016llx 0xFF shl 56
    ret
endp

proc main6
    cinvoke puts, '*** main6 ***'
    print_x -0x55
    print_x not 0x55 + 1
    ret
endp

proc main7
    cinvoke puts, '*** main7 ***'
    print_x 34
    print_x -34
    print_x (-34)
    print_x (-34) and 0xFFFF
    ret
endp

proc main8
    cinvoke puts, '*** main8 ***'
    print_x -1
    print_x (-1) shr 1
    print_x not (1 shl 31)
    ret
endp

proc main9
    cinvoke puts, '*** main9 ***'
    print_d 0x80000000 shr 31
    print_d 0x80000000_00000000 shr 63
    ret
endp

proc main10
    cinvoke puts, '*** main10 ***'
    print_08x 0x00000001 shl 31
    print_08x 0x80000000 shr 31
    print_016llx 0x00000000_00000001 shl 63
    print_016llx 0x80000000_00000000 shr 63
    ret
endp

proc main11
    cinvoke puts, '*** main11 ***'
    print_llx (-1) shr 1
    print_llx 0xFFFFFFFF_FFFFFFFF shr 1
    ret
endp

include 'compiler/footer.inc'
