format PE64

include 'compiler_old.inc'
include 'win64ax.inc'

stdcall main
cinvoke puts, 'done'
invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_016llx, 0xFF            ; 00000000_000000ff
    cinvoke printf, fmt_016llx, 0xFF shl  8     ; 00000000_0000ff00
    cinvoke printf, fmt_016llx, 0xFF shl 16     ; 00000000_00ff0000
    cinvoke printf, fmt_016llx, 0xFF shl 24     ; 00000000_ff000000
    cinvoke printf, fmt_016llx, 0xFF shl 32     ; 000000ff_00000000
    cinvoke printf, fmt_016llx, 0xFF shl 40     ; 0000ff00_00000000
    cinvoke printf, fmt_016llx, 0xFF shl 48     ; 00ff0000_00000000
    cinvoke printf, fmt_016llx, 0xFF shl 56     ; ff000000_00000000
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_llx, 0x11223344_55667788
    ret
endp

.data
include 'util/format.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
