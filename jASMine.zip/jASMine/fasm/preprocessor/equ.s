; not working. why?
format PE console
entry start

include 'win32a.inc'

ci_alias equ cinvoke

section '.data' data readable writeable
    fmt     db "hello", 10, 0

section '.code' code readable executable

start:
    cinvoke printf, fmt
    ci_alias printf, fmt
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
