format PE console
entry start

incl fix include
;incl equ include   ; not working

incl 'win32a.inc'

section '.data' data readable writeable
    fmt     db "*** fix ***", 10, 0

section '.code' code readable executable

start:
    cinvoke printf, fmt
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
