include 'compiler/header.x86.inc'

; 7   rva plt
; 6   bsf bsr
; 5   not
; 4   shl shr
; 3   and or xor
; 2   mod
; 1   * /
; 0   + -

proc main
    cinvoke puts, '*** main1 ***'
    print_3d    0 and 1,    1 and 0,    1 and 1
    print_3d    0  or 1,    1  or 0,    1  or 1
    print_3d    0 xor 1,    1 xor 0,    1 xor 1
    ret
endp

proc main11
    cinvoke puts, '*** main11 ***'
    print_3d    4 * 3 + 1,    (4 * 3) + 1,    4 * (3 + 1)
    print_3d    1 + 4 * 3,    1 + (4 * 3),    (1 + 4) * 3
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    print_3d    4 shl 1 + 2,    (4 shl 1) + 2,    1 shl (1 + 2)
    print_3d    2 + 4 shl 1,    2 + (4 shl 1),    (2 + 4) shl 1
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    print_08x\
        0x78 or\
        0x56 shl 8 or\
        0x34 shl 16 or\
        0x12 shl 24
    print_08x\
        0x78 or\
        (0x56 shl 8) or\
        (0x34 shl 16) or\
        (0x12 shl 24)
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    print_3d    4 - 3 + 1,    (4 - 3) + 1,    4 - (3 + 1)
    print_3d    1 + 4 - 3,    1 + (4 - 3),    (1 + 4) - 3
    ret
endp

include 'compiler/footer.inc'
