include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    num1 = 5
    print_d num1
    num1 = num1 + 2
    print_d num1
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    num1 = 5
    num2 = 10
    sum = num1 + num2
    print_d sum
    ret
endp

include 'compiler/footer.inc'
