include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    print_s str1
    print_d str1_len
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    print_x addr1
    print_x addr2
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    stdcall main3_1
    stdcall main3_2
    stdcall main3_3
    ret
endp

proc main3_1
    align 16
    push $
    push $
    push fmt_2x
    call [printf]
    add esp, 12
    ret
endp

proc main3_2
    align 16
.addr1:
    push .addr1
.addr2:
    push .addr2
    push fmt_2x
    call [printf]
    add esp, 12
    ret
endp

proc main3_3
    align 16
    push .addr1
.addr1:
    push .addr2
.addr2:
    push fmt_2x
    call [printf]
    add esp, 12
    ret
endp

include 'compiler/footer_data.inc'
str1        db 'abc', 0
str1_len    = $ - str1 - 1

align 16
addr1 = $
rb 1
addr2 = $
rb 1

include 'compiler/footer_idata.inc'
