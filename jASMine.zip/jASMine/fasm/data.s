give me a program that shows the difference between:
rb 32 = buffer, uninitialized, no EXE size increase
db 32 = one byte, initialized to decimal 32
db 32 dup(0)