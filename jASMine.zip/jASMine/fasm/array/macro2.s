format PE
entry start

include 'win32a.inc'

macro print_arr format, array, index {
    cinvoke printf, format, [array + (index)*4]
}

section '.data' data readable writeable
    fmt1    db 'arr1: %d', 10, 0
    fmt2    db 'arr2: %d', 10, 0
    arr1    dd 101, 201, 301, 401
    arr2    dd 102, 202, 302, 402

section '.text' code readable executable
start:
    print_arr fmt1, arr1, 0
    print_arr fmt1, arr1, 1
    print_arr fmt1, arr1, 2
    print_arr fmt1, arr1, 3

    print_arr fmt2, arr2, 0
    print_arr fmt2, arr2, 1
    print_arr fmt2, arr2, 2
    print_arr fmt2, arr2, 3

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
