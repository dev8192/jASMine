format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    locals
        arr dq 5.0,\
               10.0,\
               15.0
    endl
    lea eax, [arr + 0]
    cinvoke printf, fmt_f, double [eax]
    lea eax, [arr + 8]
    cinvoke printf, fmt_f, double [eax]
    lea eax, [arr + 16]
    cinvoke printf, fmt_f, double [eax]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
