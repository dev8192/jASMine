format PE Console 4.0
entry start

include 'win32a.inc'

ID_CUT   = 101
ID_COPY  = 102
ID_PASTE = 103

section '.data' data readable writeable

    accelList1:
        db FCONTROL or FVIRTKEY, 0
        dw 'X', ID_CUT
        db FCONTROL or FVIRTKEY, 0
        dw 'C', ID_COPY
        db FCONTROL or FVIRTKEY, 0
        dw 'V', ID_PASTE
    size1 = $ - accelList1

    accelList2:
        ACCEL FCONTROL or FVIRTKEY, 'X', ID_CUT
        ACCEL FCONTROL or FVIRTKEY, 'C', ID_COPY
        ACCEL FCONTROL or FVIRTKEY, 'V', ID_PASTE
    size2 = $ - accelList2

    szSizes      db 'accelList1 is %d bytes, accelList2 is %d bytes.', 10, 0
    szMatch      db 'Result: They are IDENTICAL in memory.', 10, 0
    szDiff       db 'Result: They are NOT identical.', 10, 0

section '.text' code readable executable

start:
    cinvoke printf, szSizes, size1, size2

    mov     eax, size1
    cmp     eax, size2
    jne     .not_identical

    mov     esi, accelList1
    mov     edi, accelList2
    mov     ecx, size1
    repe    cmpsb
    jne     .not_identical

.identical:
    cinvoke printf, szMatch
    jmp     .exit

.not_identical:
    cinvoke printf, szDiff

.exit:
    invoke  ExitProcess, 0

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
