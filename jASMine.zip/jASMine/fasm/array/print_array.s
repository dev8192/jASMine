format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    my_array dd 10, 20, 30, 40, 50, 60, 70
    ARRAY_SIZE = ($ - my_array) / 4
    fmt      db '%d: %d', 10, 0

section '.code' code readable executable
start:
    xor ebx, ebx
.loop:
    cmp ebx, ARRAY_SIZE
    jge done

    mov eax, [my_array + ebx*4]
    cinvoke printf, fmt, ebx, eax

    inc ebx
    jmp .loop

done:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            msvcrt,   'msvcrt.dll'

    import kernel32, \
           ExitProcess, 'ExitProcess'

    import msvcrt, \
           printf, 'printf'
