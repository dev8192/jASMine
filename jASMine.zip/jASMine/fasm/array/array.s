format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    array       dd 10, 20, 30, 40
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0
    
proc main1 uses ebx
    cinvoke puts, '*** main1 ***'
    stdcall .print_item1, 3
    stdcall .print_item2, 3
    stdcall .print_item3, 3
    ret
endp
    
proc .print_item1, idx
    mov     eax, [idx]
    cinvoke printf, fmt_d, [array + eax * 4]
    ret
endp
    
proc .print_item2, idx
    mov     eax, [idx]
    lea     eax, [array + eax * 4]
    cinvoke printf, fmt_d, dword [eax]
    ret
endp
    
proc .print_item3, idx
    mov     eax, [idx]
    mov     eax, [array + eax * 4]
    cinvoke printf, fmt_d, eax
    ret
endp
    
proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, array
    lea     eax, [array]
    cinvoke printf, fmt_x, eax
    mov     eax, array
    cinvoke printf, fmt_x, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
