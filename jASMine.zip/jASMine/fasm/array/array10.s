format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    arr dd 10, 20, 30, 40, 50
    fmt db '%x: %d', 10, 0

section '.text' code readable executable
func1:
    xor ebx, ebx
    lea eax, [arr + ebx * 4]
    mov ecx, [arr + ebx * 4]
    cinvoke printf, fmt, eax, ecx
    inc ebx
    lea eax, [arr + ebx * 4]
    mov ecx, [arr + ebx * 4]
    cinvoke printf, fmt, eax, ecx
    inc ebx
    lea eax, [arr + ebx * 4]
    mov ecx, [arr + ebx * 4]
    cinvoke printf, fmt, eax, ecx
    inc ebx
    ret

start:
    stdcall func1
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
