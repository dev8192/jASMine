include 'boilerplate/header.x86.inc'

macro chain [instr] { forward instr }

proc main
    cinvoke puts, '*** main1 ***'
    xor eax, eax
    chain inc eax, inc eax, inc eax
    cinvoke printf, fmt_d, eax

    xor eax, eax
    chain <add eax, 2>, <add eax, 2>, <add eax, 2>
    cinvoke printf, fmt_d, eax
    ret
endp

include 'boilerplate/footer.inc'
