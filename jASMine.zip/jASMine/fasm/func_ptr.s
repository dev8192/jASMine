include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall func_ptr__test, [printf], fmt_d, 123
    ret
endp

proc func_ptr__test, func_ptr, p1, p2
    cinvoke printf, fmt_x, esp
    ccall [func_ptr], [p1], [p2]
    cinvoke printf, fmt_x, esp
    ret
endp

include 'boilerplate/footer.inc'
