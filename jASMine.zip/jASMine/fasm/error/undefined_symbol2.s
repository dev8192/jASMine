include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    print_d [section1.num1]
    print_d [..num2]
   ;print_d [num3]
    print_d num4
    print_s section1.str1
    ret
endp

include 'compiler/footer_data.inc'
section1:
.num1 dd 111
..num2 dd 222
;num3 dd 333
num4 = 444

;struct EXAMPLE
;    num dd ?
;ends

.str1 db 'hello', 0

include 'compiler/footer_idata.inc'
