include 'compiler/header.x86.inc'
include 'util/line.inc'

macro print_hello {
    print_s 'hello'
}

proc main1
    cinvoke puts, '*** main1 ***'
    print_hello
   ;print_hello world
    ret
endp

macro print_sum num1, num2 {
    print_d num1 + num2
}

proc main2
    cinvoke puts, '*** main2 ***'
    print_sum 5, 10
   ;print_sum 5, 10, 15
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    print_4d [line1.pt1.x], [line1.pt1.y], [line1.pt2.x], [line1.pt2.y]
   ;print_2d [pt1.x], [pt1.y]
    ret
endp

macro print_number1 num {
    print_d num
}

proc main
    cinvoke puts, '*** main4 ***'
   ;print_number1, 444
    ret
endp

;macro print_number2, num {
;    print_d num
;}

proc main5
    cinvoke puts, '*** main5 ***'
   ;print_number2 444
    ret
endp

include 'compiler/footer_data.inc'
pt1 POINT
;pt1 POINT 10
;pt1 POINT 10, 20
;pt1 POINT 10, 20, 30
line1 LINE <10, 20>, <30, 40>
;line1 LINE 10, 20, 30, 40
include 'compiler/footer_idata.inc'
