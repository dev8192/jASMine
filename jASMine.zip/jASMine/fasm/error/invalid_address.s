include 'compiler/header.x86.inc'
include 'util/introspection.text.inc'

; 00 x1
; 01 x2
; 10 x4
; 11 x8

proc main1
    cinvoke puts, '*** main1 ***'
    jmp .intro_end
.intro1: nop [ecx * 0]   ; 0F 1F 05 00 00 00 00      (00)(00 0)(101)
.intro2: nop [0]         ; 0F 1F 05 00 00 00 00      (00)(00 0)(101)
.intro3: nop [ecx * 1]   ; 0F 1F 01                  (00)(00 0)(001)
.intro4: nop [ecx]       ; 0F 1F 01                  (00)(00 0)(001)
.intro5: nop [ecx * 2]   ; 0F 1F 04 09               (00)(00 0)(100) (00)(00 1)(001)
.intro6: nop [ecx + ecx] ; 0F 1F 04 09               (00)(00 0)(100) (00)(00 1)(001)
.intro7: nop [ecx * 4]   ; 0F 1F 04 8D 00 00 00 00   (00)(00 0)(100) (10)(00 1)(101)
.intro8: nop [ecx * 8]   ; 0F 1F 04 CD 00 00 00 00   (00)(00 0)(100) (11)(00 1)(101)
.intro_end:
    introspect8
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    jmp .intro_end
.intro1: nop [ebp * 0]   ; 0F 1F 05 00 00 00 00      (00)(00 0)(101)
.intro2: nop [0]         ; 0F 1F 05 00 00 00 00      (00)(00 0)(101)
.intro3: nop [ebp * 1]   ; 0F 1F 45 00               (01)(00 0)(101)
.intro4: nop [ebp]       ; 0F 1F 45 00               (01)(00 0)(101)
.intro5: nop [ebp * 2]   ; 0F 1F 44 2D 00            (01)(00 0)(100) (00)(10 1)(101)
.intro6: nop [ebp + ebp] ; 0F 1F 44 2D 00            (01)(00 0)(100) (00)(10 1)(101)
.intro7: nop [ebp * 4]   ; 0F 1F 04 AD 00 00 00 00   (00)(00 0)(100) (10)(10 1)(101)
.intro8: nop [ebp * 8]   ; 0F 1F 04 ED 00 00 00 00   (00)(00 0)(100) (11)(10 1)(101)
.intro_end:
    introspect8
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    jmp .intro_end
.intro1: nop [esp * 0]  ; 0F 1F 05 00 00 00 00      (00)(00 0)(101)
.intro2: nop [esp * 1]  ; 0F 1F 04 24               (00)(00 0)(100)
;.intro3: nop [esp * 2] ; 0F 1F 04 ED 00 00 00 00   (00)(00 0)(100)  (00)(10 0)(101)
;.intro3: nop [esp * 4] ; 0F 1F 04 F5 00 00 00 00   (00)(00 0)(100)  (10)(10 0)(101)
;.intro3: nop [esp * 8] ; 0F 1F 04 FD 00 00 00 00   (00)(00 0)(100)  (11)(10 0)(101)
.intro_end:
    introspect2
    ret
endp

include 'compiler/footer.inc'
