include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    local num:DWORD
    mov [num], 123
    print_d [num]
    push 456
    print_d dword [esp]
    add esp, 4
    ret
endp

proc main2
    print_s '*** main2 ***'
    local num:DWORD
    mov eax, period
    cinvoke printf, fmt_c, dword [eax]
    ret
endp

proc main3
    print_s '*** main3 ***'
    local num:DWORD
    mov [num], 5
    stdcall increment, addr num
    print_d [num]
    ret
endp

proc increment num
    mov eax, [num]
    inc dword [eax]
    ret
endp

include 'compiler/footer.inc'
