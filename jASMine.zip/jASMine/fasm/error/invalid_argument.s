include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

;include

proc main
    cinvoke puts, '*** main1 ***'
    locals
        local_buf        db 3 dup (0x11, 0x22, 0x33)
       ;local_buf        db 3 dup (0x11)
        local_buf_len    = $ - local_buf
    endl
    print_d local_buf_len
    stdcall print_bytes, addr local_buf, local_buf_len
    print_d global_buf_len
    stdcall print_bytes, addr global_buf, global_buf_len
    ret
endp

include 'compiler/footer_data.inc'
global_buf        db 3 dup (0x11, 0x22, 0x33)
global_buf_len    = $ - global_buf
include 'compiler/footer_idata.inc'
