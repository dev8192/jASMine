include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    print_s 'hello
    ret
endp

include 'compiler/footer.inc'
