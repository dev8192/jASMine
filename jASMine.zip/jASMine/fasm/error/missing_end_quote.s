include 'compiler/header.x86.inc'

; convert_line
;     convert_line_data
;         convert_string
;             copy_string
;                 no_end_quote
;                     missing_end_quote

proc main
    cinvoke puts, '*** main1 ***'
    print_s 'hello
    ret
endp

include 'compiler/footer.inc'
