include 'boilerplate/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    int1 = 5
    cinvoke printf, fmt_d, int1
    ret
endp

; no error
proc main
    cinvoke puts, '*** main2 ***'
    local int1:DWORD
    mov [int1], 555
    cinvoke printf, fmt_d, [int1]
    ret
endp

include 'boilerplate/footer.inc'
