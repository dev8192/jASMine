include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
   ;mov eax 555
   ;mov eax
    mov
    ret
endp

proc main2
    print_s '*** main2 ***'
    push
    ret
endp

proc main3
    print_s '*** main3 ***'
    test eax, 0
   ;test 0, eax
    ret
endp

proc main4
    print_s '*** main4 ***'
   ;print_s str
    ret
endp

include 'compiler/footer_data.inc'
;str db 'hello', 0
include 'compiler/footer_idata.inc'
