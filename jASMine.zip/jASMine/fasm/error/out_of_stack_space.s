include 'compiler/header.x86.inc'

;include 'out_of_stack_space.s'
include 'out_of_stack_space1.inc'

proc main
    cinvoke puts, '*** main1 ***'
    ret
endp

include 'compiler/footer.inc'
