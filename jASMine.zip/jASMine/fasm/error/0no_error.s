include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local num1:DWORD, num1:DWORD
    mov [num1], 333
    print_d [num1]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    locals
        main dd 333
    endl
    print_d [main]
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    stdcall main1_1
    stdcall main1_2
    ret
endp

proc main1_1
    local num:DWORD
    mov [num], 123
    ret
endp

proc main1_2
    local 456:DWORD
    cinvoke printf, fmt_d, [456]
    ret
endp

include 'boilerplate/footer.inc'
