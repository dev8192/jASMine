include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    mov eax, num
    ret
endp

include 'compiler/footer.inc'
