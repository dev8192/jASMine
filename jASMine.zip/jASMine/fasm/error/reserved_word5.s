include 'boilerplate/header.x86.inc'

num equ 4
num = 3

proc main
    cinvoke puts, '*** main1 ***'
    print_d num
    ret
endp

include 'boilerplate/footer.inc'
