include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    locals
       ;num dq 12.25 + 0.5
        num dq 12.25
    endl
    mov eax, 12.25 + 0.5
    print_f [num]
    ret
endp

include 'compiler/footer.inc'
