include 'compiler/header.x86.inc'

; convert_line
;     convert_line_data
;         convert_separator
;             symbol_character
;                 backslash_character
;                     concatenate_lines
;                         extra_characters_on_line

proc main
    print_s '*** main1 ***'
    \
    \ ;
   ;\ hello
    ret
endp

include 'compiler/footer.inc'
\ ;