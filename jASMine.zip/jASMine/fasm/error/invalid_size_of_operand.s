include 'compiler/header.x86.inc'

proc main1 uses ebx
    cinvoke puts, '*** main1 ***'
    mov ebx, 0x12345678
    movzx eax, bl
    print_x eax
    movzx eax, bx
    print_x eax
   ;movzx eax, ebx
    mov eax, ebx
    print_x eax
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local mem:DWORD
    mov [mem], 0x12345678
    movzx eax, byte [mem]
    print_x eax
    movzx eax, word [mem]
    print_x eax
    movzx eax, dword [mem]
   ;mov eax, [mem]
    print_x eax
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    push eax
    pop eax
    push ax
    pop ax
   ;push al
    pop al
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    local buf[4]:BYTE
    mov [buf + 0], 0x11
    mov [buf + 1], 0x22
    mov [buf + 2], 0x33
    mov [buf + 3], 0x44
   ;print_x [buf]
    print_x dword [buf]
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    stdcall main5_1
    stdcall main5_2
   ;stdcall main5_3
    ret
endp

proc main5_1
    mov eax, fs
    print_x eax
    ret
endp

proc main5_2
    mov ax, fs
    movzx eax, ax
    print_x eax
    ret
endp

proc main5_3
    mov al, fs
    movzx eax, al
    print_x eax
    ret
endp

include 'compiler/footer.inc'
