include 'compiler/header.x86.inc'

;define
;restore
macro

proc main
    cinvoke puts, '*** main1 ***'
    ret
endp

include 'compiler/footer.inc'
