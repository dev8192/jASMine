include 'compiler/header.x86.inc'

include 'file_not_found.inc'

proc main
    cinvoke puts, '*** main1 ***'
    ret
endp

include 'compiler/footer.inc'
