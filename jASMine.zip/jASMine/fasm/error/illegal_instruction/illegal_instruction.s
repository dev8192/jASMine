include 'compiler/header.x86.inc'

proc main1
    print_s '*** main1 ***'
    hello
    ret
endp

proc main2
    print_s '*** main2 ***'
    hello world
    ret
endp

macro print_hello { print_s 'hello' }

proc main3
    print_s '*** main3 ***'
    print_hello
    print_d num1
    ret
endp

num1 = 111
;macro print_hello { print_s 'hello' }

;include 'data/person.inc'

proc main4
    print_s '*** main4 ***'
    local person:PERSON
    ret
endp

proc main5
    print_s '*** main5 ***'
    cinvoke printf, fmt_3d,\
       ;123, 456, 789
        111, 222, 333
    ret
endp

proc main
    print_s '*** main6 ***'
    print_d sizeof.EXAMPLE
    ret
endp

include 'compiler/footer_data.inc'
example EXAMPLE 5, 10
struct EXAMPLE
    field1 dd ?
    field2 db ?
ends

include 'compiler/footer_idata.inc'
