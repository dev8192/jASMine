include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
   ;abc = 'abc'
    'abc'
    ret
endp

include 'compiler/footer.inc'
