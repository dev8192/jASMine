include 'compiler/header.x86.inc'

; no error
proc

proc main
    cinvoke puts, '*** main1 ***'
    ret
endp

include 'compiler/footer.inc'
