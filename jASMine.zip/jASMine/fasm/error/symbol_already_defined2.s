include 'compiler/header.x86.inc'

;main = 111

proc main
    cinvoke puts, '*** main1 ***'
    ret
endp

include 'compiler/footer_data.inc'
main dd 222

include 'compiler/footer_idata.inc'
