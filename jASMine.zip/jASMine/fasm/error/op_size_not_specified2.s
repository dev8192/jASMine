format PE
entry start

include 'win32ax.inc'
;include 'win32a.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
   ;cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, [num1]
    cinvoke printf, fmt_d, [num2]
   ;cinvoke printf, fmt_d, dword [num2]
    ret
endp

section '.data' data readable writeable
include 'util/format.data.inc'
num1        dd 111
num2:       dd 222

include 'compiler/footer.inc'
