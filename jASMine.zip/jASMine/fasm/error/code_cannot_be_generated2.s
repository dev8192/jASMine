include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    jmp .addr1
    jc .addr1 + 0xFFBFEFA1
.addr1:
    mov eax, 0xFFFFFFFF
    sub eax, .addr1
    print_X eax ; 0xFFBFEFA0
    ret
endp

include 'compiler/footer.inc'
