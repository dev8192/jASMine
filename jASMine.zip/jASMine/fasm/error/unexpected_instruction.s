include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    i = 1
    while i <= 5
        print_d i
        i = i + 1
   ;end while
    ret
endp

include 'compiler/footer.inc'
