include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local num:DWORD
    mov [num], 0x11223344
    mov al, byte [num]
    movzx eax, al
    print_x eax
    ret
endp

include 'compiler/footer.inc'
