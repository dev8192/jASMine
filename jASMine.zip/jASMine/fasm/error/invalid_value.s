include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    local num:DWORD
    cinvoke printf, fmt_d, num
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local num:DWORD
    mov [num], 333
    push num
   ;push [num]
    push fmt_d
    call [printf]
    add esp, 8
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    num = 333
    if ? num
        cinvoke puts, 'hello'
    end if
    ret
endp

proc main
    cinvoke puts, '*** main4 ***'
    nop [eax * eax * 0]
    ret
endp

include 'compiler/footer.inc'
