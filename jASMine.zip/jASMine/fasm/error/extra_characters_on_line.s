include 'compiler/header.x86.inc'

proc main1
    print_s '*** main1 ***'
   ;mov eax, 0x7F | 0x80
   ;mov eax, 0x7F or 0x80
    mov eax, 5 > 1
    print_x eax
    ret
endp

proc main2
    print_s '*** main2 ***'
   ;nop 333
    nop eax
   ;nop eax, eax
    ret
endp

proc print_number num
    print_d [num]
    ret
endp

proc main3
    print_s '*** main3 ***'
   ;stdcall print_number 333
    ret
endp

proc main4
    print_s '*** main4 ***'
    locals
        arr dd 11 22
       ;arr dd 11, 22
    endl
    print_d [arr]
    print_d [arr + 4]
    ret
endp

proc main5
    print_s '*** main5 ***'
;.instr_start: mov eax, 123 .instr_end:
.instr_start: mov eax, 123
.instr_end:
    print_d eax
    ret
endp

proc main6
   ;print_s '*** main6 ***'
   ;stdcall main6_1
    stdcall main6_2
    ret
endp

proc main6_1
    print_s '*** main6_1 ***'
    local buf[12]:BYTE, buf_ptr:DWORD
    mov [buf_ptr], addr mem
    ret
endp

proc main6_2
    print_s '*** main6_2 ***'
    local buf[12]:BYTE, buf_ptr:DWORD
    lea eax, [buf]
    mov [buf_ptr], eax
    ret
endp

proc main7
    print_s '*** main7 ***'
    locals
       ;num1 dq 15.25 + 0.5
        num1 dq 15.25
    endl
    mov eax, 3.14 + 0.1
    print_f [num1]
    ret
endp

proc main
    print_s '*** main8 ***'
    use32
   ;use32 hello
    ret
endp

include 'compiler/footer.inc'
