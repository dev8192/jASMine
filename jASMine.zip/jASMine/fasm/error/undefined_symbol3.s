include 'compiler/header.x86.inc'

num1 = 111
num2 equ 222

proc main
    cinvoke puts, '*** main3 ***'
    print_d num1
    print_d num2
    print_d num3
   ;print_d num4
    ret
endp

num3 = 333
num4 equ 444

include 'compiler/footer.inc'
