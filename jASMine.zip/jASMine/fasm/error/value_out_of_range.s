include 'compiler/header.x86.inc'

proc main1
   ;print_s '*** main1 ***'
    stdcall main1_1
    stdcall main1_2
    stdcall main1_3
    ret
endp

proc main1_1
    print_s '*** main1_1 ***'
    print_llx 0xFFFFFFFF_FFFFFFFE + 1
   ;print_llx 0xFFFFFFFF_FFFFFFFE + 2
    ret
endp

num1 = 0xFFFFFFFF_FFFFFFFE + 1
;num1 = 0xFFFFFFFF_FFFFFFFE + 2

proc main1_2
    print_s '*** main1_2 ***'
    print_llx num1
    ret
endp

proc main1_3
    print_s '*** main1_3 ***'
    locals
        num dq 0xFFFFFFFF_FFFFFFFE + 1
       ;num dq 0xFFFFFFFF_FFFFFFFE + 2
    endl
    print_llx [num]
    ret
endp

proc main2
    print_s '*** main2 ***'
   ;mov eax, 0xFFFFFFFF + 1
   ;mov ax, 0xFFFF + 1
    mov al, 0xFF + 1
    ret
endp

proc main4
    print_s '*** main4 ***'
   ;push 1/0
    push 0/0
    ret
endp

proc main4
    print_s '*** main4 ***'
    mov eax, 1
   ;shl eax, 31
    shl eax, 32
    print_u eax
   ;print_u 1 shl 31
    print_u 1 shl 32
    print_u 0x80000000
    ret
endp

proc main78
    print_s '*** main78 ***'
    print_x -1
    print_llx -1
   ;print_x 0xFFFFFFFF_FFFFFFFF
    print_llx 0xFFFFFFFF_FFFFFFFF
    ret
endp

proc main22
    print_s '*** main22 ***'
    local num:BYTE
   ;mov [num], 256
    mov [num], 0xFFFFFFFF_FFFFFFFF - 0xFFFFFFFF_FFFFFFF0
    movzx eax, [num]
    print_x eax
    ret
endp

proc main
    print_s '*** main23 ***'
    locals
       ;num1 dq '123456789'
        num1 dq '12345678'
    endl
   ;mov eax, '12345'
    mov eax, '1234'
    print_x eax
    print_llx [num1]

    val = '123456789'
   ;val = '12345678'
    print_llx val
    ret
endp

include 'compiler/footer.inc'
