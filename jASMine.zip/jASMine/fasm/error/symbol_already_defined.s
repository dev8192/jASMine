include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    print_d [global_num1]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall print_hello
    ret
endp

proc print_hello
    cinvoke puts, 'hello'
    ret
endp

proc print_hello
    cinvoke puts, 'hello'
    ret
endp

struct EXAMPLE
    num dd ?
ends

;struct EXAMPLE
;    num dd ?
;ends

proc main3
    cinvoke puts, '*** main3 ***'
    local example:EXAMPLE
    mov [example.num], 333
    print_d [example.num]
    ret
endp

proc main
    cinvoke puts, '*** main4 ***'
    mov ecx, 1
.loop:
    loop .loop
    mov ecx, 1
;.loop:
;    loop .loop
    ret
endp

include 'compiler/footer_data.inc'
global_num1 dd 111
;global_num1 dd 222
include 'compiler/footer_idata.inc'
