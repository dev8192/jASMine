include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke puts, str1
    ret
endp

include 'compiler/footer_data.inc'
include 'symbol_already_defined4.inc'
;include 'symbol_already_defined4.inc'
include 'compiler/footer_idata.inc'
