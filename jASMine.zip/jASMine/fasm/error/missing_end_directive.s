include 'compiler/header.x86.inc'

;while

proc main
    cinvoke puts, '*** main1 ***'
    num = 333
    if defined num
        print_d num
   ;end if
    ret
endp

include 'compiler/footer.inc'
