format PE
entry start

include 'win32a.inc'

; ------------------------------------------------
; 00 01 02 03 04 05 06 07 08 09 0a 0b 0c 0d 0e 0f
; 61 62 63 0a 00 78 79 7a 0a 00 00 10 40 00 
; 61 62 63 0a 00 78 79 7a 0a 00 05 10 40 00 
; ------------------------------------------------
section '.data' data readable writeable
    str1            db 'abc', 10, 0     ; 00401000
    str2            db 'xyz', 10, 0     ; 00401005
    ptr1            dd str1             ; 0040100a
    buf_len         = $ - str1
    fmt_x           db '%08x', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall test40
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc test10
    cinvoke printf, fmt_x, str1
    cinvoke printf, fmt_x, str2
    cinvoke printf, fmt_x, ptr1
    ret
endp
    
proc test20
    movzx eax, [str1]
    cinvoke printf, fmt_x, eax
    movzx eax, [str2]
    cinvoke printf, fmt_x, eax
    cinvoke printf, fmt_x, [ptr1]
    ret
endp

proc test30
    cinvoke printf, [ptr1]
    mov [ptr1], str2
    cinvoke printf, [ptr1]
    ret
endp

proc test40
    stdcall print_bytes, str1, buf_len
    mov [ptr1], str2
    stdcall print_bytes, str1, buf_len
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
