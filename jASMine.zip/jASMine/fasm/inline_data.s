include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    jmp .print_msg
    .str        db 'abc', 0
    str_len     = $ - .str
    .fmt        db '"%s": %d', 10, 0
    .num         dd 100
.print_msg:
    cinvoke printf, .fmt, .str, str_len
    inc [.num]
    cinvoke printf, fmt_d, [.num]
    ret
endp

include 'boilerplate/footer.inc'
