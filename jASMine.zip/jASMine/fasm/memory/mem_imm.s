format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
t20:
    .fmt1       db '%08x ', 0
    .fmt2       db '%08x', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

; ----------------------------
; ffffffff ffffffab
; ffffffff ffffffab
; ffffffff ffff00ab
; ffffffff 000000ab
; ----------------------------
proc test10
    local buf1[4]:BYTE
    mov dword [buf1], -1
    local buf2[4]:BYTE
    mov dword [buf2], -1
    local buf3[4]:BYTE
    mov dword [buf3], -1
    local buf4[4]:BYTE
    mov dword [buf4], -1
    
    cinvoke printf, t20.fmt1, dword [buf1]
    mov [buf1], 0xAB
    cinvoke printf, t20.fmt2, dword [buf1]
    
    cinvoke printf, t20.fmt1, dword [buf2]
    mov byte[buf2], 0xAB
    cinvoke printf, t20.fmt2, dword [buf2]
    
    cinvoke printf, t20.fmt1, dword [buf3]
    mov word [buf3], 0xAB
    cinvoke printf, t20.fmt2, dword [buf3]
    
    cinvoke printf, t20.fmt1, dword [buf4]
    mov dword [buf4], 0xAB
    cinvoke printf, t20.fmt2, dword [buf4]

    ret
endp

; ----------------------------
; ffffffff 000000ab
; ffffffff ffffffab
; ffffffff ffff00ab
; ffffffff 000000ab
; ----------------------------
proc test20
    local num1:DWORD
    mov [num1], -1
    local num2:DWORD
    mov [num2], -1
    local num3:DWORD
    mov [num3], -1
    local num4:DWORD
    mov [num4], -1
    
    cinvoke printf, t20.fmt1, [num1]
    mov [num1], 0xAB
    cinvoke printf, t20.fmt2, [num1]
    
    cinvoke printf, t20.fmt1, [num2]
    mov byte[num2], 0xAB
    cinvoke printf, t20.fmt2, [num2]
    
    cinvoke printf, t20.fmt1, [num3]
    mov word [num3], 0xAB
    cinvoke printf, t20.fmt2, [num3]
    
    cinvoke printf, t20.fmt1, [num4]
    mov dword [num4], 0xAB
    cinvoke printf, t20.fmt2, [num4]

    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
