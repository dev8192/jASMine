format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%x', 10, 0
    buf11    rb 4
    buf12    rb 4
    buf13    rb 4
    buf14    rb 4

    buf41    rd 4
    buf42    rd 4
    buf43    rd 4
    buf44    rd 4

section '.text' code readable executable
start:
    stdcall test40
    invoke ExitProcess, 0
    
proc test10 uses ebx
    mov ebx, 0x12345678
    mov [buf11], bh
    cinvoke printf, fmt, dword [buf11]
    mov [buf12], bl
    cinvoke printf, fmt, dword [buf12]
    mov word [buf13], bx
    cinvoke printf, fmt, dword [buf13]
    mov dword [buf14], ebx
    cinvoke printf, fmt, dword [buf14]
    ret
endp
    
proc test40 uses ebx
    mov ebx, 0x12345678
    mov byte [buf41], bh
    cinvoke printf, fmt, [buf41]
    mov byte [buf42], bl
    cinvoke printf, fmt, [buf42]
    mov word [buf43], bx
    cinvoke printf, fmt, [buf43]
    mov [buf44], ebx
    cinvoke printf, fmt, [buf44]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
