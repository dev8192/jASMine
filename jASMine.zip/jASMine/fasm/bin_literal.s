include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_x, 1010_1011_1100_1101_1110_1111b
   ;cinvoke printf, fmt_x, 0b1010_1011_1100_1101_1110_1111
    ret
endp

include 'boilerplate/footer.inc'
