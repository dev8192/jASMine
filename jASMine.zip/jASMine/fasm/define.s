include 'compiler/header.x86.inc'

num1 = 1
if ~ defined guard
    define guard 1
    num1 = 5
end if
if ~ defined guard
    define guard 1
    num1 = 10
end if

proc main
    print_s '*** main1 ***'
    print_d num1
    ret
endp

include 'compiler/footer.inc'
