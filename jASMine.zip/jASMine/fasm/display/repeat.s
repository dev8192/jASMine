
macro main1 {
    display '*** main1 ***', 10
    repeat 3
        display 'hello', 10
    end repeat
}

macro main11 {
    display '*** main11 ***', 10
    repeat 5
        display '0' + %, ' '
    end repeat
}

macro main {
    display '*** main2 ***', 10
    repeat 3
        repeat 5
            display '0' + %, ' '
        end repeat
        display 10
    end repeat
}

macro main3 {
    display '*** main3 ***', 10
    str1 equ 'hello'
    str2 equ 'world'
    display str1, ' ', str2
}

macro main4 {
    display '*** main4 ***', 10
    current = 0
    repeat 26
        display 'a' + current
        current = current + 1
    end repeat
}

macro main4 {
    display '*** main4 ***', 10
    current = 0
    repeat 16
        if current < 10
            digit = '0' + current
        else
            digit = 'A' + (current - 10)
        end if
        display digit
        current = current + 1
    end repeat
}

main
