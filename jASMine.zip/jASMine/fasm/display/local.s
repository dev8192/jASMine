
num1 = 'a'

macro main {
    display num1, 10
    local num1
    num1 = 'b'
    display num1, 10
}

display num1, 10
main
display num1, 10
