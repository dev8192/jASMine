
macro main1 {
    display '*** main1 ***', 10
    local num1
    num1 = 18446744073709551615
    num2 = 0xFFFFFFFFFFFFFFFF
}

macro main11 {
    display '*** main11 ***', 10
    local num1
    num1 = 0x12345678
    repeat 8
    display '0' + num1 and 0xF, ' '
    num1 = num1 shr 4
    end repeat
}

macro main {
    display '*** main12 ***', 10
    local num1
    num1 = 0x12345678
    count = 0
    repeat 8
    display '0' + ((num1 shr count) and 0xF), ' '
    count = count + 4
    end repeat
}

macro add result, num1, num2 {
    result = num1 + num2
}

macro main2 {
    display '*** main2 ***', 10
    local num1
    num1 = 18446744073709551615
    num2 = 0xFFFFFFFFFFFFFFFF
    num1 = 'a'
    add num1, 0x30, 5
    display num1, 10
}

main
