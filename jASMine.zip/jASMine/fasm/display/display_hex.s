include 'display_hex.inc'

display_hex 0x12345678
display 10
display_hex 0xABCD
