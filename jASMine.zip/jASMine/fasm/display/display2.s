display 'one', 10
display 'two', 10
display 'three', 10
display 0x31, 0x32, 0x33, 10
; display 0x100, 10 ; value out of range

result = 0x30 + 5
display 'result: ', result, 10
