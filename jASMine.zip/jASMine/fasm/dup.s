include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    locals
        buf1        db 3 dup (0x11)
        buf1_len    = $ - buf1
        buf2        dw 3 dup (0x22)
        buf2_len    = $ - buf2
        buf3        dd 3 dup (0x33)
        buf3_len    = $ - buf3
    endl
    stdcall print_bytes, addr buf1, buf1_len
    stdcall print_bytes, addr buf2, buf2_len
    stdcall print_bytes, addr buf3, buf3_len
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    locals
        buf1        db 3 dup('a'), 3 dup('b'), 3 dup('c'), 0
        buf1_len    = $ - buf1
    endl
    print_d buf1_len
    print_s addr buf1
    stdcall print_bytes, addr buf1, buf1_len
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    stdcall main3_1
    stdcall main3_2
    stdcall main3_3
    ret
endp

proc main3_1
    locals
        buf1        db 8 dup (0x69)
        buf1_len    = $ - buf1
    endl
    stdcall print_bytes, addr buf1, buf1_len
    ret
endp

proc main3_2
    locals
        buf1        db 8 dup (?)
        buf1_len    = $ - buf1
    endl
    stdcall print_bytes, addr buf1, buf1_len
    ret
endp

proc main3_3
    locals
        buf1        rb 8
        buf1_len    = $ - buf1
    endl
    stdcall print_bytes, addr buf1, buf1_len
    ret
endp

include 'compiler/footer.inc'
