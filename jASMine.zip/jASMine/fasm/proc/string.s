format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    addr1   = $
    str1    db 'abcd1234', 0
    fmt     db '%x %s %x %x', 10, 0
    fmt_hex db '%x', 10, 0

; ------------------------------------------------------------------------------
; 401000
; 401000 abcd1234 64636261 34333231
; 401000 abcd1234 64636261 34333231
; ------------------------------------------------------------------------------
section '.text' code readable executable
start:
    cinvoke printf, fmt_hex, addr1
    cinvoke printf, fmt, str1, str1, dword [str1], dword [str1 + 4]
    mov     eax, str1
    cinvoke printf, fmt, eax, eax, [eax], [eax + 4]
    stdcall test10, str1
    invoke ExitProcess, 0

proc test10, str_ptr
    mov     eax, [str_ptr]
    cinvoke printf, fmt, eax, eax, [eax], [eax + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
