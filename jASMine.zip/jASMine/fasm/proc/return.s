format PE
entry start

include 'compiler_old.inc'
include 'win32ax.inc'

section '.data' data readable writeable
    num1        dd ?

include 'util/format.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0
    
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall .func
    cinvoke printf, fmt_d, eax
    ret
endp
    
proc .func
    mov eax, 10
    ret
endp
    
proc main
    cinvoke puts, '*** main2 ***'
    mov [num1], 0x55
    stdcall .func, num1
    ret
endp
    
proc .func, num
    cinvoke printf, fmt_x, [num]
    mov eax, [num]
    cinvoke printf, fmt_x, [eax]
    ret
endp
    
proc main3
    cinvoke puts, '*** main3 ***'
    stdcall .func, num1
    cinvoke printf, fmt_d, [num1]
    ret
endp
    
proc .func, num
    mov eax, [num]
    mov dword [eax], 30
    ret
endp

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
