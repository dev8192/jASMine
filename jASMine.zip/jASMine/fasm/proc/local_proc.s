format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
fmt:
    .rectangle  db 'rectangle', 10, 0
    .circle     db 'circle', 10, 0

section '.text' code readable executable
start:
    stdcall rectangle.draw
    stdcall cirlce.draw
    invoke ExitProcess, 0

rectangle:
proc .draw
    cinvoke printf, fmt.rectangle
    ret
endp

cirlce:
proc .draw
    cinvoke printf, fmt.circle
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
