format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1        db 'hello', 0
    str2        db 'goodbye', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_hello
    cinvoke puts, str1
    ret
endp

;proc print_hello
;    cinvoke puts, str2
;    ret
;endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_hello
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
