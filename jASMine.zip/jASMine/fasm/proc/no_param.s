include 'boilerplate/header.x86.inc'
include 'util/introspect.text.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall main1_1
    cinvoke printf, fmt_x, eax
    stdcall main1_2
    cinvoke printf, fmt_x, eax
    ret
endp

proc main1_1
    mov eax, 0x11
    ret
endp

main1_2:
    mov eax, 0x12
    ret

proc main
    cinvoke puts, '*** main2 ***'
    stdcall introspect, main1_1, main1_2
    stdcall introspect, main1_2, main
    ret
endp

include 'boilerplate/footer.inc'
