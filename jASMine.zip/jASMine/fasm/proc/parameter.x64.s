include 'boilerplate/header.x64.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    push 0x88
    push 0x77
    push 0x66
    push 0x55
    add rsp, 32
    stdcall .func, 0x11, 0x22, 0x33, 0x44
    ret
endp

proc .func, p1, p2, p3, p4
    cinvoke printf, fmt_4x, [p1], [p2], [p3], [p4]
    ret
endp

proc .func2, p1, p2, p3, p4
    mov [p1], rcx
    mov [p2], rdx
    mov [p3], r8
    mov [p4], r9
    cinvoke printf, fmt_4x, [p1], [p2], [p3], [p4]
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    mov rax, rsp
    cinvoke printf, fmt_x, rax
    stdcall .func, 0
    ret
endp

proc .func, p1
    cinvoke printf, fmt_x, addr p1
    ret
endp

include 'boilerplate/footer.inc'
