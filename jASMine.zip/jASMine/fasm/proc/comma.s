format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    stdcall .func1, 1
    stdcall .func2, 2
    stdcall .func3, 3
   ;stdcall .func4, 4
    ret
endp

proc .func1, num
    cinvoke printf, fmt_d, [num]
    ret
endp
    
proc .func2 num
    cinvoke printf, fmt_d, [num]
    ret
endp

proc .func3 uses ebx, num
    cinvoke printf, fmt_d, [num]
    ret
endp

;proc .func4 uses ebx num
;    cinvoke printf, fmt_d, [num]
;    ret
;endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
