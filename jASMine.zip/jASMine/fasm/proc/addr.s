format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_main        db 'main: %x', 10, 0
    fmt_func1       db 'func1: %x', 10, 0
    fmt_func2       db 'func2: %x', 10, 0
    fmt_x           db '%x', 10, 0
    fmt_d           db '%d', 10, 0
    fmt_2x          db '%x %x', 10, 0
    num1            dd 123

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_main, esp
    stdcall .func1, 5, 10, 15
    cinvoke printf, fmt_main, esp
    stdcall .func2, 5, 10, 15
    cinvoke printf, fmt_main, esp
    ret
endp

proc .func1 p1, p2, p3
    cinvoke printf, fmt_func1, addr p1
    cinvoke printf, fmt_func1, addr p2
    cinvoke printf, fmt_func1, addr p3
    ret
endp

proc .func2 p1, p2, p3
    lea eax, [p1]
    cinvoke printf, fmt_func2, eax
    lea eax, [p2]
    cinvoke printf, fmt_func2, eax
    lea eax, [p3]
    cinvoke printf, fmt_func2, eax
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, num1
    cinvoke printf, fmt_x, addr num1
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    local num:DWORD
    mov [num], 123
    cinvoke printf, fmt_d, [num]
    stdcall increment, addr num
    cinvoke printf, fmt_d, [num]
    ret
endp

proc increment, num
    mov eax, [num]
    mov ecx, [eax]
    inc ecx
    mov [eax], ecx
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    local num:DWORD
    cinvoke printf, fmt_x, addr num
    mov edx, 0x12345678
    stdcall .func, edx, edx
    mov edx, 0x12345678
    stdcall .func, edx, addr num
    mov edx, 0x12345678
    stdcall .func, addr num, edx
    ret
endp

proc .func, num1, num2
    cinvoke printf, fmt_2x, [num1], [num1]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
