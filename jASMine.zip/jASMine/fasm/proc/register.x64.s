include 'boilerplate/header.x64.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    mov rdx, 0x33
    cinvoke printf, fmt_3x, 0x11, 0x22, rdx
    mov r8, 0x33
    cinvoke printf, fmt_3x, 0x11, 0x22, r8
    mov r9, 0x33
    cinvoke printf, fmt_3x, 0x11, 0x22, r9
    mov r10, 0x33
    cinvoke printf, fmt_3x, 0x11, 0x22, r10
    mov r11, 0x33
    cinvoke printf, fmt_3x, 0x11, 0x22, r11
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    push 0x88
    push 0x77
    push 0x66
    push 0x55
    add rsp, 32
    stdcall .func, 0x11, 0x22, 0x33, 0x44
    ret
endp

proc .func1, p1, p2, p3, p4
    cinvoke printf, fmt_4x, [p1], [p2], [p3], [p4]
    ret
endp

proc .func, p1, p2, p3, p4
    mov [p1], rcx
    mov [p2], rdx
    mov [p3], r8
    mov [p4], r9
    cinvoke printf, fmt_4x, [p1], [p2], [p3], [p4]
    ret
endp

include 'boilerplate/footer.inc'
