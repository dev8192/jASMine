include 'boilerplate/header.x86.inc'
include 'util/introspect.text.x86.inc'

proc main uses ebx esi edi
    cinvoke puts, '*** main1 ***'
    mov ebx, 111
    mov esi, 222
    mov edi, 333
   ;call main1_1
    cinvoke printf, fmt_3d, ebx, esi, edi
    call main1_2
    cinvoke printf, fmt_3d, ebx, esi, edi
    call main1_3
    cinvoke printf, fmt_3d, ebx, esi, edi
    call main1_4
    cinvoke printf, fmt_3d, ebx, esi, edi
    call main1_5
    cinvoke printf, fmt_3d, ebx, esi, edi
    ret
endp

proc main1_1
    mov ebx, 0
    mov esi, 0
    mov edi, 0
    ret
endp

proc main1_2
    push ebx        ; 53
    push esi        ; 56
    push edi        ; 57
    mov ebx, 0      ; BB 00 00 00 00
    mov esi, 0      ; BE 00 00 00 00
    mov edi, 0      ; BF 00 00 00 00
    pop edi         ; 5F
    pop esi         ; 5E
    pop ebx         ; 5B
    ret             ; C3
endp                   

proc main1_3
    push ebx esi edi
    mov ebx, 0
    mov esi, 0
    mov edi, 0
    pop edi esi ebx
    ret
endp

main1_4:
    push ebx esi edi
    mov ebx, 0
    mov esi, 0
    mov edi, 0
    pop edi esi ebx
    ret

proc main1_5 uses ebx esi edi
    mov ebx, 0
    mov esi, 0
    mov edi, 0
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall introspect, main1_2, main1_3
    stdcall introspect, main1_3, main1_4
    stdcall introspect, main1_4, main1_5
    stdcall introspect, main1_5, main
    ret
endp

include 'boilerplate/footer.inc'
