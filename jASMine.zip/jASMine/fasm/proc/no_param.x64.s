include 'boilerplate/header.x64.inc'
include 'util/introspect.text.x64.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall main1_1
    cinvoke printf, fmt_x, eax
    stdcall main1_2
    cinvoke printf, fmt_x, eax
    ret
endp

proc main1_1
    mov eax, 0x11
    ret
endp

main1_2:
    push rbp        ; 55
    mov rbp, rsp    ; 48 89 E5
    mov eax, 0x11   ; B8 11 00 00 00
    leave           ; C9
    ret             ; C3

proc main
    cinvoke puts, '*** main2 ***'
    stdcall introspect, main1_1, main1_2
    stdcall introspect, main1_2, main
    ret
endp

include 'boilerplate/footer.inc'
