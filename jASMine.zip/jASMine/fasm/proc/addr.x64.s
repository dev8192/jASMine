include 'boilerplate/header.x64.inc'
include 'util/introspect.text.x64.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local num1:QWORD, num2:QWORD, num3:QWORD, num4:QWORD
    mov [num1], 0x11
    mov [num2], 0x22
    mov [num3], 0x33
    mov [num4], 0x44
.introspect_1:
    stdcall .func, addr num1, addr num2, addr num3, addr num4
.introspect_2:
    sub rsp, 32             ; 48 83 EC 20      
    lea rcx, [rbp - 32]     ; 48 8D 4D E0      
    lea rdx, [rbp - 24]     ; 48 8D 55 E8      
    lea r8, [rbp - 16]      ; 4C 8D 45 F0      
    lea r9, [rbp - 8]       ; 4C 8D 4D F8      
    call .func              ; E8 06 00 00 00   
    add rsp, 32             ; 48 83 C4 20      
.introspect_3:
    ret
endp

proc .func, p1, p2, p3, p4
    mov [p1], rcx
    mov [p2], rdx
    mov [p3], r8
    mov [p4], r9
    mov rax, [p1]
    cinvoke printf, fmt_x, qword [rax]
    mov rax, [p2]
    cinvoke printf, fmt_x, qword [rax]
    mov rax, [p3]
    cinvoke printf, fmt_x, qword [rax]
    mov rax, [p4]
    cinvoke printf, fmt_x, qword [rax]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    dummy = main1
    stdcall introspect, main1.introspect_1, main1.introspect_2
    stdcall introspect, main1.introspect_2, main1.introspect_3
    ret
endp

include 'boilerplate/footer.inc'
