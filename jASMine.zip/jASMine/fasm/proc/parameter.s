format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_2x      db '%x %x', 10, 0
    fmt_3x      db '%x %x %x', 10, 0
    fmt_f       db '%f', 10, 0
    fmt_llu     db '%llu', 10, 0
    fmt_3d      db '%d %d %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall .func, 0x1234, 0x5678
    stdcall .func, 0x12345678, 0x12345678
endp

proc .func, p1:WORD, p2:WORD
    movzx eax, [p1]
    movzx ecx, [p2]
    cinvoke printf, fmt_2x, eax, ecx
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall .func, 0x12, 0xAA
    stdcall .func, 0x1234, 0xAABB
    stdcall .func, 0x12345678, 0xAABBCCDD
endp

proc .func, p1:BYTE, p2:BYTE
    movzx eax, [p1]
    movzx ecx, [p2]
    cinvoke printf, fmt_2x, eax, ecx
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    locals
        num1 dq 11.5
        num2 dq -1
    endl
    stdcall .func1, double [num1]
    stdcall .func2, double [num2]
    ret
endp

proc .func1 num:QWORD
    cinvoke printf, fmt_f, double [num]
    ret
endp

proc .func2 num:QWORD
    cinvoke printf, fmt_llu, double [num]
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    cinvoke printf, fmt_x, esp
    stdcall .func1, 0x123, 0x456, 0x789
    stdcall .func2, 0x123, 0x456, 0x789
    ret
endp

proc .func1, num1, num2, num3
    mov eax, [num1]
    mov ecx, [num2]
    mov edx, [num3]
    cinvoke printf, fmt_3x, eax, ecx, edx
    ret
endp

proc .func2, num1, num2, num3
    lea eax, [num1]
    lea ecx, [num2]
    lea edx, [num3]
    cinvoke printf, fmt_3x, eax, ecx, edx
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    cinvoke printf, fmt_x, esp
    stdcall .func, 0x123, 0x456, 0x789
    ret
endp

proc .func, num1, num2, num3
    cinvoke printf, fmt_3x, [num1], [num2], [num3]
    inc [num1]
    inc [num2]
    inc [num3]
    cinvoke printf, fmt_3x, [num1], [num2], [num3]
    ret
endp

;       64 68 6c 70 74
; func1          ** **
; func2    **       **
; func3 **          **
proc main
    cinvoke puts, '*** main6 ***'
    cinvoke printf, fmt_x, esp
    stdcall .func1
    cinvoke printf, fmt_x, esp
    stdcall .func2, 5.25
    cinvoke printf, fmt_x, esp
    stdcall .func3, double 5.25
    cinvoke printf, fmt_x, esp
    ret
endp

proc .func1
    cinvoke printf, fmt_x, esp
    ret
endp

proc .func2, num
    cinvoke printf, fmt_x, esp
    ret
endp

proc .func3, num:QWORD
    cinvoke printf, fmt_x, esp
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
