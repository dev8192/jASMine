format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt0        db 'fmt0: %x', 10, 0
    fmt1        db 'fmt1: %x', 10, 0
    fmt2        db 'fmt2: %x', 10, 0
    fmt3        db 'fmt3: %u', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt0, esp
    stdcall test11, 5, 10, 15
    cinvoke printf, fmt0, esp
    stdcall test12
    cinvoke printf, fmt0, esp
    invoke ExitProcess, 0

proc test11 p1, p2, p3
    cinvoke printf, fmt1, addr p1
    cinvoke printf, fmt1, addr p2
    cinvoke printf, fmt1, addr p3
    stdcall test2, addr p1, addr p2, addr p3
    stdcall test3, [p1], [p2], [p3]
    ret
endp

proc test12
    local p1:DWORD, p2:DWORD, p3:DWORD
    mov [p1], 5
    mov [p2], 10
    mov [p3], 15
    cinvoke printf, fmt1, addr p1
    cinvoke printf, fmt1, addr p2
    cinvoke printf, fmt1, addr p3
    stdcall test2, addr p1, addr p2, addr p3
    stdcall test3, [p1], [p2], [p3]
    ret
endp

proc test2 p1, p2, p3
    cinvoke printf, fmt2, [p1]
    cinvoke printf, fmt2, [p2]
    cinvoke printf, fmt2, [p3]
    ret
endp

proc test3 p1, p2, p3
    cinvoke printf, fmt3, [p1]
    cinvoke printf, fmt3, [p2]
    cinvoke printf, fmt3, [p3]
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'
    import  kernel32,\
            ExitProcess, 'ExitProcess'
    import  msvcrt,\
            printf, 'printf'
