include 'boilerplate/header.x64.inc'

proc main
    cinvoke puts, '*** main1 ***'
   ;dummy = main1_1
   ;cinvoke printf, fmt_x, main1_1.print_num
    cinvoke printf, fmt_x, addr_before
    cinvoke printf, fmt_x, addr_after
    ret
endp

addr_before = $
proc main1_1
.print_num:
    cinvoke printf, fmt_x, 255
    ret
endp
addr_after = $

include 'boilerplate/footer.inc'
