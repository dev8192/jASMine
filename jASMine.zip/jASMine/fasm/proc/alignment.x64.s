include 'boilerplate/header.x64.inc'

proc print_rsp1
    mov rax, rsp
    cinvoke printf, fmt_x, rax
    ret
endp

print_rsp2:
    mov rax, rsp
    cinvoke printf, fmt_x, rax
    ret

proc main
    cinvoke puts, '*** main1 ***'
;                             b8 c0 c8
    stdcall print_rsp1      ;    **
    stdcall print_rsp2      ;       **
    sub rsp, 8
    stdcall print_rsp1      ; **
    stdcall print_rsp2      ;    **
    add rsp, 8
    ret
endp

include 'boilerplate/footer.inc'
