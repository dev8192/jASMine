format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt     db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    cinvoke printf, fmt, .example1
    cinvoke printf, fmt, .example2
    cinvoke printf, fmt, .example3
    cinvoke printf, fmt, .example4
    cinvoke printf, fmt, .example5
    ret
endp

.example1:
proc .example2
.example3:
    ret
.example4:
endp
.example5:

proc test20
    stdcall .test_inc, 100
    stdcall .test_add, 100
    stdcall .test_shift, 100
    stdcall .test_div, 100
    ret
endp

proc .test_inc, num
    cinvoke printf, fmt, [num]
    inc     [num]
    cinvoke printf, fmt, [num]
    inc     [num]
    cinvoke printf, fmt, [num]
    ret
endp
    
proc .test_add, num
    cinvoke printf, fmt, [num]
    add     [num], 10
    cinvoke printf, fmt, [num]
    add     [num], 10
    cinvoke printf, fmt, [num]
    ret
endp
    
proc .test_shift, num
    cinvoke printf, fmt, [num]
    shl     [num], 1
    cinvoke printf, fmt, [num]
    shr     [num], 1
    cinvoke printf, fmt, [num]
    ret
endp
    
proc .test_div1, num
    cinvoke printf, fmt, [num]
    mov     eax, [num]
    xor     edx, edx
    mov     ecx, 5
    div     ecx
    mov     [num], eax
    cinvoke printf, fmt, [num]
    mov     eax, [num]
    xor     edx, edx
    mov     ecx, 5
    div     ecx
    mov     [num], eax
    cinvoke printf, fmt, [num]
    ret
endp

proc .test_div, num
    cinvoke printf, fmt, [num]
    mov     eax, [num]
    mov     cl, 5
    div     cl
    movzx   eax, al
    mov     [num], eax
    cinvoke printf, fmt, [num]
    mov     eax, [num]
    mov     cl, 5
    div     cl
    movzx   eax, al
    mov     [num], eax
    cinvoke printf, fmt, [num]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
