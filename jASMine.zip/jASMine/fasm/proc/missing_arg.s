format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    num1        dq -1
    num2        dq 18049604360605696
    fmt_x       db '%x', 10, 0
    fmt_llu     db '%llu', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
exit:
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_llu, num1                           ; 18049604360605696
    cinvoke printf, fmt_llu, num1, exit                     ; 18049604360605696
    cinvoke printf, fmt_llu, dword [num2], dword [num2 + 4] ; 18049604360605696
    cinvoke printf, fmt_x, num1                             ; 401000
    cinvoke printf, fmt_x, exit                             ; 402005
    stdcall print_bytes, num2, 8                            ; 00 10 40 00 05 20 40 00 
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
