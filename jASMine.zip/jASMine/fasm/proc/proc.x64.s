format PE64

include 'compiler_old.inc'
include 'win64ax.inc'

stdcall main
invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    fastcall .func, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66
    ret
endp

proc .func, arg1, arg2, arg3, arg4, arg5, arg6
    mov [arg1], rcx
    mov [arg2], rdx
    mov [arg3], r8
    mov [arg4], r9
    cinvoke printf, fmt_x, [arg1]
    cinvoke printf, fmt_x, [arg2]
    cinvoke printf, fmt_x, [arg3]
    cinvoke printf, fmt_x, [arg4]
    cinvoke printf, fmt_x, [arg5]
    cinvoke printf, fmt_x, [arg6]
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, rsp
    invoke printf, fmt_x, 0x12345678
    cinvoke printf, fmt_x, rsp
    ret
endp

.data
include 'util/format.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
