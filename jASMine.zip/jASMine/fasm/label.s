include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke puts, alphabet
    cinvoke puts, alphabet + 23
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    mov ebx, 'a'
.loop:
    cinvoke printf, fmt_c0, ebx
    inc ebx
    cmp ebx, 'c'
    jbe .loop
    cinvoke printf, newline
    ret
endp

proc main3 uses ebx
    cinvoke puts, '*** main3 ***'
    mov ebx, 1
@@:
    cmp ebx, 5
    ja @f
    cinvoke printf, fmt_d, ebx
    inc ebx
    jmp @b
@@:
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    cinvoke puts, lowercase.one
    cinvoke puts, lowercase.two
    cinvoke puts, lowercase.three
    cinvoke puts, uppercase.one
    cinvoke puts, uppercase.two
    cinvoke puts, uppercase.three
    ret
endp

proc main
    cinvoke puts, '*** main5 ***'
    stdcall main5_1
    stdcall main5_2
    ret
endp

proc main5_1
    cinvoke puts, .str
    cinvoke puts, main5_2.str
    ret
.str db 'main5_1', 0
endp

proc main5_2
    cinvoke puts, main5_1.str
    cinvoke puts, .str
    ret
.str db 'main5_2', 0
endp

include 'compiler/footer_data.inc'
include 'util/alphabet.data.inc'

lowercase:
.one    db 'one', 0
.two    db 'two', 0
.three  db 'three', 0

uppercase:
.one    db 'ONE', 0
.two    db 'TWO', 0
.three  db 'THREE', 0

include 'compiler/footer_idata.inc'
