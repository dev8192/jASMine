include 'boilerplate/header.x86.inc'

proc print_message, msg
    cinvoke printf, fmt, [msg]
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall .func, print_message, str1
    stdcall .func, print_message, str2
    ret
endp
    
proc .func, callback, msg
    cinvoke printf, fmt_x, esp
    stdcall [callback], [msg]
    cinvoke printf, fmt_x, esp
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall .func, [puts], str1
    stdcall .func, [puts], str2
    ret
endp
    
proc .func, callback, msg
    cinvoke printf, fmt_x, esp
    cinvoke callback, [msg]
    cinvoke printf, fmt_x, esp
    ret
endp

; Default callback
proc main3
    cinvoke puts, '*** main3 ***'
    stdcall .func, print_message
    stdcall .func, 0
    ret
endp
    
proc .func, callback
    cmp [callback], 0
    jz .def_callback
    stdcall [callback], str1
    jmp .done
.def_callback:
    cinvoke puts, 'test30 (default)'
.done:
    ret
endp

.data
include 'util/format.data.inc'
fmt     db '%s (print_message)', 10, 0
str1    db 'str1', 0
str2    db 'str2', 0

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
