include 'boilerplate/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    repeat 3
        cinvoke printf, fmt_d, %
    end repeat
    cinvoke puts, 'done'
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    repeat 3
        if % > 1
            cinvoke printf, fmt_d, %
        end if
    end repeat
    cinvoke puts, 'done'
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    cinvoke printf, 'Compiled at Unix timestamp: '
    cinvoke printf, fmt_u, %t
    cinvoke puts, 'done'
    ret
endp

include 'boilerplate/footer.inc'
