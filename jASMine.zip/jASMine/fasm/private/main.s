include 'compiler/header.x86.inc'
include 'module.text.inc'

proc main
    print_s '*** main1 ***'
    stdcall module__print_number, 333
    ret
endp

include 'compiler/footer.inc'
