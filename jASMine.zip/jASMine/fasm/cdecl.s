include 'boilerplate/header.x86.inc'
include 'util/introspection.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    jmp .intro_end
.intro1:
    cinvoke printf, fmt_d, 1
.intro2:
    push 1              ; 6A 01
    push fmt_d          ; 68 1A 20 40 00
    call [printf]       ; FF 15 84 30 40 00
    add esp, 8          ; 83 C4 08
.intro_end:
    introspect2
    ret
endp

include 'boilerplate/footer.inc'
