format binary

db 'hello', 10
