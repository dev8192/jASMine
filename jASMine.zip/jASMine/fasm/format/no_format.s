db 'example 1', 10
