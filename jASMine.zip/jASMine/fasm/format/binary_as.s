format binary as 'txt'

db 'hello', 10
