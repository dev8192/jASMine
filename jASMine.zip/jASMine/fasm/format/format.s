;format PE
format PE gui
;format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    class_name db 'ExampleWindow', 0
    wc WNDCLASS
    msg MSG
    fmt db 'hello', 10, 0

section '.text' code readable executable
start:
    cinvoke printf, fmt
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.lpszClassName], class_name
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    invoke RegisterClass, wc

    invoke CreateWindowEx, 0, class_name, class_name,\
        WS_VISIBLE + WS_OVERLAPPEDWINDOW,\
        CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT, CW_USEDEFAULT,\
        0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jle end_loop
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            DefWindowProc,      'DefWindowProcA',\
            GetMessage,         'GetMessageA',\
            DispatchMessage,    'DispatchMessageA',\
            LoadCursor,         'LoadCursorA',\
            PostQuitMessage,    'PostQuitMessage'
    import  msvcrt,\
            printf,             'printf'
