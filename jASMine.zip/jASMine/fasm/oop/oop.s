include 'compiler/header.x86.inc'
include 'shape.text.inc'
include 'square.text.inc'
include 'circle.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local square:SQUARE, circle:CIRCLE
    stdcall SQUARE.construct, addr square, 5
    stdcall SHAPE.print_info, addr square
    stdcall CIRCLE.construct, addr circle, 5
    stdcall SHAPE.print_info, addr circle
    ret
endp

include 'compiler/footer_data.inc'
include 'square.data.inc'
include 'circle.data.inc'
include 'compiler/footer_idata.inc'
