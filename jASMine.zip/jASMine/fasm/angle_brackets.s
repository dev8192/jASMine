include 'compiler/header.x86.inc'
include 'util/line.inc'
include 'util/introspection.inc'
include 'util/introspection_v2.inc'
include 'util/introspection.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall main1_1, 0
    stdcall main1_1, 1
    ret
endp

proc main1_1 intro_flag
    cmp [intro_flag], 1
    je .do_introspection
.intro1:
    cinvoke printf, <'%d + %d = %d', 10>, 5, 1, 6
   ;cinvoke printf, <'%d + %d = %d', 10>, 5, 1, 6
.intro2:
    push 6                      ; 6A 06
    push 1                      ; 6A 01
    push 5                      ; 6A 05
    call @f                     ; E8 0E 00 00 00
    db '%d + %d = %d', 10, 0    ; 25 64 20 2B 20 25 64 20 3D 20 25 64 0A 00
@@:
    call dword [printf]         ; FF 15 84 30 40 00
    add esp, 16                 ; 83 C4 10
.intro_end:
    jmp .finish
.do_introspection:
    introspect2
.finish:
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    print_4d [line1.pt1.x], [line1.pt1.y], [line1.pt2.x], [line1.pt2.y]
    ret
endp

include 'compiler/footer_data.inc'
line1 LINE <10, 20>, <30, 40>
;line1 LINE 10, 20, 30, 40
include 'compiler/footer_idata.inc'
