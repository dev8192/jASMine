
macro main1 {
    display '*** main1 ***', 10
    define msg_id 1
    match =1, msg_id \{ msg equ 'one' \}
    match =2, msg_id \{ msg equ 'two' \}
    display msg
}

macro main2 {
    display '*** main2 ***', 10
    define msg_id 1
    match =1, msg_id \{
        display 'msg1', 10
    \}
    match =2, msg_id \{
        display 'msg2', 10
    \}
    display 'done'
}

macro main3 {
    display '*** main3 ***', 10
    match +,+ \{ display '++', 10 \}
    match +,- \{ display '+-', 10 \}
    display 'done'
}

macro main4 {
    display '*** main4 ***', 10
    match w1-w2, 97-'bc' \{
        display w1, w2, 10
    \}
    display 'done'
}

macro main {
    display '*** main5 ***', 10
   ;regs equ 1
    match =regs, regs \{ display 'hello', 10 \}
    display 'done'
}

main
