
macro main1 {
    macro parse input \{
        match first:second, input \\{
            display 'First part: ', first, 10
            display 'Second part: ', second, 10
        \\}
    \}
    parse 'hello':'world'
}

macro main {
    macro smart_mov destination, source \{
        match [address], source \\{
            display 'match1', 10
        \\}
        match value, source \\{
            display 'match2', 10
        \\}
    \}
    smart_mov ebx, [eax]
    smart_mov ebx, ecx
}

main
