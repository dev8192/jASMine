include 'boilerplate/header.x86.inc'

number = 111
NUMBER = 222

proc main
    cinvoke puts, '*** main1 ***'
    locals
        num dd 333
        Num dd 444
    endl
    print_d number
    print_d NUMBER
    print_d [num]
    print_d [Num]
    ret
endp

include 'boilerplate/footer.inc'
