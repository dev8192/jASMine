include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall .func, 0
    ret
endp

proc .func dummy
    cinvoke puts, '*** main1 ***'
    invoke printf, fmt_x, esp
    invoke printf, fmt_x, esp
    invoke printf, fmt_x, esp
    ret
endp

include 'boilerplate/footer.inc'
