include 'boilerplate/header.x86.inc'

; HELLO = 1
; HELLO equ 1
; c:/fasm/fasm.exe -d HELLO=1 fasm/defined.s prog.exe
; c:/fasm/fasm.exe -d hello=1 fasm/defined.s prog.exe ; not working
proc main
    cinvoke puts, '*** main1 ***'
    if defined HELLO
        cinvoke printf, fmt_x, 0x12345678
    end if
    ret
endp

include 'boilerplate/footer.inc'
