macro enum_start start_val, [name] {
  common
    local counter
    counter = start_val
  forward
    name = counter
    counter = counter + 1
}

; Usage:
enum_start 10, State_Idle, State_Running, State_Error
; State_Idle = 10, State_Running = 11, State_Error = 12
