
macro main1 {
    display '*** main1 ***', 10
    str1 equ 'one'
    str1 equ 'two'
    str1 equ 'three'
    irpv item, str1 \{
        display item, 10
       ;restore str1
    \}
    display 'and again:', 10
    irpv item, str1 \{
        display item, 10
    \}
    display 'done'
}

macro main2 {
    display '*** main2 ***', 10
    define str1, 'one'
    define str1, 'two'
    define str1, 'three'
    display str1, 10
    irpv item, str1 \{
       ;display 'hello', 10
    \}
    display 'done'
}

macro main {
    display '*** main3 ***', 10
    define str1, hello
    display `str1, 10
    display 'done'
}

main
