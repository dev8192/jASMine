format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt  db '%d', 10, 0

section '.text' code readable executable
test10:
    cinvoke puts, "*** test10 ***"
    mov eax, [esp+4]
    cinvoke printf, fmt, eax
    ret 4

test20:
    cinvoke puts, "*** test20 ***"
    mov eax, [esp+4]
    add eax, [esp+8]
    cinvoke printf, fmt, eax
    ret 8

test30:
    cinvoke puts, "*** test30 ***"
    mov eax, [esp+4]
    add eax, [esp+8]
    add eax, [esp+12]
    cinvoke printf, fmt, eax
    ret 12

start:
    stdcall test10, 10
    stdcall test20, 5, 15
    stdcall test30, 5, 10, 15

    cinvoke printf, fmt, eip

    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
