format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt  db '%d', 10, 0

section '.text' code readable executable

proc test1 p1
    cinvoke printf, fmt, [p1]
    ret
endp

proc test2 p1, p2
    mov eax, [p1]
    add eax, [p2]
    cinvoke printf, fmt, eax
    ret
endp

proc test3 p1, p2, p3
    mov eax, [p1]
    add eax, [p2]
    add eax, [p3]
    cinvoke printf, fmt, eax
    ret
endp

start:
    stdcall test1, 5
    stdcall test2, 5, 10
    stdcall test3, 5, 10, 15
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf'
