format PE
entry start

include 'win32a.inc'

OPTION1 = 11
OPTION2 = 22
OPTION3 = 33

section '.data' data readable writeable
    fmt1  db 'fmt1: %d', 10, 0
    fmt2  db 'fmt2: %d', 10, 0

section '.text' code readable executable

proc test1 opt
    cmp [opt], OPTION1
    je .option1
    cmp [opt], OPTION2
    je .option2
    cmp [opt], OPTION3
    je .option3
    cinvoke printf, fmt1, 0
    jmp .finish
.option1:
    cinvoke printf, fmt1, 111
    jmp .finish
.option2:
    cinvoke printf, fmt1, 222
    jmp .finish
.option3:
    cinvoke printf, fmt1, 333
.finish:
    ret
endp

proc test2 opt
    cmp [opt], OPTION1
    je .option1
    cmp [opt], OPTION2
    je .option2
    cmp [opt], OPTION3
    je .option3
    cinvoke printf, fmt2, 0
    ret
.option1:
    cinvoke printf, fmt2, 111
    ret
.option2:
    cinvoke printf, fmt2, 222
    ret
.option3:
    cinvoke printf, fmt2, 333
    ret
endp

start:
    stdcall test1, 11
    stdcall test1, 22
    stdcall test1, 33
    stdcall test1, 44
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'
    import kernel32,\
        ExitProcess, 'ExitProcess'
    import msvcrt,\
        printf, 'printf'
