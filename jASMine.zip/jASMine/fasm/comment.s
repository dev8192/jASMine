include 'boilerplate/header.x86.inc'

; single line comment

if 0

multiline comment

end if

proc main
    cinvoke puts, '*** main1 ***'
    ret
endp

include 'boilerplate/footer.inc'
