include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall print_bytes, str1, 4
    stdcall print_bytes, str2, 4
    stdcall print_bytes, str3, 4
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall main1_1
    stdcall main1_2
    stdcall main1_3
    ret
endp

proc main1_1
    local num:DWORD
    mov [num], 0x11223344
    ret
endp

proc main1_2
    local num:DWORD
    stdcall print_bytes, addr num, 4
    ret
endp

proc main1_3
    local num:DWORD
    mov [num], 'a'
    stdcall print_bytes, addr num, 4
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall main1_1, 0
    stdcall main1_1, 1
    ret
endp

proc main1_1 intro_flag
    cmp [intro_flag], 1
    je .do_introspection
.intro1:
    cinvoke printf, fmt_x, 0x12345678
.intro2:
    push 0x12345678     ; 68 78 56 34 12
    push fmt_x          ; 68 00 20 40 00
    call [printf]       ; FF 15 84 30 40 00
    add esp, 8          ; 83 C4 08
.intro_end:
    jmp .finish
.do_introspection:
    introspect2
.finish:
    ret
endp

include 'compiler/footer_data.inc'
str1 dd 'a'
str2 dd 'ab'
str3 dd 'abc'
include 'compiler/footer_idata.inc'
