include 'boilerplate/header.x64.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, f_3x, 0x0000000000000000,                    0,                    0
    cinvoke printf, f_3x, 0x0000000000000001,                    1,                    1
    cinvoke printf, f_3x, 0x0000000000000002,                    2,                    2
    cinvoke printf, f_3x, 0x7FFFFFFFFFFFFFFE,  9223372036854775806,  9223372036854775806
    cinvoke printf, f_3x, 0x7FFFFFFFFFFFFFFF,  9223372036854775807,  9223372036854775807
    cinvoke printf, f_3x, 0x8000000000000000,  9223372036854775808, -9223372036854775808
    cinvoke printf, f_3x, 0x8000000000000001,  9223372036854775809, -9223372036854775807
    cinvoke printf, f_3x, 0xFFFFFFFFFFFFFFFE, 18446744073709551614,                   -2
    cinvoke printf, f_3x, 0xFFFFFFFFFFFFFFFF, 18446744073709551615,                   -1
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, f_xud, 0x00000000_00000000, 0x00000000_00000000, 0x00000000_00000000
    cinvoke printf, f_xud, 0x00000000_00000001, 0x00000000_00000001, 0x00000000_00000001
    cinvoke printf, f_xud, 0x00000000_00000002, 0x00000000_00000002, 0x00000000_00000002
    cinvoke printf, f_xud, 0x7FFFFFFF_FFFFFFFE, 0x7FFFFFFF_FFFFFFFE, 0x7FFFFFFF_FFFFFFFE
    cinvoke printf, f_xud, 0x7FFFFFFF_FFFFFFFF, 0x7FFFFFFF_FFFFFFFF, 0x7FFFFFFF_FFFFFFFF
    cinvoke printf, f_xud, 0x80000000_00000000, 0x80000000_00000000, 0x80000000_00000000
    cinvoke printf, f_xud, 0x80000000_00000001, 0x80000000_00000001, 0x80000000_00000001
    cinvoke printf, f_xud, 0xFFFFFFFF_FFFFFFFE, 0xFFFFFFFF_FFFFFFFE, 0xFFFFFFFF_FFFFFFFE
    cinvoke printf, f_xud, 0xFFFFFFFF_FFFFFFFF, 0xFFFFFFFF_FFFFFFFF, 0xFFFFFFFF_FFFFFFFF
    ret
endp

include 'boilerplate/footer_data.inc'
f_3x      db '    cinvoke printf, f_xud, 0x%016llX, 0x%016llX, 0x%016llX', 10, 0
f_xud     db '    cinvoke printf, f_3x, 0x%016llX, %20llu, %20lld', 10, 0

include 'boilerplate/footer_idata.inc'
