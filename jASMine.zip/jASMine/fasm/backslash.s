include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_3d,\
        123, 456, 789
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_3d,\
       ;123, 456, 789
        111, 222, 333
    ret
endp

include 'compiler/footer.inc'
