include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_3x, [arr], [arr + 4], [arr + 8]
    cinvoke printf, fmt_3x, 0xA, 0Bh, $C
    mov eax, 0xA
    mov ecx, 0Bh
    mov edx, $C
    cinvoke printf, fmt_3x, eax, ecx, edx
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_2x, 11h, 011h
    FFh = 0AAh
    cinvoke printf, fmt_2x, FFh , 0FFh
    ret
endp

include 'boilerplate/footer_data.inc'
arr dd 0xA, 0Bh, $C

include 'boilerplate/footer_idata.inc'
