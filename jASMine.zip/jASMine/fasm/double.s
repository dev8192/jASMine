include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    locals
        num1 dq 0.123456
        num2 dq 18446744073709551615
    endl
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    cinvoke printf, fmt_f, double [num1]
    cinvoke printf, fmt_f, double 0.123456

    cinvoke printf, fmt_llu, dword [num2], dword [num2 + 4]
    cinvoke printf, fmt_llu, double [num2]
    cinvoke printf, fmt_llu, double -1
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, esp
    cinvoke printf, fmt_llu, double 123
    cinvoke printf, fmt_x, esp
    cinvoke printf, fmt_llu, 123, 0
    cinvoke printf, fmt_x, esp
    cinvoke printf, fmt_llu, 123
    cinvoke printf, fmt_x, esp
    cinvoke printf, fmt_llu, 123, 0x00401005
    cinvoke printf, fmt_x, esp

    cinvoke printf, fmt_x, dword [esp]

    ret
endp

include 'compiler/footer.inc'
