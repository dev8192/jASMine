include 'compiler/header.x86.inc'
include 'main.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall add_numbers, [arr], [arr + 4]
    print_d eax
    ret
endp

proc main2
   ;cinvoke puts, '*** main2 ***'
    stdcall main2_1
    stdcall main2_2
    stdcall main2_3
    ret
endp

proc main2_1
    cinvoke puts, '*** main2_1 ***'
    include 'print_number.inc'
    include 'print_number.inc'
    ret
endp

proc main2_2
    cinvoke puts, '*** main2_2 ***'
    repeat 2
        include 'print_number.inc'
    end repeat
    ret
endp

proc main2_3
    cinvoke puts, '*** main2_3 ***'
    rept 2 {
        include 'print_number.inc'
    }
    ret
endp

include 'compiler/footer_data.inc'
include 'main.data.inc'
include 'compiler/footer_idata.inc'
