include 'compiler/header.x86.inc'

num1 = 5
include 'include_guard.inc'
include 'include_guard.inc'

proc main
    print_s '*** main1 ***'
    print_d num1
    ret
endp

include 'compiler/footer.inc'
