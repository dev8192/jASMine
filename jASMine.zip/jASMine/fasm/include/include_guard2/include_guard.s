include 'compiler/header.x86.inc'
include 'include_guard1.inc'
include 'include_guard2.inc'

proc main
    print_s '*** main1 ***'
    mov eax, num1
    add eax, num2
    print_d eax
    ret
endp

include 'compiler/footer.inc'
