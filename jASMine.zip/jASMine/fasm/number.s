include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    print_3x 0x00000000,          0,           0
    print_3x 0x00000001,          1,           1
    print_3x 0x00000002,          2,           2
    print_3x 0x7FFFFFFE, 2147483646,  2147483646
    print_3x 0x7FFFFFFF, 2147483647,  2147483647
    print_3x 0x80000000, 2147483648, -2147483648
    print_3x 0x80000001, 2147483649, -2147483647
    print_3x 0xFFFFFFFE, 4294967294,          -2
    print_3x 0xFFFFFFFF, 4294967295,          -1
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    print_xud 0x00000000
    print_xud 0x00000001
    print_xud 0x00000002
    print_xud 0x7FFFFFFE
    print_xud 0x7FFFFFFF
    print_xud 0x80000000
    print_xud 0x80000001
    print_xud 0xFFFFFFFE
    print_xud 0xFFFFFFFF
    ret
endp

include 'compiler/footer.inc'
