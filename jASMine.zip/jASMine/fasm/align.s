include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    print_x num1
    print_x num2
    print_x num3
    print_x num4
    stdcall print_bytes, num1, size
    ret
endp

include 'compiler/footer_data.inc'
align 16
num1 rb 1
num2 rb 1
;align 4
;align 8
align 16
num3 rb 1
num4 rb 1
size = $ - num1

include 'compiler/footer_idata.inc'
