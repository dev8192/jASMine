include 'compiler/header.x86.inc'

macro print_number num { cinvoke printf, fmt_d, num }
macro print_number num { cinvoke printf, fmt_u, num }

proc main
    cinvoke puts, '*** main1 ***'
    print_number -1
    ret
endp

include 'compiler/footer.inc'
