
macro make_constants [name, value] {
    name = value
}
make_constants A, 10, B, 20, C, 30

letter_A = A + B + C + 5
display letter_A
