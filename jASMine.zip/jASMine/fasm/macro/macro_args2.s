
macro test [arg] {
common
    display 'test:'
    if ~ arg eq
        display ' hello'
    end if
    display 10
}

test
test 'one'
test 'one', 'two'
test 'one', 'two', 'three'
