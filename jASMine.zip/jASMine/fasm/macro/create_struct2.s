include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    print_3d [e1.field1], [e1.field2], [e1.field3]
    print_4d [e2.field1], [e2.field2], [e2.field3], [e2.field4]
    ret
endp

struct EXAMPLE1
    field1 dd ?
    field2 dd ?
    field3 dd ?
ends

struct EXAMPLE2
    field1 dd ?
    field2 dd ?
    field3 dd ?
    field4 dd ?
ends

macro create_var name, type, [arg] {
common
    define all
forward
    match any, all \{ define all all, arg \}
    match , all \{ define all arg \}
common
    match processed, all \{ name type processed \}
    restore all
}


include 'compiler/footer_data.inc'

create_var e1, EXAMPLE1, 10, 20, 30
create_var e2, EXAMPLE2, 10, 20, 30, 40

;e1 EXAMPLE1 10, 20, 30
;e2 EXAMPLE2 10, 20, 30, 40

include 'compiler/footer_idata.inc'
