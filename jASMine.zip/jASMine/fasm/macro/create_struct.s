include 'compiler/header.x86.inc'

macro create_struct name, [field, type] {
common
    struct name
forward
    field type ?
common
    ends
}

create_struct EXAMPLE,\
    field1, STRING,\
    field2, STRING

; struct EXAMPLE
;     field1 dd ?
;     field2 dd ?
; ends

proc main
    print_s '*** main1 ***'
    print_d sizeof.EXAMPLE
    print_s [example.field1.str]
    print_s [example.field2.str]
    ret
endp

include 'compiler/footer_data.inc'
str1 db 'hello', 0
str2 db 'world', 0
example EXAMPLE\
    <str1, 0>,\
    <str2, 0>

include 'compiler/footer_idata.inc'
