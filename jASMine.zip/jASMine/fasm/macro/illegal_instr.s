include 'boilerplate/header.x86.inc'

macro illegal_instr {
    This is an illegal instruction.
}

proc main
    cinvoke puts, '*** main1 ***'
   ;illegal_instr
    cinvoke puts, 'done'
    ret
endp

include 'boilerplate/footer.inc'
