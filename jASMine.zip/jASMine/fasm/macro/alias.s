
macro macro1 {
    display 'hello'
}
match func, macro1 { func }
