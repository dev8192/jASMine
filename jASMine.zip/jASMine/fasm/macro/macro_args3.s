format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_3d      db '%d %d %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

macro print [args] {
    common
    cinvoke printf, fmt_3d, args
}

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_3d, 5, 10, 15
    print 111, 222, 333
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
