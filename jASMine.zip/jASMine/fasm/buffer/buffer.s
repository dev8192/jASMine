include 'boilerplate/header.x86.inc'

proc populate_buffer p_buf
    mov eax, [p_buf]
    mov byte [eax + 0], 'h'
    mov byte [eax + 1], 'e'
    mov byte [eax + 2], 'l'
    mov byte [eax + 3], 'l'
    mov byte [eax + 4], 'o'
    mov byte [eax + 5], 0
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'

    stdcall populate_buffer, data_buf
    cinvoke printf, fmt_xs, data_buf, data_buf

    local local_buf[8]:BYTE
    stdcall populate_buffer, addr local_buf
    cinvoke printf, fmt_xs, addr local_buf, addr local_buf

    local p_buf:DWORD
    cinvoke malloc, 8
    mov [p_buf], eax
    stdcall populate_buffer, [p_buf]
    cinvoke printf, fmt_xs, [p_buf], [p_buf]
    cinvoke free, [p_buf]

    local h_heap:DWORD
    invoke GetProcessHeap
    mov [h_heap], eax
    invoke HeapAlloc, [h_heap], 0, 8
    mov [p_buf], eax
    stdcall populate_buffer, [p_buf]
    cinvoke printf, fmt_xs, [p_buf], [p_buf]
    invoke HeapFree, [h_heap], 0, [p_buf]

    cinvoke puts, 'done'
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local buf[8]:BYTE, p_buf:DWORD
    stdcall populate_buffer, addr buf
    cinvoke puts, addr buf
    sub esp, 8
    mov [p_buf], esp
    stdcall populate_buffer, [p_buf]
    cinvoke puts, [p_buf]
    add esp, 8
    cinvoke puts, 'done'
    ret
endp

include 'boilerplate/footer_data.inc'
fmt_xs      db '%08x : "%s"', 10, 0
data_buf    rb 8

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        GetProcessHeap, 'GetProcessHeap',\
        HeapAlloc,      'HeapAlloc',\
        HeapFree,       'HeapFree',\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        malloc,         'malloc',\
        free,           'free',\
        printf,         'printf',\
        puts,           'puts'
