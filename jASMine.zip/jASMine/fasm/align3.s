include 'compiler/header.x86.inc'
include 'util/introspection.text.inc'

proc main
    print_s '*** main1 ***'
    jmp .intro_end
    align 4
.intro1:
    align 4
.intro2:
    inc eax
    align 4
.intro3:
    inc eax
    inc eax
    align 4
.intro4:
    inc eax
    inc eax
    inc eax
    align 4
.intro5:
    inc eax
    inc eax
    inc eax
    inc eax
.intro6:
    align 4
.intro_end:
    introspect6
    ret
endp

include 'compiler/footer.inc'
