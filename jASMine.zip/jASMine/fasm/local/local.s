include 'boilerplate/header.x86.inc'
include 'util/introspection.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall main1_1
    stdcall main1_2
    stdcall main1_introspect
    ret
endp

proc main1_1
    local num1:DWORD
    mov dword [num1], 0x1234
    ret
endp

proc main1_2
    push ebp                  ; 55
    mov ebp, esp              ; 89 E5
    sub esp, 4                ; 83 EC 04
    mov dword [ebp-4], 0x1234 ; C7 45 FC 34 12 00 00
    leave                     ; C9
    ret                       ; C3
endp

proc main1_introspect
    stdcall introspect, main1_1, main1_2
    stdcall introspect, main1_2, main1_introspect
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall main2_1
    stdcall main2_2
    stdcall main2_introspect
    ret
endp

proc main2_1
    local num1:BYTE, num2:WORD, num3:DWORD, num4:QWORD, num5:TBYTE
    mov [num1], 1
    mov [num2], 2
    mov [num3], 3
    mov dword [num4], 4
    mov dword [num5], 5
    ret
endp

proc main2_2
    push ebp                 ; 55
    mov ebp, esp             ; 89 E5
    sub esp, 28              ; 83 EC 1C
    mov byte [ebp-28], 1     ; C6 45 E4 01
    mov word [ebp-27], 2     ; 66 C7 45 E5 02 00
    mov dword [ebp-25], 3    ; C7 45 E7 03 00 00 00
    mov dword [ebp-21], 4    ; C7 45 EB 04 00 00 00
    mov dword [ebp-13], 5    ; C7 45 F3 05 00 00 00
    leave                    ; C9
    ret                      ; C3
endp

proc main2_introspect
    stdcall introspect, main2_1, main2_2
    stdcall introspect, main2_2, main2_introspect
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    stdcall main3_1
    stdcall main3_2
    stdcall main3_introspect
    ret
endp

proc main3_1
    local buf1[4]:BYTE
    mov [buf1 + 0], 0x12
    mov [buf1 + 1], 0x34
    mov [buf1 + 2], 0x56
    mov [buf1 + 3], 0x78
    cinvoke printf, fmt_x, dword [buf1]
    movzx eax, [buf1 + 1]
    cinvoke printf, fmt_x, eax
    ret
endp

proc main3_2
    push ebp                        ; 55
    mov ebp, esp                    ; 89 E5
    sub esp, 4                      ; 83 EC 04
    mov byte [ebp-4], 0x12          ; C6 45 FC 12
    mov byte [ebp-3], 0x34          ; C6 45 FD 34
    mov byte [ebp-2], 0x56          ; C6 45 FE 56
    mov byte [ebp-1], 0x78          ; C6 45 FF 78
    push dword [ebp-4]              ; FF 75 FC
    push 0x401029                   ; 68 29 10 40 00
    call dword [0x403084]           ; FF 15 84 30 40 00
    add esp, 8                      ; 83 C4 08
    movzx eax, byte [ebp-3]         ; 0F B6 45 FD
    push eax                        ; 50
    push 0x401029                   ; 68 29 10 40 00
    call dword [0x403084]           ; FF 15 84 30 40 00
    add esp, 8                      ; 83 C4 08
    leave                           ; C9
    ret                             ; C3
endp

proc main3_introspect
    dummy = main3_1
    dummy = main3_2
    stdcall introspect, main3_1, main3_2
    stdcall introspect, main3_2, main3_introspect
    ret
endp

include 'boilerplate/footer.inc'
