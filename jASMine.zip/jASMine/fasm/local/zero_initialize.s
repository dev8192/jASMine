format PE
entry start

include 'win32ax.inc'

BUFSZ = 10

section '.data' data readable writeable
    fmt_func1       db 'func1: %d', 10, 0
    fmt_func2       db 'func2: %d', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'
    
proc main1
    cinvoke puts, '*** main1 ***'
    stdcall .func1
    stdcall .func2
    ret
endp
    
proc .func1
    local num:DWORD
    mov [num], 123
    cinvoke printf, fmt_func1, [num]
    ret
endp

proc .func2
    local num:DWORD
    cinvoke printf, fmt_func2, [num]
    ret
endp
    
proc main
    cinvoke puts, '*** main2 ***'
    stdcall .func1
    stdcall .func2
    ret
endp
    
proc .func1
    locals
        buf1 db BUFSZ dup(0xAB)
        buf2 db BUFSZ dup(0xCD)
    endl
    stdcall print_bytes, addr buf1, BUFSZ
    stdcall print_bytes, addr buf2, BUFSZ
    ret
endp

proc .func2
    locals
        buf1 db BUFSZ dup(0x12)
        buf2 rb BUFSZ
    endl
    stdcall print_bytes, addr buf1, BUFSZ
    stdcall print_bytes, addr buf2, BUFSZ
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    stdcall .func1, 456
    sub esp, 4
    stdcall .func2
    ret
endp

proc .func1, p1
    cinvoke printf, fmt_func1, [p1]
    ret
endp

proc .func2, p1
    cinvoke printf, fmt_func2, [p1]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
