format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    pt1             dd 11, 12
    pt2:            dd 21, 22
    fmt_dn          db '%d', 10, 0
    fmt_point       db '%d %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    locals
        num1 rd 1
    endl
    mov [num1], 5
    cinvoke printf, fmt_dn, [num1]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    locals
        num1 dd 5
        num2 dd 10
        num3 dd ?
    endl
    mov eax, [num1]
    add eax, [num2]
    mov [num3], eax
    cinvoke printf, fmt_dn, [num3]
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    locals
        pt3     dd 31, 32
        pt4:    dd 41, 42
    endl
    cinvoke printf, fmt_point, dword [pt1], dword [pt1 + 4]
    cinvoke printf, fmt_point, dword [pt2], dword [pt2 + 4]
    cinvoke printf, fmt_point, dword [pt3], dword [pt3 + 4]
    cinvoke printf, fmt_point, dword [pt4], dword [pt4 + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
