format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    locals
        buf1 db 20 dup(0x33)
    endl
    stdcall print_bytes, addr buf1, 20
    mov dword [buf1 + 4], 0x44
    stdcall print_bytes, addr buf1, 20
    cinvoke printf, fmt_x, dword [buf1 + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
