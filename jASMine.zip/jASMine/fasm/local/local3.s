format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt     db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall test10
    stdcall test20
    stdcall test30
    stdcall test40
    invoke ExitProcess, 0
    
proc test10
    local var1:DWORD
    cinvoke puts, "*** test10 ***"
    cinvoke printf, fmt, esp
    ret
endp
    
proc test20
    cinvoke puts, "*** test20 ***"
    cinvoke printf, fmt, esp
    local var1:DWORD
    cinvoke printf, fmt, esp
    local var2:DWORD
    cinvoke printf, fmt, esp
    ret
endp
    
proc test30
    cinvoke puts, "*** test30 ***"
    cinvoke printf, fmt, esp
    local var1:DWORD
    cinvoke printf, fmt, esp
    local var2:DWORD
    cinvoke printf, fmt, esp
    ret
endp
    
proc test40a
    cinvoke puts, "*** test40 ***"
    cinvoke printf, fmt, esp
    local var1:DWORD
    cinvoke printf, fmt, esp
    sub     esp, 4
    cinvoke printf, fmt, esp
    ret
endp
    
proc test40
    cinvoke puts, "*** test40 ***"
    cinvoke printf, fmt, esp
    local var1:DWORD
    cinvoke printf, fmt, esp
    sub     esp, 4
    mov     eax, ebp
    sub     eax, esp
    cinvoke printf, fmt, eax
    sub     esp, 4
    mov     eax, ebp
    sub     eax, esp
    cinvoke printf, fmt, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
