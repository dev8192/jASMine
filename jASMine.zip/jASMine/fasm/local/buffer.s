format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    msg db 'Stack Variables Example', 0
    fmt_hex     db '%x', 10, 0

section '.text' code readable executable
start:
    ;stdcall CalculateAndShow, 100, 50
    stdcall test20
    invoke  ExitProcess, 0

proc test10
    local buf1[16]:BYTE
    local buf2[8]:WORD
    local buf3[4]:DWORD
    local buf4[2]:QWORD
    cinvoke printf, fmt_hex, esp
    cinvoke printf, fmt_hex, addr buf1
    cinvoke printf, fmt_hex, addr buf2
    cinvoke printf, fmt_hex, addr buf3
    cinvoke printf, fmt_hex, addr buf4
    cinvoke printf, fmt_hex, ebp
    ret
endp

proc PrintBuffer uses ebx, buf
    mov ebx, [buf]
    cinvoke printf, fmt_hex, dword [ebx +  0]
    cinvoke printf, fmt_hex, dword [ebx +  4]
    cinvoke printf, fmt_hex, dword [ebx +  8]
    cinvoke printf, fmt_hex, dword [ebx + 12]
    ret
endp

proc test20 uses ebx
    local buf[4]:DWORD
    lea ebx, [buf]
    cinvoke printf, fmt_hex, addr buf
    cinvoke printf, fmt_hex, ebx
    mov dword [ebx +  0], 0x12
    mov dword [ebx +  4], 0x34
    mov dword [ebx +  8], 0x56
    mov dword [ebx + 12], 0x78
    stdcall PrintBuffer, addr buf
    ret
endp

proc test201
    local buf[4]:DWORD
    stdcall PrintBuffer, addr buf
    mov dword [buf +  0], 0x12
    mov dword [buf +  4], 0x34
    mov dword [buf +  8], 0x56
    mov dword [buf + 12], 0x78
    stdcall PrintBuffer, addr buf
    ret
endp

proc CalculateAndShow, val1, val2
    local result:DWORD
    local buffer[64]:BYTE

    mov     eax, [val1]
    add     eax, [val2]
    mov     [result], eax

    invoke  wsprintf, addr buffer,\
        '%d + %d = %d', [val1], [val2], [result]

    invoke  MessageBox, 0, addr buffer, msg, MB_OK
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  user32,\
            MessageBox,     'MessageBoxA',\
            wsprintf,       'wsprintfA'
    import  msvcrt,\
            printf,         'printf'
