include 'compiler/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    print_d [section1.num]
    print_d [section2.num]
    ret
endp

include 'compiler/footer_data.inc'
section1.num dd 123
section2:
.num dd 456
include 'compiler/footer_idata.inc'
