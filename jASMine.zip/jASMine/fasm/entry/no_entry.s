format PE console

include 'win32a.inc'

section '.text' code readable executable
    cinvoke printf, str1
    invoke ExitProcess, 0

section '.data' data readable writeable
    str1 db "no entry start", 10, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
