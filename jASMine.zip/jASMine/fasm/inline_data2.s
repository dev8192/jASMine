format PE GUI 4.0
entry start

include 'win32a.inc'

section '.text' code readable executable

start:
    call ExecuteEncryptedPayload
    
    ; Exit the program cleanly
    invoke ExitProcess, 0

proc ExecuteEncryptedPayload
    locals
        stack_buffer rb 8    ; Allocate 8 bytes on the stack
    endl

    ; 1. Copy the encrypted inline machine code onto the stack
    ;    We can read the data block placed safely below the 'ret'
    mov eax, [encrypted_code]
    mov [stack_buffer], eax
    mov eax, [encrypted_code+4]
    mov [stack_buffer+4], eax

    ; 2. Decode the payload directly on the stack using XOR key: 0xAA
    ;    (XOR logic: Encrypted ^ Key = Original Code)
    xor dword [stack_buffer], 0xAAAAAA22
    xor dword [stack_buffer+4], 0xAA00AAAA

    ; 3. Execute the stack buffer!
    ;    We dynamically jump straight into the stack memory address
    lea eax, [stack_buffer]
    call eax

    ret

; ----------------------------------------------------
; INLINE DATA AREA (Safely sitting outside execution)
; ----------------------------------------------------
align 4
encrypted_code:
    ; This looks like a random sequence of numbers/constants
    dd 0xC3CA9A97
    dd 0xAA56AA22
endp

; ====================================================
; EXPLANATION OF THE MACHINE CODE NUMBERS
; ====================================================
; When the CPU runs the XOR operation above, the hidden bytes become:
; 
; Hex Bytes:   6A 30 33 C9 58 FF D0 C3
; 
; In x86 Assembly, those exact bytes translate to:
; push 0x30        ; 6A 30  -> Push 0x30 onto stack (TEB pointer offset)
; xor ecx, ecx     ; 33 C9  -> Zero out ECX
; pop eax          ; 58     -> EAX = 0x30
; call eax         ; FF D0  -> Dynamic absolute call
; ret              ; C3     -> Clean exit back to main function
