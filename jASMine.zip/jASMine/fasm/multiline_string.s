include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    print_s str1
    print_d str1_len
    ret
endp

include 'compiler/footer_data.inc'
str1 db 'abc',\
'123', 0
str1_len = $ - str1

include 'compiler/footer_idata.inc'
