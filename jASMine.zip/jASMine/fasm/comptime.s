; TODO: How to implement zig's comptime in fasm?
