format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_esp_inside      db 'inside  : %x', 10, 0
    fmt_esp_outside     db 'outside : %x', 10, 0
    fmt_d               db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_esp_outside, esp
    stdcall .func, 123
    cinvoke printf, fmt_esp_outside, esp
    ret
endp

proc .func, num
    cinvoke printf, fmt_esp_inside, esp
    invoke printf, fmt_d, [num]
    cinvoke printf, fmt_esp_inside, esp
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_esp_outside, esp
    stdcall .func
    cinvoke printf, fmt_esp_outside, esp
    ret
endp

proc .func
    cinvoke printf, fmt_esp_inside, esp
    invoke printf, fmt_d, 123
    add esp, 8
    cinvoke printf, fmt_esp_inside, esp
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    cinvoke printf, fmt_esp_outside, esp
    stdcall .func
    cinvoke printf, fmt_esp_outside, esp
    ret
endp

proc .func
    push ebp
    mov ebp, esp
    cinvoke printf, fmt_esp_inside, esp
    invoke printf, fmt_d, 123
    leave
    cinvoke printf, fmt_esp_inside, esp
    ret
endp

proc main
    cinvoke puts, '*** main4 ***'
    cinvoke printf, fmt_esp_outside, esp
    stdcall .func
    cinvoke printf, fmt_esp_outside, esp
    ret
endp

proc .func
    push ebp
    mov ebp, esp
    cinvoke printf, fmt_esp_inside, esp
    invoke printf, fmt_d, 123
    mov esp, ebp
    pop ebp
    cinvoke printf, fmt_esp_inside, esp
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
