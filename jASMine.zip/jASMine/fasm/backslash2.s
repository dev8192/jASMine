include 'compiler/header.x86.inc'

include 'compiler/footer.inc'

; what is the point of this backslash?
; fasm\internals\preprocessor\convert_line.trace
\