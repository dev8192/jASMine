include 'fasm/tbyte.s'
