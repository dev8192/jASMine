include 'boilerplate/header.x86.inc'
include 'util/introspection.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    jmp .introspection_end
.introspection1:
    cinvoke puts, 'abc'
    cinvoke puts, 'abc'
.introspection2:
    call @f             ; E8 04 00 00 00
    db "abc", 0         ; 61 62 63 00
@@: call [puts]         ; FF 15 88 30 40 00
    add esp, 4          ; 83 C4 04
    call $ + 5 + 4      ; E8 04 00 00 00
    db "abc", 0         ; 61 62 63 00
    call [puts]         ; FF 15 88 30 40 00
    add esp, 4          ; 83 C4 04
.introspection_end:
    introspect2
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall main2_1
    stdcall main2_2
    stdcall introspect, main2_1.introspection1, main2_1.introspection_end
    stdcall introspect, main2_2.introspection1, main2_2.introspection_end
    ret
endp

proc main2_1
.introspection1:
    jmp @f
    .str1 db 'abc', 0
@@: cinvoke puts, .str1
.introspection_end:
    ret
endp

proc main2_2
.introspection1:
    jmp $ + 2 + 4       ; EB 04
    db 'abc', 0         ; 61 62 63 00
    push $ - 4          ; 68 ?? ?? ?? ??
    call [puts]         ; FF 15 88 30 40 00
    add esp, 4          ; 83 C4 04
.introspection_end:
    ret
endp

include 'boilerplate/footer.inc'
