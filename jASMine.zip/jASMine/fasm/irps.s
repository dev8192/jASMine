
; TODO: What does $ mean in the context of irps?
macro main1 {
    display '*** main1 ***', 10
    four equ 'hello world'
    irps item, 'one' 'two three' four \{
        display item, 10
    \}
    display 'done'
}

macro main2 {
    display '*** main2 ***', 10
    count = 0
    irps item, eax + [ebx * 4] \{
        count = count + 1
    \}
    display '0' + count, 10
    display 'done'
}

macro main3 {
    display '*** main3 ***', 10
    irps item, \{
        display 'This will never print'
    \}
    display 'done'
}

macro main4 {
    display '*** main4 ***', 10
    reglist equ 'one two three'
    irps reg, reglist \{
        display reg, 10
    \}
    display 'done'
}

macro main5 {
    display '*** main5 ***', 10
    reglist equ one two three
    irps reg, reglist \{
        display \`reg, 10
        display `reg, 10
    \}
    display 'done'
}

macro macro33 reglist {
    irps reg, reglist \{
        display 'hello', 10
    \}
}

macro main {
    display '*** main6 ***', 10
    macro33 one two three
    display 'done'
}

main
