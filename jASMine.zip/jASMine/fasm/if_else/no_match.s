include 'win32ax.inc'

; 1 for GetCommandLine, 0 for Static
TITLE_MODE = 0
if TITLE_MODE = 1
    _TITLE equ invoke GetCommandLine
else
    _TITLE equ "Static Title!"
end if

.code
  start:
    invoke MessageBox, \
           HWND_DESKTOP, \
           "Message", \
           _TITLE, \
           MB_OK

    invoke ExitProcess, 0
.end start
