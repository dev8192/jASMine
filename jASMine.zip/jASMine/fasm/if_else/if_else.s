
macro main1 {
    display '*** main1 ***', 10
    UPPERCASE = 0
    if UPPERCASE = 1
        display 'HELLO'
    else
        display 'hello'
    end if
}

macro main21 {
    display '*** main21 ***', 10
   ;UPPERCASE = 1
    if defined UPPERCASE
        display 'HELLO'
    else
        display 'hello'
    end if
}

macro main {
    display '*** main22 ***', 10
   ;UPPERCASE = 1
    if ~ defined UPPERCASE
        display 'hello'
    else
        display 'HELLO'
    end if
}

macro main3 {
    display '*** main3 ***', 10
   ;NUM1 = 5 ; greater than 0
   ;NUM1 = -5 ; less than 0
    NUM1 = 0 ; equals 0
    if NUM1 > 0
        display 'greater than 0'
    else
        if NUM1 < 0
            display 'less than 0'
        else
            display 'equals 0'
        end if
    end if
}

macro main4 {
    display '*** main4 ***', 10
   ;NUM1 = 5 ; greater than 0
    NUM1 = -5 ; less than 0
   ;NUM1 = 0 ; equals 0
    if NUM1 > 0
        display 'greater than 0'
    else if NUM1 < 0
        display 'less than 0'
    else
        display 'equals 0'
    end if
}

; broken
macro main5 {
    display '*** main5 ***', 10
   ;NUM1 = 5 ; error: illegal instruction
   ;NUM1 = -5 ; equals 0 wtf?
    NUM1 = 0 ; equals 0
    if NUM1 > 0
        display 'greater than 0'
    elif NUM1 < 0
        display 'less than 0'
    else
        display 'equals 0'
    end if
}

macro main6 {
    display '*** main6 ***', 10
    NUM1 = 6
    if NUM1 > 5 & NUM1 < 10
        display '111'
    else
        display '222'
    end if
}

main
