format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    mov eax, 123
var1 = 5
if var1 = 5
    mov eax, 456
end if
    cinvoke printf, fmt_d, eax
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
var1 = 3
if var1 = 5
    mov eax, 123
else
    mov eax, 456
end if
    cinvoke printf, fmt_d, eax
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
var1 = 1
if var1 > 5
    mov eax, 123
else if var1 < 5
    mov eax, 456
else
    mov eax, 789
end if
    cinvoke printf, fmt_d, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
