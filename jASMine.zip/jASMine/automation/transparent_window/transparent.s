format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    clsName db 'Overlay', 0
    fmt db 'X: %d, Y: %d', 10, 0
    wc WNDCLASS
    msg MSG

section '.text' code readable executable
start:
    invoke GetModuleHandleA, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], WindowProc
    invoke LoadCursorA, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.lpszClassName], clsName
    mov [wc.hbrBackground], COLOR_WINDOW+1
    invoke RegisterClassA, wc
    invoke GetSystemMetrics, SM_CXSCREEN
    mov ebx, eax
    invoke GetSystemMetrics, SM_CYSCREEN
    mov esi, eax
    invoke CreateWindowExA, WS_EX_LAYERED or WS_EX_TOPMOST,\
        clsName, 0, WS_POPUP or WS_VISIBLE,\
        0, 0, ebx, esi, 0, 0, [wc.hInstance], 0
    invoke SetLayeredWindowAttributes, eax, 0, 1, LWA_ALPHA
msg_loop:
    invoke GetMessageA, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessageA, msg
    jmp msg_loop
end_loop:
    invoke ExitProcess, [msg.wParam]

proc WindowProc hwnd, wmsg, wparam, lparam
    cmp [wmsg], WM_LBUTTONDOWN
    je .lbuttondown
    cmp [wmsg], WM_KEYDOWN
    je .keydown
    cmp [wmsg], WM_DESTROY
    je .wmdestroy
.defwndproc:
    invoke DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret
.lbuttondown:
    mov eax, [lparam]
    movsx ecx, ax
    sar eax, 16
    cinvoke printf, fmt, ecx, eax
    xor eax, eax
    ret
.keydown:
    cmp [wparam], VK_ESCAPE
    jne .defwndproc
    invoke DestroyWindow, [hwnd]
    xor eax, eax
    ret
.wmdestroy:
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandleA, 'GetModuleHandleA'

    import user32,\
        CreateWindowExA, 'CreateWindowExA',\
        DefWindowProcA, 'DefWindowProcA',\
        DestroyWindow, 'DestroyWindow',\
        DispatchMessageA, 'DispatchMessageA',\
        GetMessageA, 'GetMessageA',\
        GetSystemMetrics, 'GetSystemMetrics',\
        LoadCursorA, 'LoadCursorA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClassA, 'RegisterClassA',\
        SetLayeredWindowAttributes, 'SetLayeredWindowAttributes',\
        TranslateMessage, 'TranslateMessage'

    import msvcrt,\
        printf, 'printf'
