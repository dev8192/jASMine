format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    angle_factor dd 0.0062831853
    radius dd 300.0
    center_x dd 640.0
    center_y dd 360.0
    ticks_val dd 0
    cur_x dd 0
    cur_y dd 0

section '.text' code readable executable
start:
.loop:
    invoke GetAsyncKeyState, VK_ESCAPE
    test eax, eax
    jnz .end

    invoke GetTickCount
    mov [ticks_val], eax

    fild dword [ticks_val]
    fmul dword [angle_factor]
    fsincos

    fmul dword [radius]
    fadd dword [center_x]
    fistp dword [cur_x]

    fmul dword [radius]
    fadd dword [center_y]
    fistp dword [cur_y]

    invoke SetCursorPos, [cur_x], [cur_y]
    invoke Sleep, 100
    jmp .loop
.end:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            user32, 'USER32.DLL'

    import kernel32, \
           ExitProcess, 'ExitProcess', \
           GetTickCount, 'GetTickCount', \
           Sleep, 'Sleep'

    import user32, \
           GetAsyncKeyState, 'GetAsyncKeyState', \
           SetCursorPos, 'SetCursorPos'
