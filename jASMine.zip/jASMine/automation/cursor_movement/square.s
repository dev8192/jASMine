format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    start_x dd 340, 940, 940, 340
    start_y dd 60, 60, 660, 660
    sign_x dd 1, 0, -1, 0
    sign_y dd 0, 1, 0, -1

section '.text' code readable executable
start:
    invoke Main
    invoke ExitProcess, 0

proc Main
.loop:
    invoke GetAsyncKeyState, VK_ESCAPE
    test eax, eax
    jnz .end

    invoke GetTickCount

    xor edx, edx
    mov ecx, 1000
    div ecx

    mov eax, edx
    xor edx, edx
    mov ecx, 250
    div ecx

    push eax

    mov eax, edx
    mov ecx, 12
    mul ecx
    mov ecx, 5
    div ecx

    pop ebx
    mov esi, eax

    mov eax, [sign_x + ebx*4]
    imul eax, esi
    add eax, [start_x + ebx*4]
    mov edi, eax

    mov eax, [sign_y + ebx*4]
    imul eax, esi
    add eax, [start_y + ebx*4]

    invoke SetCursorPos, edi, eax
    invoke Sleep, 10
    jmp .loop
.end:
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            user32, 'USER32.DLL'

    import kernel32, \
           ExitProcess, 'ExitProcess', \
           GetTickCount, 'GetTickCount', \
           Sleep, 'Sleep'

    import user32, \
           GetAsyncKeyState, 'GetAsyncKeyState', \
           SetCursorPos, 'SetCursorPos'
