format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    chrome_class db 'Chrome_WidgetWin_1', 0
    found_msg db 'Chrome found and Ctrl+T sent.', 10, 0
    notfound_msg db 'Chrome not found.', 10, 0
    class_buf rb 256
    found_flag dd 0

section '.text' code readable executable

proc EnumWindowsProc hwnd, lParam
    invoke GetClassNameA, [hwnd], class_buf, 256
    invoke lstrcmpA, class_buf, chrome_class
    test eax, eax
    jnz .continue

    invoke IsWindowVisible, [hwnd]
    test eax, eax
    jz .continue

    invoke SetForegroundWindow, [hwnd]
    invoke Sleep, 100

    invoke keybd_event, VK_CONTROL, 0, 0, 0
    invoke keybd_event, 'T', 0, 0, 0
    invoke keybd_event, 'T', 0, KEYEVENTF_KEYUP, 0
    invoke keybd_event, VK_CONTROL, 0, KEYEVENTF_KEYUP, 0

    mov [found_flag], 1
    xor eax, eax
    ret

.continue:
    mov eax, 1
    ret
endp

start:
    invoke EnumWindows, EnumWindowsProc, 0

    cmp [found_flag], 1
    je .success
    cinvoke printf, notfound_msg
    jmp .exit

.success:
    cinvoke printf, found_msg

.exit:
    invoke ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        msvcrt, 'MSVCRT.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        Sleep, 'Sleep',\
        lstrcmpA, 'lstrcmpA'

    import user32,\
        EnumWindows, 'EnumWindows',\
        GetClassNameA, 'GetClassNameA',\
        IsWindowVisible, 'IsWindowVisible',\
        SetForegroundWindow, 'SetForegroundWindow',\
        keybd_event, 'keybd_event'

    import msvcrt,\
        printf, 'printf'
