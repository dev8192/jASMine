format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    calc_cmd db 'calc.exe', 0
    calc_title db 'Calculator', 0

section '.text' code readable executable

start:
    invoke WinExec, calc_cmd, SW_SHOWNORMAL
    invoke Sleep, 2000
    invoke FindWindow, 0, calc_title
    test eax, eax
    jz exit
    invoke SetWindowPos, eax, 0, 0, 0, 0, 0, SWP_NOSIZE or SWP_NOZORDER
    invoke Sleep, 1000
    stdcall click, 45, 429
    invoke Sleep, 1000
    stdcall click, 129, 424
    invoke Sleep, 1000
    stdcall click, 197, 426

exit:
    invoke ExitProcess, 0

proc click x, y
    invoke SetCursorPos, [x], [y]
    invoke mouse_event, MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0
    invoke mouse_event, MOUSEEVENTF_LEFTUP, 0, 0, 0, 0
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL', \
        user32, 'USER32.DLL'

    import kernel32, \
        WinExec, 'WinExec', \
        Sleep, 'Sleep', \
        ExitProcess, 'ExitProcess'

    import user32, \
        FindWindow, 'FindWindowA', \
        SetWindowPos, 'SetWindowPos', \
        SetCursorPos, 'SetCursorPos', \
        mouse_event, 'mouse_event'
