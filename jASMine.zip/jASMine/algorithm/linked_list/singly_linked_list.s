include 'boilerplate/header.x86.inc'
include 'algorithm/linked_list/linked_list.inc'
include 'algorithm/linked_list/singly_linked_list.inc'

proc main uses ebx
    cinvoke puts, '*** main1 ***'
    local singly_list:SinglyList
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    local singly_list:SinglyList
    lea ebx, [singly_list]
    invoke GetProcessHeap
    mov [ebx + singly_list.heap_handle], eax
    mov [ebx + singly_list.head], 0
    

    local node_a dd ?
    local node_b dd ?
    cinvoke printf, msg_start_singly
    stdcall prepend_singly_node, ebx, 5
    test eax, eax
    jnz .prep_ok
    cinvoke printf, msg_err_prepend
    jmp .exit
.prep_ok:
    stdcall append_singly_node, ebx, 10
    test eax, eax
    jnz .app_ok
    cinvoke printf, msg_err_append
    jmp .exit
.app_ok:
    mov [node_a], eax
    stdcall insert_singly_node, ebx, [node_a], 15
    test eax, eax
    jnz .ins_ok
    cinvoke printf, msg_err_insert
    jmp .exit
.ins_ok:
    mov [node_b], eax
    stdcall update_singly_node, [node_b], 25
    stdcall swap_singly_nodes, [node_a], [node_b]
    stdcall delete_singly_node, ebx, [node_a]
    test eax, eax
    jnz .del_ok
    cinvoke printf, msg_err_delete
    jmp .exit
.del_ok:
    stdcall print_singly_list, ebx
.exit:
    stdcall destroy_singly_list, ebx
    ret
endp

include 'boilerplate/footer_data.inc'
msg_err_append      db 'Error: Append failed.', 10, 0
msg_err_prepend     db 'Error: Prepend failed.', 10, 0
msg_err_insert      db 'Error: Insert failed.', 10, 0
msg_err_delete      db 'Error: Delete failed.', 10, 0
msg_newline         db 10, 0

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        GetProcessHeap, 'GetProcessHeap',\
        HeapAlloc,      'HeapAlloc',\
        HeapFree,       'HeapFree',\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
