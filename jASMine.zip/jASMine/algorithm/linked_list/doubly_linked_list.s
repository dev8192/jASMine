include 'boilerplate/header.x86.inc'

proc main uses ebx
    cinvoke puts, '*** main2 ***'
    
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    local doubly_list:DoublyList
    lea ebx, [doubly_list]
    invoke GetProcessHeap
    mov [ebx + doubly_list.heap_handle], eax
    mov [ebx + doubly_list.head], 0
    mov [ebx + doubly_list.tail], 0

    local node_a dd ?
    local node_b dd ?
    cinvoke printf, msg_start_doubly
    lea ecx, [ebx + AppData.doubly_list]
    invoke prepend_doubly_node, ecx, 50
    test eax, eax
    jnz .prep_ok
    cinvoke printf, msg_err_prepend
    jmp .exit
.prep_ok:
    lea ecx, [ebx + AppData.doubly_list]
    invoke append_doubly_node, ecx, 100
    test eax, eax
    jnz .app_ok
    cinvoke printf, msg_err_append
    jmp .exit
.app_ok:
    mov [node_a], eax
    lea ecx, [ebx + AppData.doubly_list]
    invoke insert_doubly_node, ecx, [node_a], 150
    test eax, eax
    jnz .ins_ok
    cinvoke printf, msg_err_insert
    jmp .exit
.ins_ok:
    mov [node_b], eax
    invoke update_doubly_node, [node_b], 250
    invoke swap_doubly_nodes, [node_a], [node_b]
    lea ecx, [ebx + AppData.doubly_list]
    invoke delete_doubly_node, ecx, [node_a]
    test eax, eax
    jnz .del_ok
    cinvoke printf, msg_err_delete
    jmp .exit
.del_ok:
    lea ecx, [ebx + AppData.doubly_list]
    invoke print_doubly_list, ecx
.exit:
    invoke destroy_doubly_list, ebx
    ret
endp

include 'boilerplate/footer_data.inc'
msg_start_singly    db 'Testing Singly Linked List...', 10, 0
msg_start_doubly    db 'Testing Doubly Linked List...', 10, 0
msg_err_append      db 'Error: Append failed.', 10, 0
msg_err_prepend     db 'Error: Prepend failed.', 10, 0
msg_err_insert      db 'Error: Insert failed.', 10, 0
msg_err_delete      db 'Error: Delete failed.', 10, 0
msg_node_data       db 'Node: %d', 10, 0
msg_newline         db 10, 0

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        GetProcessHeap, 'GetProcessHeap',\
        HeapAlloc,      'HeapAlloc',\
        HeapFree,       'HeapFree',\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
