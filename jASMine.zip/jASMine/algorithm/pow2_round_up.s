; Fast Power-of-Two Round-Up algorithm

format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_dd      db '%d %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../util/print_binary.text.inc'

; ----------------------------------------------------------

proc main1 uses ebx
    cinvoke puts, '*** main1 ***'
    stdcall print_binary32, 11111111_11111111_11111111_11111110b
    stdcall print_binary32, -2
    stdcall print_binary32, 11111111_11111111_11111111_11111100b
    stdcall print_binary32, -4
    stdcall print_binary32, 11111111_11111111_11111111_11111000b
    stdcall print_binary32, -8
    ret
endp

; ----------------------------------------------------------

proc main3 uses ebx
    cinvoke puts, '*** main3 ***'
    xor ebx, ebx
.loop:
    stdcall .func, ebx
    inc ebx
    cmp ebx, 15
    jl .loop
    ret
endp

proc .func, buf_size
    mov eax, [buf_size]
    add eax, 3
    and eax, -4
    cinvoke printf, fmt_dd, [buf_size], eax
    ret
endp

proc .func2, buf_size
    mov eax, [buf_size]
    inc eax
    add eax, 3
    and eax, -4
    cinvoke printf, fmt_dd, [buf_size], eax
    ret
endp

; ----------------------------------------------------------

proc main uses ebx
    cinvoke puts, '*** main3 ***'
    xor ebx, ebx
.loop:
    stdcall align_value, ebx, 8
    cinvoke printf, fmt_dd, ebx, eax
    inc ebx
    cmp ebx, 15
    jl .loop
    ret
endp

proc align_value val, alignment
    mov eax, [val]
    mov ecx, [alignment]
    dec ecx
    add eax, ecx
    not ecx
    and eax, ecx
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
