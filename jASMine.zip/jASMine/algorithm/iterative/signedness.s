include 'compiler/header.x86.inc'

proc loop_jge uses esi edi, l_bound, u_bound
    cinvoke puts, '*** loop_jge ***'
    mov esi, [l_bound]
    mov edi, [u_bound]
.loop:
    cmp esi, edi
    jge .done
    print_xud esi
    inc esi
    jmp .loop
.done:
    ret
endp

proc loop_jae uses esi edi, l_bound, u_bound
    cinvoke puts, '*** loop_jae ***'
    mov esi, [l_bound]
    mov edi, [u_bound]
.loop:
    cmp esi, edi
    jae .done
    print_xud esi
    inc esi
    jmp .loop
.done:
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall loop_jge, 0x7FFFFFFE, 0x80000002
    stdcall loop_jae, 0x7FFFFFFE, 0x80000002
    ret
endp

include 'compiler/footer.inc'
