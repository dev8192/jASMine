include 'compiler/header.x86.inc'

proc exclusive_upper_bound uses esi edi, l_bound, u_bound
    mov esi, [l_bound]
    mov edi, [u_bound]
    xor eax, eax
.loop:
    cmp esi, edi
    jae .done
    inc eax
    inc esi
    jmp .loop
.done:
    print_xud eax
    ret
endp

proc inclusive_upper_bound
    ret
endp

proc print_number uses esi edi, start, count
    mov esi, [start]
    mov ebx, [count]
.loop:
    cmp ebx, 0
    je .done
    print_xud esi
    inc esi
    dec ebx
    jmp .loop
.done:
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
   ;stdcall print_number, 0, 5
   ;stdcall print_number, 10, 11
   ;stdcall print_number, 10, 10
   ;stdcall print_number, 10, 5
    stdcall exclusive_upper_bound, 0, 0xFFFFFFFF
    ret
endp

include 'compiler/footer.inc'
