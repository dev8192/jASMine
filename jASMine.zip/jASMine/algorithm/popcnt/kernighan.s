; ------------------------------------------------
; Count Set Bits (Brian Kernighan's Algorithm)
; Clears the lowest set bit in each iteration using n & (n - 1)
; ------------------------------------------------
format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d   db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test1
    invoke  ExitProcess, 0

proc popcount, num
    mov     ecx, [num]
    mov     eax, 0
.loop:
    test    ecx, ecx
    jz      .count_done
    mov     edx, ecx
    dec     edx
    and     ecx, edx
    inc     eax
    jmp     .loop
.count_done:
    ret
endp

proc popcount_test, num
    stdcall popcount, [num]
    cinvoke printf, fmt_d, eax
    ret
endp

proc test1
    stdcall popcount_test, 0101_0101b
    stdcall popcount_test, 0101_1111b
    stdcall popcount_test, 1111_1111b
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
