; ------------------------------------------------
; SIMD Within A Register (SWAR)
; ------------------------------------------------
format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt_d   db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall test1
    invoke  ExitProcess, 0

; 11010111 -> 6
; [ 1 ] [ 1 ] [ 0 ] [ 1 ] [ 0 ] [ 1 ] [ 1 ] [ 1 ]
; [ 10 ] [ 01 ] [ 01 ] [ 10 ]
; [ 0011 ] [ 0011 ]
; [ 00000110 ]

; [1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0][1][0]
; [ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ][ 01 ]
; [   0010   ][   0010   ][   0010   ][   0010   ][   0010   ][   0010   ][   0010   ][   0010   ]
; [       00000100       ][       00000100       ][       00000100       ][       00000100       ]
; [               0000000000001000               ][               0000000000001000               ]
; [                              00000000000000000000000000010000                                ]

proc popcount, num
    mov     eax, [num]

    mov     ebx, eax
    shr     ebx, 1
    and     eax, 01010101010101010101010101010101b
    and     ebx, 01010101010101010101010101010101b
    add     eax, ebx

    mov     ebx, eax
    shr     ebx, 2
    and     eax, 00110011001100110011001100110011b
    and     ebx, 00110011001100110011001100110011b
    add     eax, ebx

    mov     ebx, eax
    shr     ebx, 4
    and     eax, 00001111000011110000111100001111b
    and     ebx, 00001111000011110000111100001111b
    add     eax, ebx

    mov     ebx, eax
    shr     ebx, 8
    and     eax, 00000000111111110000000011111111b
    and     ebx, 00000000111111110000000011111111b
    add     eax, ebx

    mov     ebx, eax
    shr     ebx, 16
    and     eax, 00000000000000001111111111111111b
    and     ebx, 00000000000000001111111111111111b
    add     eax, ebx

    ret
endp

proc popcount2, num
    mov     eax, [num]

    mov     ebx, eax
    shr     ebx, 1
    and     ebx, 0x55555555
    sub     eax, ebx

    mov     ebx, eax
    shr     ebx, 2
    and     eax, 0x33333333
    and     ebx, 0x33333333
    add     eax, ebx

    mov     ebx, eax
    shr     ebx, 4
    add     eax, ebx
    and     eax, 0x0F0F0F0F

    imul    eax, 0x01010101
    shr     eax, 24

    ret
endp

proc popcount_test, num
    stdcall popcount, [num]
    cinvoke printf, fmt_d, eax
    ret
endp

proc test1
    stdcall popcount_test, 0101_0101b
    stdcall popcount_test, 0101_1111b
    stdcall popcount_test, 1111_1111b
    stdcall popcount_test, 1101_0101b
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
