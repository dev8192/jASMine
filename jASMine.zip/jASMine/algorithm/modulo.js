function main() {
    const arr = []
    for(let i = 0; i < 30; i++) {
        arr.push(i % 4)
    }
    console.log(arr.join(' '))
}

main()
