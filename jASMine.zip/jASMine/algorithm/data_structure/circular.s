include 'compiler/header.x86.inc'

struct ITEM
    current     dd ?
    next        dd ?
    previous    dd ?
ends

proc noop p_item
    ret
endp

proc print_item p_item
    mov eax, [p_item]
    print_s0 [eax + ITEM.current]
    print_space
    ret
endp

proc print_newline_p p_item
    print_newline
    ret
endp

proc traverse_forward p_item, count, cb1, cb2, cb3
    stdcall traverse, ITEM.next,\
        [p_item], [count], [cb1], [cb2], [cb3]
    ret
endp

proc traverse_backward p_item, count, cb1, cb2, cb3
    stdcall traverse, ITEM.previous,\
        [p_item], [count], [cb1], [cb2], [cb3]
    ret
endp

proc traverse uses ebx esi edi, offset, p_item, count, cb1, cb2, cb3
    mov ebx, [count]
    mov esi, [p_item]
    mov edi, [offset]
    stdcall [cb1], esi
.loop:
    test ebx, ebx
    jz .done
    stdcall [cb2], esi
    mov esi, [esi + edi]
    dec ebx
    jmp .loop
.done:
    stdcall [cb3], esi
    mov eax, esi
    ret
endp

proc main1 uses ebx
    cinvoke puts, '*** main1 ***'
    mov ebx, list
    print_s [ebx + ITEM.current]
    print_s [ebx + ITEM.next]
    print_s [ebx + ITEM.previous]
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main2 ***'
   ;stdcall traverse_backward, list, 2, noop, noop, noop
    stdcall traverse_forward, list, 1, noop, noop, noop
    stdcall traverse_forward, eax, 3, noop, print_item, print_newline_p
    stdcall traverse_forward, eax, 3, noop, print_item, print_newline_p
    stdcall traverse_forward, eax, 3, noop, print_item, print_newline_p
    stdcall traverse_forward, eax, 3, noop, print_item, print_newline_p
    stdcall traverse_forward, eax, 3, noop, print_item, print_newline_p
    ret
endp

include 'compiler/footer_data.inc'
include 'data/month.data.inc'
list:
.Jan dd month.Jan, .Feb, .Dec
.Feb dd month.Feb, .Mar, .Jan
.Mar dd month.Mar, .Apr, .Feb
.Apr dd month.Apr, .May, .Mar
.May dd month.May, .Jun, .Apr
.Jun dd month.Jun, .Jul, .May
.Jul dd month.Jul, .Aug, .Jun
.Aug dd month.Aug, .Sep, .Jul
.Sep dd month.Sep, .Oct, .Aug
.Oct dd month.Oct, .Nov, .Sep
.Nov dd month.Nov, .Dec, .Oct
.Dec dd month.Dec, .Jan, .Nov
include 'compiler/footer_idata.inc'
