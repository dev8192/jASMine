include 'compiler/header.x86.inc'
include 'algorithm/modulo.text.inc'

struct TEST_CONFIG
    func        dd ?
    data        dd ?
    data_sz     dd ?
    callback    dd ?
ends

proc main1
    print_s '*** main1 ***'
    stdcall mod_n, 6, 4
    print_d eax
    ret
endp

proc main2
   ;print_s '*** main2 ***'
    stdcall main2_1
    stdcall main2_2
    ret
endp

proc main2_1
    print_s '*** main2_1 ***'
    stdcall print_numbers_mod_n, 2, 0, 32
    stdcall print_numbers_mod_n, 4, 0, 32
    stdcall print_numbers_mod_n, 8, 0, 32
    stdcall print_numbers_mod_n, 16, 0, 32
    ret
endp

proc main2_2
    print_s '*** main2_2 ***'
    stdcall print_numbers_mod2, 0, 32
    stdcall print_numbers_mod4, 0, 32
    stdcall print_numbers_mod8, 0, 32
    stdcall print_numbers_mod16, 0, 32
    ret
endp

proc main
   ;print_s '*** main3 ***'
    stdcall main3_1
   ;stdcall main3_2
    ret
endp

proc main3_1
   ;print_s '*** main3_1 ***'
    local config:TEST_CONFIG
    mov [config.func], print_rows1
   ;mov [config.func], print_16_item_rows1
   ;mov [config.func], print_16_item_rows2
    mov [config.data], data1
    mov [config.data_sz], data1_sz
    mov [config.callback], print_02x0__fn
    stdcall print_rows__test, addr config
    ret
endp

proc main3_2
   ;print_s '*** main3_2 ***'
    local config:TEST_CONFIG
    mov [config.func], print_rows2
    mov [config.data], data2
    mov [config.data_sz], data2_sz
    mov [config.callback], print_02d0__fn
    stdcall print_rows__test, addr config
    ret
endp

proc print_rows__test uses ebx esi edi, config
    mov ebx, [config]
    mov esi, [ebx + TEST_CONFIG.data]
    mov edi, [ebx + TEST_CONFIG.data_sz]
.loop:
    print_s '*** print_rows__test ***'
    stdcall [ebx + TEST_CONFIG.func],\
        dword [esi + TEST_ITEM.count],\
        dword [esi + TEST_ITEM.lbound],\
        dword [esi + TEST_ITEM.ubound],\
        dword [ebx + TEST_CONFIG.callback]
    add esi, sizeof.TEST_ITEM
    dec edi
    jnz .loop
    ret
endp

struct TEST_ITEM
    count   dd ?
    lbound  dd ?
    ubound  dd ?
ends

include 'compiler/footer_data.inc'
data1 dd\
    16, 0, 50,\
    16, 1, 50,\
    16, 15, 50,\
    16, 16, 50,\
    16, 10, 11,\
    16, 10, 10,\
    16, 10, 5
data1_sz = ($ - data1) / sizeof.TEST_ITEM
data2 dd\
    10, 0, 30,\
    10, 1, 30,\
    10, 1, 31,\
    10, 1, 32,\
    10, 10, 11,\
    10, 10, 10,\
    10, 10, 5
data2_sz = ($ - data2) / sizeof.TEST_ITEM
include 'compiler/footer_idata.inc'
