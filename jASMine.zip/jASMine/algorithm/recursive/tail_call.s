include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    mov eax, 600000
    xor edx, edx
    call count
    print_d edx
    ret
endp

count:
    test eax, eax
    jz .exit
    inc edx
    dec eax
   ;call count
    jmp count
.exit:
    ret

include 'compiler/footer.inc'
