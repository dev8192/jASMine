format PE CONSOLE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    msg_start   db 'Testing stdcall Stack Bounds (100,000 iterations)...', 13, 10, 0
    msg_tco_ok  db 'TCO Function Success! Result: %d', 13, 10, 0
    msg_crash   db 'Call Function Success!', 13, 10, 0 ; (Will not be reached due to crash)

section '.text' code readable executable
start:
    invoke  printf, msg_start

    ; =========================================================================
    ; TEST 1: The Tail-Call Optimized (TCO) stdcall Procedure
    ; =========================================================================
    stdcall recursive_tco_add, 100000, 0
    invoke  printf, msg_tco_ok, eax

    ; =========================================================================
    ; TEST 2: The Non-Optimized stdcall Procedure (Standard Call)
    ; =========================================================================
    ; Passing 100,000 iterations will push 400KB of metadata to the stack.
    ; This overflows the standard environment reservation, causing an immediate crash.
    stdcall recursive_call_add, 100000, 0

    invoke  printf, msg_crash
    invoke  ExitProcess, 0


; -----------------------------------------------------------------------------
; OPTIMIZED VERSION: TCO via manual Frame Reset
; -----------------------------------------------------------------------------
proc recursive_tco_add stdcall, current_val:DWORD, accumulator:DWORD
    ; 1. Check Base Case
    mov     eax, [current_val]
    test    eax, eax
    jz      .base_case

    ; 2. Perform Operation
    mov     ecx, [accumulator]
    add     ecx, eax             ; accumulator = accumulator + current_val
    dec     eax                  ; current_val = current_val - 1

    ; 3. TAIL-CALL OPTIMIZATION MECHANICS
    ; We must modify the existing stack frame arguments *in place* 
    ; and unwind the macro's local modifications before jumping.
    mov     [current_val], eax   ; Update param 1 on stack
    mov     [accumulator], ecx   ; Update param 2 on stack

    ; FASM's 'proc' creates an EBP frame. We copy our local epilogue steps manually:
    mov     esp, ebp             ; Collapse any unexpected stack drift
    pop     ebp                  ; Restore original caller's base pointer
    
    jmp     recursive_tco_add    ; Re-enter function directly with a pure jump.
                                 ; O(1) Stack Depth maintained.

.base_case:
    mov     eax, [accumulator]   ; stdcall returns integer results via EAX
    ret                          ; The macro handles stack cleanup here on final return
endp


; -----------------------------------------------------------------------------
; CRASH VERSION: Standard Structural Recursion
; -----------------------------------------------------------------------------
proc recursive_call_add stdcall, current_val:DWORD, accumulator:DWORD
    mov     eax, [current_val]
    test    eax, eax
    jz      .base_case

    mov     ecx, [accumulator]
    add     ecx, eax
    dec     eax

    ; Standard recursive execution path:
    ; Pushes new parameters and evaluates a completely fresh stack context.
    stdcall recursive_call_add, eax, ecx 
    ret

.base_case:
    mov     eax, [accumulator]
    ret
endp


section '.idata' import data readable
    library kernel32,'KERNEL32.DLL',\
            msvcrt,'MSVCRT.DLL'

    import kernel32, ExitProcess,'ExitProcess'
    import msvcrt, printf,'printf'
