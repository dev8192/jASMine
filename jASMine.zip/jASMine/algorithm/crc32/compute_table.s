format PE
entry start

include 'win32w.inc'

section '.data' data readable writeable
    fmt_x       db '0x%08X', 10, 0

section '.bss' readable writeable
    castagnoli_table rd 256

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main uses edi
    cinvoke puts, '*** main1 ***'
    xor ecx, ecx                  ; ecx = table index (0 to 255)
    mov edi, castagnoli_table     ; edi points to destination buffer

.generate_loop:
    mov eax, ecx                  ; eax will hold the mutating CRC value
    mov edx, 8                    ; edx = bit loop counter (8 bits per byte)

.bit_loop:
    test eax, 1                   ; Check if the lowest bit is set
    jz .bit_zero                  ; If 0, skip the XOR operation
    
    shr eax, 1                    ; Shift right by 1
    xor eax, 0x82F63B78           ; XOR with bit-reversed Castagnoli polynomial
    jmp .next_bit

.bit_zero:
    shr eax, 1                    ; Just shift right if the bit was 0

.next_bit:
    dec edx                       ; Decrement bit counter
    jnz .bit_loop                 ; Repeat for all 8 bits

    mov [edi + ecx * 4], eax        ; Store completed 32-bit entry into table
    inc ecx                       ; Move to next byte index
    cmp ecx, 256                  ; Check if all 256 entries are populated
    jne .generate_loop            ; Repeat until table is filled

    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
