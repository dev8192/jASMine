format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '0x%08X', 10, 0
    str1        db 'Hello World', 0
    str1_len    = $ - str1 - 1

include 'crc32.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include 'crc32.text.inc'
include '../../x86/sse4_2/crc32.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall x86_crc32, str1, str1_len
    cinvoke printf, fmt_x, eax ; 0x691DAA2F
    stdcall compute_crc32, str1, str1_len
    cinvoke printf, fmt_x, eax ; 0x691DAA2F
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
