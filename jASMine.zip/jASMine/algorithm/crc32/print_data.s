format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    ; Create a sample array of 256 dwords (0, 1, 2... 255) for testing
    my_array    dd 256 dup (?)
    
    ; Format strings for printf
    fmt_hex     db '%08X ', 0       ; Prints 8-digit uppercase hex with a trailing space
    fmt_newline db 10, 0            ; Newline character (ASCII 10)

section '.text' code readable executable
start:
    mov ecx, 256
    xor eax, eax
.fill_loop:
    mov [my_array + eax*4], eax
    inc eax
    loop .fill_loop

    push my_array
    call print_array_rows
    
    invoke ExitProcess, 0

proc print_array_rows uses ebx esi edi, array_ptr
    mov esi, [array_ptr]    ; ESI = base address of the array
    xor edi, edi            ; EDI = overall element counter (0 to 255)
    xor ebx, ebx            ; EBX = column counter for the current row (0 to 7)
.print_loop:
    mov eax, [esi + edi * 4]
    cinvoke printf, fmt_hex, eax
    inc edi                 ; Move to the next element
    inc ebx                 ; Track current row column position
    cmp ebx, 8
    jne .check_end          ; If not 8 yet, skip newline
    cinvoke printf, fmt_newline
    xor ebx, ebx            ; Reset row column count to 0
.check_end:
    cmp edi, 256            ; Did we process all 256 elements?
    jne .print_loop         ; If not, continue looping
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt,   'MSVCRT.DLL'
            
    import kernel32, \
           ExitProcess, 'ExitProcess'
           
    import msvcrt, \
           printf, 'printf'
