include 'boilerplate/header.x86.inc'
include 'algorithm/resizable_array/resizable_array.text.inc'
include 'data/person.text.inc'

DEBUG = 1

proc main
    stdcall array_alloc__test
   ;stdcall array_free__test
   ;stdcall array_push__test
   ;stdcall array_push_imm__test
   ;stdcall array_pop__test
   ;stdcall array_pop_imm8__test
   ;stdcall array_pop_imm16__test
   ;stdcall array_pop_imm32__test
   ;stdcall array_get__test
   ;stdcall array_set__test
   ;stdcall array_grow__test
   ;stdcall array_shrink__test
   ;stdcall array_insert__test
   ;stdcall array_delete__test
   ;stdcall array_print_info__test
   ;stdcall array_print__test
    ret
endp

proc array_alloc__test uses ebx
    stdcall array_alloc__test1
    ret
endp

proc array_free__test
    cinvoke puts, '*** array_free__test ***'
    ret
endp

proc array_alloc__test1 uses ebx
    cinvoke puts, '*** array_alloc__test1 ***'
    local arr:ResizableArray
    cinvoke memset, addr arr, 97, sizeof.ResizableArray
    mov [arr.element_size], 1
    mov [arr.capacity], 4
    stdcall array_alloc, addr arr
    stdcall array_print_info, ebx
    ret
endp

proc array_push__test uses ebx
    cinvoke puts, '*** array_push__test ***'
    local arr:ResizableArray
    lea ebx, [arr]
    mov [arr.element_size], sizeof.PERSON
    mov [arr.capacity], 4
    stdcall array_alloc, ebx
    test eax, eax
    jz .exit
   ;print_x [arr.data]
    stdcall array_push, ebx, person.John
    stdcall array_push, ebx, person.Jane
    stdcall array_push, ebx, person.Olivia
    stdcall array_print_info, ebx
    stdcall array_print, ebx, stringify_person_utf8
    stdcall array_free, ebx
    print_s 'done'
.exit:
    ret
endp

proc array_push_imm__test uses ebx
    cinvoke puts, '*** array_push_imm__test ***'
    local arr:ResizableArray
    lea ebx, [arr]
    stdcall array_alloc, ebx
    test eax, eax
    jz .exit
    stdcall array_push_imm, ebx, 0x7FFFFFFE
    stdcall array_push_imm, ebx, 0x7FFFFFFF
    stdcall array_push_imm, ebx, 0x80000000
    stdcall array_push_imm, ebx, 0x80000001
   ;stdcall array_print, ebx, stringify_u
    stdcall array_print, ebx, stringify_d
    stdcall array_free, ebx
    print_s 'done'
.exit:
    ret
endp

proc array_push_imm__test2 uses ebx
    cinvoke puts, '*** array_push_imm__test2 ***'
    local arr:ResizableArray
    lea ebx, [arr]
    mov [arr.element_size], 4
    mov [arr.capacity], 4
    stdcall array_alloc, ebx
    test eax, eax
    jz .exit
    print_x month.Jan
    print_x month.Feb
    print_x month.Mar
    stdcall array_push_imm, ebx, month.Jan
    stdcall array_push_imm, ebx, month.Feb
    stdcall array_push_imm, ebx, month.Mar
    stdcall array_print_info, ebx
    stdcall array_print, ebx, stringify_utf8_utf8
    stdcall array_free, ebx
    print_s 'done'
.exit:
    ret
endp

proc array_pop__test uses ebx
    cinvoke puts, '*** array_pop__test ***'
    ret
endp

proc array_pop_imm8__test uses ebx
    cinvoke puts, '*** array_pop_imm8__test ***'
    local arr:ResizableArray
    lea ebx, [arr]
    mov [arr.element_size], 1
    mov [arr.capacity], 4
    stdcall array_alloc, ebx
    test eax, eax
    jz .exit
    stdcall array_push_imm, ebx, 0xAA11
    stdcall array_push_imm, ebx, 0xAA22
    stdcall array_push_imm, ebx, 0xAA33
    stdcall array_pop_imm8, ebx
    print_x eax
    stdcall array_print_info, ebx
    stdcall array_print, ebx, stringify_u8_x
    stdcall array_free, ebx
    print_s 'done'
.exit:
    ret
endp

proc array_pop_imm16__test uses ebx
    cinvoke puts, '*** array_pop_imm16__test ***'
    ret
endp

proc array_pop_imm32__test uses ebx
    cinvoke puts, '*** array_pop_imm32__test ***'
    ret
endp

proc array_get__test uses ebx
    cinvoke puts, '*** array_get__test ***'
    ret
endp

proc array_set__test uses ebx
    cinvoke puts, '*** array_set__test ***'
    ret
endp

proc array_grow__test uses ebx
    cinvoke puts, '*** array_grow__test ***'
    ret
endp

proc array_shrink__test uses ebx
    cinvoke puts, '*** array_shrink__test ***'
    ret
endp

proc array_insert__test uses ebx
    cinvoke puts, '*** array_insert__test ***'
    ret
endp

proc array_delete__test uses ebx
    cinvoke puts, '*** array_delete__test ***'
    ret
endp

proc array_print_info__test uses ebx
    cinvoke puts, '*** array_print_info__test ***'
    ret
endp

proc array_print__test uses ebx
    cinvoke puts, '*** array_print__test ***'
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    local arr1:ResizableArray
    local element_value dd ?
    local out_value dd ?
    local iteration_index dd ?
    lea ebx, [arr1]
    stdcall array_alloc, ebx, 4, 4
    test eax, eax
    jz .end_test
    mov [element_value], 10
    lea ecx, [element_value]
    stdcall array_insert, ebx, 0, ecx
    test eax, eax
    jz .cleanup_array
    mov [element_value], 20
    lea ecx, [element_value]
    stdcall array_insert, ebx, 1, ecx
    test eax, eax
    jz .cleanup_array
    mov [element_value], 15
    lea ecx, [element_value]
    stdcall array_insert, ebx, 1, ecx
    test eax, eax
    jz .cleanup_array
    mov [element_value], 99
    lea ecx, [element_value]
    stdcall array_set, ebx, 0, ecx
    test eax, eax
    jz .cleanup_array
    stdcall array_delete, ebx, 2
    test eax, eax
    jz .cleanup_array
    mov [iteration_index], 0
.print_loop:
    mov eax, [iteration_index]
    cmp eax, [ebx + ResizableArray.length]
    jae .cleanup_array
    lea ecx, [out_value]
    stdcall array_get, ebx, [iteration_index], ecx
    test eax, eax
    jz .cleanup_array
    cinvoke printf, fmt_2d, [iteration_index], [out_value]
    inc [iteration_index]
    jmp .print_loop
.cleanup_array:
    stdcall array_free, ebx
.end_test:
    ret
endp

include 'boilerplate/footer_data.inc'
include 'algorithm/resizable_array/resizable_array.data.inc'
include 'data/month.data.inc'
include 'data/person.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        GetProcessHeap, 'GetProcessHeap',\
        HeapAlloc,      'HeapAlloc',\
        HeapReAlloc,    'HeapReAlloc',\
        HeapFree,       'HeapFree',\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        sprintf,        'sprintf',\
        memmove,        'memmove',\
        memcpy,         'memcpy',\
        memset,         'memset',\
        printf,         'printf',\
        puts,           'puts'
