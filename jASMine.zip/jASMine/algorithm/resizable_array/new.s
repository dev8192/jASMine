format PE console

include 'win32ax.inc'

INITIAL_CAPACITY = 4
GROWTH_FACTOR = 2
STATUS_SUCCESS = 1
STATUS_FAILURE = 0

struct ResizableArray
    data_pointer dd ?
    element_size dd ?
    capacity dd ?
    length dd ?
ends

section '.data' data readable writeable
    error_alloc_msg db 'Error: Array allocation failed.', 10, 0
    error_realloc_msg db 'Error: Array reallocation failed.', 10, 0
    error_free_msg db 'Error: Array memory free failed.', 10, 0
    test_pop_msg db 'Popped element: %d', 10, 0
    test_shrink_msg db 'Capacity after shrink: %d', 10, 0
    test_header_msg db 'Array elements:', 10, 0
    element_msg db 'Index %d: %d', 10, 0

section '.text' code readable executable

proc array_create array_ptr, element_size, initial_capacity
    local status dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    mov eax, [element_size]
    mov [ebx + ResizableArray.element_size], eax
    mov [ebx + ResizableArray.length], 0
    mov eax, [initial_capacity]
    mov [ebx + ResizableArray.capacity], eax
    mov ecx, eax
    imul ecx, [element_size]
    invoke GetProcessHeap
    invoke HeapAlloc, eax, HEAP_ZERO_MEMORY, ecx
    test eax, eax
    jnz .allocation_success
    cinvoke printf, error_alloc_msg
    jmp .end_function
.allocation_success:
    mov [ebx + ResizableArray.data_pointer], eax
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_grow array_ptr
    local status dd ?
    local new_capacity dd ?
    local new_size dd ?
    local current_heap dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    mov eax, [ebx + ResizableArray.capacity]
    imul eax, GROWTH_FACTOR
    mov [new_capacity], eax
    imul eax, [ebx + ResizableArray.element_size]
    mov [new_size], eax
    invoke GetProcessHeap
    mov [current_heap], eax
    invoke HeapReAlloc, [current_heap], HEAP_ZERO_MEMORY,\
        [ebx + ResizableArray.data_pointer], [new_size]
    test eax, eax
    jnz .realloc_success
    cinvoke printf, error_realloc_msg
    jmp .end_function
.realloc_success:
    mov [ebx + ResizableArray.data_pointer], eax
    mov eax, [new_capacity]
    mov [ebx + ResizableArray.capacity], eax
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_shrink array_ptr
    local status dd ?
    local new_capacity dd ?
    local new_size dd ?
    local current_heap dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    mov eax, [ebx + ResizableArray.length]
    cmp eax, INITIAL_CAPACITY
    jae .set_capacity
    mov eax, INITIAL_CAPACITY
.set_capacity:
    mov [new_capacity], eax
    cmp eax, [ebx + ResizableArray.capacity]
    je .already_shrunk
    imul eax, [ebx + ResizableArray.element_size]
    mov [new_size], eax
    invoke GetProcessHeap
    mov [current_heap], eax
    invoke HeapReAlloc, [current_heap], HEAP_ZERO_MEMORY,\
        [ebx + ResizableArray.data_pointer], [new_size]
    test eax, eax
    jnz .realloc_success
    cinvoke printf, error_realloc_msg
    jmp .end_function
.realloc_success:
    mov [ebx + ResizableArray.data_pointer], eax
    mov eax, [new_capacity]
    mov [ebx + ResizableArray.capacity], eax
.already_shrunk:
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_push array_ptr, element_ptr
    local status dd ?
    local dest_ptr dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    mov eax, [ebx + ResizableArray.length]
    cmp eax, [ebx + ResizableArray.capacity]
    jb .capacity_ok
    stdcall array_grow, ebx
    test eax, eax
    jz .end_function
.capacity_ok:
    mov eax, [ebx + ResizableArray.length]
    imul eax, [ebx + ResizableArray.element_size]
    mov ecx, [ebx + ResizableArray.data_pointer]
    add ecx, eax
    mov [dest_ptr], ecx
    cinvoke memcpy, [dest_ptr], [element_ptr], [ebx + ResizableArray.element_size]
    inc [ebx + ResizableArray.length]
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_pop array_ptr, out_element_ptr
    local status dd ?
    local src_ptr dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    cmp [ebx + ResizableArray.length], 0
    je .end_function
    mov eax, [ebx + ResizableArray.length]
    dec eax
    imul eax, [ebx + ResizableArray.element_size]
    mov ecx, [ebx + ResizableArray.data_pointer]
    add ecx, eax
    mov [src_ptr], ecx
    cinvoke memcpy, [out_element_ptr], [src_ptr], [ebx + ResizableArray.element_size]
    dec [ebx + ResizableArray.length]
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_insert array_ptr, index, element_ptr
    local status dd ?
    local move_size dd ?
    local dest_ptr dd ?
    local src_ptr dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    mov eax, [index]
    cmp eax, [ebx + ResizableArray.length]
    ja .end_function
    mov eax, [ebx + ResizableArray.length]
    cmp eax, [ebx + ResizableArray.capacity]
    jb .capacity_ok
    stdcall array_grow, ebx
    test eax, eax
    jz .end_function
.capacity_ok:
    mov eax, [ebx + ResizableArray.length]
    sub eax, [index]
    imul eax, [ebx + ResizableArray.element_size]
    mov [move_size], eax
    mov eax, [index]
    imul eax, [ebx + ResizableArray.element_size]
    mov ecx, [ebx + ResizableArray.data_pointer]
    add ecx, eax
    mov [src_ptr], ecx
    mov eax, ecx
    add eax, [ebx + ResizableArray.element_size]
    mov [dest_ptr], eax
    cmp [move_size], 0
    je .do_insert
    cinvoke memmove, [dest_ptr], [src_ptr], [move_size]
.do_insert:
    cinvoke memcpy, [src_ptr], [element_ptr], [ebx + ResizableArray.element_size]
    inc [ebx + ResizableArray.length]
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_delete array_ptr, index
    local status dd ?
    local move_size dd ?
    local dest_ptr dd ?
    local src_ptr dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    mov eax, [index]
    cmp eax, [ebx + ResizableArray.length]
    jae .end_function
    mov eax, [ebx + ResizableArray.length]
    sub eax, [index]
    dec eax
    imul eax, [ebx + ResizableArray.element_size]
    mov [move_size], eax
    mov eax, [index]
    imul eax, [ebx + ResizableArray.element_size]
    mov ecx, [ebx + ResizableArray.data_pointer]
    add ecx, eax
    mov [dest_ptr], ecx
    mov eax, ecx
    add eax, [ebx + ResizableArray.element_size]
    mov [src_ptr], eax
    cmp [move_size], 0
    je .do_delete
    cinvoke memmove, [dest_ptr], [src_ptr], [move_size]
.do_delete:
    dec [ebx + ResizableArray.length]
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_update array_ptr, index, element_ptr
    local status dd ?
    local dest_ptr dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    mov eax, [index]
    cmp eax, [ebx + ResizableArray.length]
    jae .end_function
    imul eax, [ebx + ResizableArray.element_size]
    mov ecx, [ebx + ResizableArray.data_pointer]
    add ecx, eax
    mov [dest_ptr], ecx
    cinvoke memcpy, [dest_ptr], [element_ptr], [ebx + ResizableArray.element_size]
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_get array_ptr, index, out_element_ptr
    local status dd ?
    local src_ptr dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    mov eax, [index]
    cmp eax, [ebx + ResizableArray.length]
    jae .end_function
    imul eax, [ebx + ResizableArray.element_size]
    mov ecx, [ebx + ResizableArray.data_pointer]
    add ecx, eax
    mov [src_ptr], ecx
    cinvoke memcpy, [out_element_ptr], [src_ptr], [ebx + ResizableArray.element_size]
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc array_destroy array_ptr
    local status dd ?
    local current_heap dd ?
    push ebx
    mov [status], STATUS_FAILURE
    mov ebx, [array_ptr]
    cmp [ebx + ResizableArray.data_pointer], 0
    je .success
    invoke GetProcessHeap
    mov [current_heap], eax
    invoke HeapFree, [current_heap], 0, [ebx + ResizableArray.data_pointer]
    test eax, eax
    jnz .success
    cinvoke printf, error_free_msg
    jmp .end_function
.success:
    mov [ebx + ResizableArray.data_pointer], 0
    mov [ebx + ResizableArray.capacity], 0
    mov [ebx + ResizableArray.length], 0
    mov [status], STATUS_SUCCESS
.end_function:
    mov eax, [status]
    pop ebx
    ret
endp

proc test_resizable_array
    local test_array ResizableArray
    local element_value dd ?
    local out_value dd ?
    local iteration_index dd ?
    push ebx
    lea ebx, [test_array]
    stdcall array_create, ebx, 4, INITIAL_CAPACITY
    test eax, eax
    jz .end_test
    mov [element_value], 10
    lea ecx, [element_value]
    stdcall array_push, ebx, ecx
    test eax, eax
    jz .cleanup_array
    mov [element_value], 20
    lea ecx, [element_value]
    stdcall array_push, ebx, ecx
    test eax, eax
    jz .cleanup_array
    mov [element_value], 30
    lea ecx, [element_value]
    stdcall array_push, ebx, ecx
    test eax, eax
    jz .cleanup_array
    lea ecx, [out_value]
    stdcall array_pop, ebx, ecx
    test eax, eax
    jz .cleanup_array
    cinvoke printf, test_pop_msg, [out_value]
    stdcall array_shrink, ebx
    test eax, eax
    jz .cleanup_array
    mov eax, [ebx + ResizableArray.capacity]
    cinvoke printf, test_shrink_msg, eax
    mov [element_value], 99
    lea ecx, [element_value]
    stdcall array_insert, ebx, 1, ecx
    test eax, eax
    jz .cleanup_array
    stdcall array_delete, ebx, 0
    test eax, eax
    jz .cleanup_array
    cinvoke printf, test_header_msg
    mov [iteration_index], 0
.print_loop:
    mov eax, [iteration_index]
    cmp eax, [ebx + ResizableArray.length]
    jae .cleanup_array
    lea ecx, [out_value]
    stdcall array_get, ebx, [iteration_index], ecx
    test eax, eax
    jz .cleanup_array
    cinvoke printf, element_msg, [iteration_index], [out_value]
    inc [iteration_index]
    jmp .print_loop
.cleanup_array:
    stdcall array_destroy, ebx
.end_test:
    pop ebx
    ret
endp

proc main
    stdcall test_resizable_array
    invoke ExitProcess, 0
    ret
endp

entry main

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
        msvcrt, 'msvcrt.dll'

    import kernel32,\
        GetProcessHeap, 'GetProcessHeap',\
        HeapAlloc, 'HeapAlloc',\
        HeapReAlloc, 'HeapReAlloc',\
        HeapFree, 'HeapFree',\
        ExitProcess, 'ExitProcess'

    import msvcrt,\
        printf, 'printf',\
        memmove, 'memmove',\
        memcpy, 'memcpy'
