include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_s, name.John
    cinvoke printf, fmt_s, name.Jane
    ret
endp

proc main2 uses esi
    cinvoke puts, '*** main2 ***'
    mov esi, month.arr
.loop:
    mov eax, [esi]
    test eax, eax
    jz .done
    cinvoke printf, fmt_s, eax
    add esi, 4
    jmp .loop
.done:
    ret
endp

proc main3 uses ebx
    cinvoke puts, '*** main3 ***'
    local buf[64]:BYTE
    mov [buf], 0
    cinvoke strcat, addr buf, season.summer
    sub [buf], 32
    cinvoke strcat, addr buf, colon_space
    cinvoke strcat, addr buf, month.Jun
    cinvoke strcat, addr buf, comma_space
    cinvoke strcat, addr buf, month.Jul
    cinvoke strcat, addr buf, comma_space
    cinvoke strcat, addr buf, month.Aug
    cinvoke strcat, addr buf, period_newline
    cinvoke printf, addr buf
    ret
endp

proc main4 uses ebx esi edi
    cinvoke puts, '*** main4 ***'
    local buf[12]:DWORD
    mov esi, month.arr + 8
    lea edi, [buf]
    mov ecx, 10
.loop:
    mov eax, [esi]
    mov [edi], eax
    add esi, 4
    add edi, 4
    loop .loop
    mov [buf + 10 * 4], month.Jan
    mov [buf + 11 * 4], month.Feb
    lea esi, [buf]
    mov ebx, 4
.print_loop:
    cinvoke printf, fmt_3s, dword [esi], dword [esi + 4], dword [esi + 8]
    add esi, 12
    dec ebx
    jnz .print_loop
    ret
endp

include 'boilerplate/footer_data.inc'
include 'data/month.data.inc'
include 'data/season.data.inc'
include 'data/number.data.inc'
include 'data/name.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        strcat,         'strcat',\
        printf,         'printf',\
        puts,           'puts'
