include 'boilerplate/header.x86.inc'
include 'data/person.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    local person1:PERSON
    mov [person1.name], name.Olivia
    mov [person1.age], 50
    stdcall print_person, person.John
    stdcall print_person, person.Jane
    stdcall print_person, addr person1
    ret
endp

proc main2 uses ebx esi
    cinvoke puts, '*** main2 ***'
    mov esi, person__data.arr
    mov ebx, person__data.arr_len
.loop:
    stdcall print_person, esi
    add esi, sizeof.PERSON
    dec ebx
    jnz .loop
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    local person:PERSON_v2
    ret
endp

include 'boilerplate/footer_data.inc'
include 'data/person.data.inc'
include 'boilerplate/footer_idata.inc'
