format PE

include 'compiler_old.inc'
include 'win32ax.inc'

stdcall main
invoke ExitProcess, 0

include 'aspect_ratio.text.inc'

struct SIZE64
    cx dq ?
    cy dq ?
ends

struct FRAC32
    num dd ?
    den dd ?
ends

proc main uses ebx
    cinvoke puts, '*** main1 ***'
    local size:SIZE
    mov [size.cx], 16.0
    mov [size.cy], 9.0
    stdcall print_sizef32, addr size
    stdcall scale_aspect_ratio, addr size, 80.0, 1.0
    stdcall print_sizef32, addr size
    stdcall scale_aspect_ratio, addr size, 1.5, 1.0
    stdcall print_sizef32, addr size
    stdcall scale_aspect_ratio, addr size, 1.0, 120.0
    stdcall print_sizef32, addr size
    ret
endp

proc main2 uses ebx
    cinvoke puts, '*** main2 ***'
    stdcall print_ratio, 16, 9
    stdcall print_ratio, 1280, 720
    stdcall print_ratio, 1920, 1080
    ret
endp

.data
include 'util/format.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
