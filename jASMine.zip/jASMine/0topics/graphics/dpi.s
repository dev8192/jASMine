format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_3d      db '%d %d %d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

; DPI (Dots Per Inch)
proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_3d, 96, 1280, 720
    cinvoke printf, fmt_3d, 144, 1920, 1080
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
