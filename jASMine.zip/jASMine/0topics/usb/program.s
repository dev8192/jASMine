format PE console
entry start

include 'win32a.inc'

struct INPUT_RECORD
    EventType           dw ?
    dwPad1              dw ?
    bKeyDown            dd ?
    wRepeatCount        dw ?
    wVirtualKeyCode     dw ?
    wVirtualScanCode    dw ?
    UnicodeChar         dw ?
    dwControlKeyState   dd ?
ends

section '.data' data readable writeable
    handle          dd ?
    stdout          dd ?
    stdin           dd ?
    bytes_io        dd ?
    data_buffer     db ?

    msg_info        db 'Press SPACEBAR to flash the LED.', 13, 10
                    db 'Press ESC to exit program.', 13, 10
    msg_info_len  =  $ - msg_info

    ir_buffer INPUT_RECORD

section '.text' code readable executable
start:
    invoke FT_Open, 0, handle
    test eax, eax               ; FT_SUCCESS is 0
    jnz error_exit

    ; --- Step 2: Enable Bit-Bang Mode ---
    ; Mask = 0x01 (Sets TXD pin as output, others as input)
    ; Mode = 0x01 (Asynchronous Bit-Bang Mode)
    invoke FT_SetBitMode, [handle], 0x01, 0x01
    test eax, eax
    jnz close_exit

    ; --- Step 3: Print UI Instructions ---
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax
    invoke WriteConsole, [stdout], msg_info, msg_info_len, bytes_io, 0

main_loop:
    invoke GetStdHandle, STD_INPUT_HANDLE
    mov [stdin], eax
    invoke ReadConsoleInput, [stdin], ir_buffer, 1, bytes_io
    
    ; Check if it is a Key Event and if Key is Down
    mov ax, [ir_buffer.EventType]
    cmp ax, 0x0001              ; KEY_EVENT
    jne main_loop
    
    cmp [ir_buffer.bKeyDown], 1
    jne main_loop

    ; Check if the key pressed is the Spacebar
    cmp [ir_buffer.wVirtualKeyCode], 0x20 ; VK_SPACE
    je flash_led
    
    ; Check if the key pressed is Escape to quit
    cmp [ir_buffer.wVirtualKeyCode], 0x1B ; VK_ESCAPE
    je close_exit
    
    jmp main_loop

flash_led:
    ; --- Step 5: Turn LED On ---
    mov [data_buffer], 0x01     ; Set TXD pin high (5V)
    invoke FT_Write, [handle], data_buffer, 1, bytes_io

    ; Sleep for 200 milliseconds
    invoke Sleep, 200

    ; --- Step 6: Turn LED Off ---
    mov [data_buffer], 0x00     ; Set TXD pin low (0V)
    invoke FT_Write, [handle], data_buffer, 1, bytes_io

    jmp main_loop

close_exit:
    ; Clean up and close hardware handle
    invoke FT_Close, [handle]
error_exit:
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            ftd2xx,             'ftd2xx.dll'
    import  kernel32,\
            GetStdHandle,       'GetStdHandle',\
            WriteConsoleA,      'WriteConsoleA',\
            ReadConsoleInputA,  'ReadConsoleInputA',\
            Sleep,              'Sleep',\
            ExitProcess,        'ExitProcess'
    import  ftd2xx,\
            FT_Open,            'FT_Open',\
            FT_SetBitMode,      'FT_SetBitMode',\
            FT_Write,           'FT_Write',\
            FT_Close,           'FT_Close'
