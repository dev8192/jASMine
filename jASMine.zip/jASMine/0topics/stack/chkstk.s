format PE
entry start

include 'win32ax.inc'

section '.text' code readable executable
start:
    call main
    invoke ExitProcess, 0

proc main
    push ebp
    mov ebp, esp

    mov eax, 16384
    call _chkstk
    
    mov byte [esp], 'A'
    mov byte [esp + 16383], 'Z'

    mov esp, ebp
    pop ebp
    ret
endp

_chkstk:
    push    ecx
    lea     ecx, [esp + 8]
.probepages:
    cmp     eax, 4096
    jbe     .lastpage
    sub     ecx, 4096
    test    [ecx], eax
    sub     eax, 4096
    jmp     .probepages
.lastpage:
    sub     ecx, eax
    test    [ecx], eax
    mov     eax, esp
    mov     esp, ecx
    mov     ecx, [eax]
    mov     eax, [eax + 4]
    jmp     eax

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
