format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_dd      db '%2d : %2d', 10, 0
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main uses ebx
    cinvoke puts, '*** main1 ***'
    xor ebx, ebx
.loop:
    mov eax, ebx
    add eax, 3
    and eax, 0xFFFFFFFC
    cinvoke printf, fmt_dd, ebx, eax
    inc ebx
    cmp ebx, 20
    jb .loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
