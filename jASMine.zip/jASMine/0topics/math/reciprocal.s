; reciprocal multiplication
format PE

include 'compiler_old.inc'
include 'win32ax.inc'

stdcall main
cinvoke puts, 'done'
invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    mov edx, 32
    xor eax, eax
    mov ecx, 100
    div ecx
    inc eax
    cinvoke printf, fmt_x, eax
    cinvoke printf, fmt_x, 0x51EB851F
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall check_division_by_100, 300
    stdcall check_division_by_100, 2500
    ret
endp

proc divide_by_100_normal, num
    mov eax, [num]
    xor edx, edx
    mov ecx, 100
    div ecx
    ret
endp

proc divide_by_100_magic, num
    mov eax, [num]
    mov ecx, 0x51EB851F
    mul ecx
    shr edx, 5
    mov eax, edx
    ret
endp

proc check_division_by_100 uses ebx, num
    stdcall divide_by_100_normal, [num]
    mov ebx, eax
    stdcall divide_by_100_magic, [num]
    cinvoke printf, fmt_2d, ebx, eax
    ret
endp

.data
include 'util/format.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
