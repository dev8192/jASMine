format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    deg_45      dq 45.0
    deg_180     dq 180.0
    result      dq ?
    fmt_f       db '%f', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

shouldn't the derivation go like this?

180 degrees = pi radians
1 degree = pi / 180 radians
N degrees = N * pi / 180 radians

pi radians = 180 degrees
1 radian = 180 / pi degrees
N radians = N * 180 / pi degrees

proc degree_to_radian degree
    fld qword [degree]
    fldpi
    fmulp
    ret
endp

proc radian_to_degree radian
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    local result:QWORD
    stdcall degree_to_radian, 45
    
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    finit
    ; Convert 45 degrees to radians: (45 * pi) / 180
    fld qword [deg_45]
    fldpi                ; Push PI onto FPU stack
    fmulp                ; ST(1) = 45 * PI, then pop
    fdiv qword [deg_180] ; ST(0) = (45 * PI) / 180
    fsin
    fstp qword [result]
    cinvoke printf, fmt_f, dword [result], dword [result+4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
