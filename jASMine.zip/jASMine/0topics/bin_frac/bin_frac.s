include 'boilerplate/header.x86.inc'
include 'boilerplate/register_class.text.inc'
include 'boilerplate/create_window__xywh.text.inc'
include 'boilerplate/message_loop.text.inc'
include 'boilerplate/vbox.inc'
include 'boilerplate/vbox.text.inc'

struct APP
    h_heap      dd ?
    pos_x       dd ?
    pos_y       dd ?
    font_name   dd ?
    font_size   dd ?
    h_font      dd ?
    widget_gap  dd ?
    bit_values  dw ?
    bits_widget dd ?
    buttons     dd ?
    sum_widget  dd ?
ends

struct BITS_WIDGET
    pos_x       dd ?
    pos_y       dd ?
    box_w       dd ?
    box_h       dd ?
    color0      dd ?
    color1      dd ?
    gap         dd ?
    dot_size    dd ?
    total_width dd ?
    app         dd ?
ends

struct BUTTONS VBOX
    hwnd_shl    dd ?
    hwnd_shr    dd ?
    hwnd_ones   dd ?
    hwnd_zeros  dd ?
ends

struct SUM_WIDGET
    pos_x       dd ?
    pos_y       dd ?
    col1        dd ?
    col2        dd ?
    app         dd ?
ends

ID_SHIFT_LEFT  = 101
ID_SHIFT_RIGHT = 102
ID_ALL_ONES    = 103
ID_ALL_ZEROS   = 104

proc main0
    cinvoke puts, '*** main0 ***'
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall bin_frac__create, 20, 20
    mov [app_ptr], eax
    stdcall register_class
    stdcall create_window__xywh, 0, 0, 600, 600
    stdcall message_loop
    stdcall bin_frac__free, [app_ptr]
    ret
endp

proc bin_frac__free p_app
    mov ebx, [p_app]
    invoke HeapFree, [ebx + APP.h_heap], 0, [ebx + APP.bits_widget]
    invoke HeapFree, [ebx + APP.h_heap], 0, [ebx + APP.buttons]
    invoke HeapFree, [ebx + APP.h_heap], 0, [ebx + APP.sum_widget]
    invoke HeapFree, [ebx + APP.h_heap], 0, ebx
    ret
endp

proc bits_widget__create uses ebx, h_heap, pos_x, pos_y
    invoke HeapAlloc, [h_heap], 0, sizeof.BITS_WIDGET
    mov ebx, eax
    copy32 ebx + BITS_WIDGET.pos_x, pos_x
    copy32 ebx + BITS_WIDGET.pos_y, pos_y
    mov [ebx + BITS_WIDGET.box_w], 25
    mov [ebx + BITS_WIDGET.box_h], 35
    mov [ebx + BITS_WIDGET.gap], 5
    mov [ebx + BITS_WIDGET.dot_size], 5
    invoke GetStockObject, LTGRAY_BRUSH
    mov [ebx + BITS_WIDGET.color0], eax
    invoke CreateSolidBrush, 0xE2705A
    mov [ebx + BITS_WIDGET.color1], eax
    mov eax, [ebx + BITS_WIDGET.box_w]
    add eax, [ebx + BITS_WIDGET.gap]
    shl eax, 4
    add eax, [ebx + BITS_WIDGET.dot_size]
    mov [ebx + BITS_WIDGET.total_width], eax
    mov eax, ebx
    ret
endp

proc buttons__create uses ebx, h_heap, pos_x, pos_y, h_font
    invoke HeapAlloc, [h_heap], 0, sizeof.BUTTONS
    mov ebx, eax
    copy32 ebx + BUTTONS.pos_x, pos_x
    copy32 ebx + BUTTONS.pos_y, pos_y
    mov [ebx + BUTTONS.box_w], 110
    mov [ebx + BUTTONS.box_h], 25
    mov [ebx + BUTTONS.gap], 5
    mov [ebx + BUTTONS.count], 0
    copy32 ebx + BUTTONS.h_font, h_font
    mov eax, ebx
    ret
endp

proc sum_widget__create uses ebx, h_heap, pos_x, pos_y
    invoke HeapAlloc, [h_heap], 0, sizeof.SUM_WIDGET
    mov ebx, eax
    copy32 ebx + SUM_WIDGET.pos_x, pos_x
    copy32 ebx + SUM_WIDGET.pos_y, pos_y
    copy32 ebx + SUM_WIDGET.col1, ebx + SUM_WIDGET.pos_x
    copy32 ebx + SUM_WIDGET.col2, ebx + SUM_WIDGET.col1
    add [ebx + SUM_WIDGET.col2], 150
    mov eax, ebx
    ret
endp

proc bin_frac__create uses ebx esi, pos_x, pos_y
    local h_heap:DWORD

    invoke GetProcessHeap
    mov [h_heap], eax
    invoke HeapAlloc, [h_heap], 0, sizeof.APP
    mov ebx, eax

    copy32 ebx + APP.h_heap, h_heap
    copy32 ebx + APP.pos_x, pos_x
    copy32 ebx + APP.pos_y, pos_y
    mov [ebx + APP.font_size], 24
   ;mov [ebx + APP.font_name], 0
    mov [ebx + APP.font_name], str_Consolas
   ;mov [ebx + APP.font_name], str_Lucida_Console
   ;mov [ebx + APP.font_name], str_Courier_New
    mov [ebx + APP.bit_values], 0
    mov [ebx + APP.widget_gap], 20

    invoke CreateFont, [ebx + APP.font_size], 0, 0, 0, FW_NORMAL, 0, 0, 0,\
        DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,\
        DEFAULT_QUALITY, FIXED_PITCH + FF_DONTCARE, [ebx + APP.font_name]
    mov [ebx + APP.h_font], eax

    stdcall bits_widget__create, [h_heap], [ebx + APP.pos_x], [ebx + APP.pos_y]
    mov [ebx + APP.bits_widget], eax

    mov eax, [ebx + APP.pos_y]
    mov esi, [ebx + APP.bits_widget]
    add eax, [esi + BITS_WIDGET.box_h]
    add eax, [ebx + APP.widget_gap]
    stdcall buttons__create, [h_heap], [ebx + APP.pos_x], eax, ebx + APP.h_font
    mov [ebx + APP.buttons], eax

    mov esi, [ebx + APP.buttons]
    mov eax, [esi + BUTTONS.pos_x]
    add eax, [esi + BUTTONS.box_w]
    add eax, [ebx + APP.widget_gap]
    mov ecx, [ebx + APP.pos_y]
    mov esi, [ebx + APP.bits_widget]
    add ecx, [esi + BITS_WIDGET.box_h]
    add ecx, [ebx + APP.widget_gap]
    stdcall sum_widget__create, [h_heap], eax, ecx
    mov [ebx + APP.sum_widget], eax

    mov eax, ebx
    ret
endp

proc window_proc uses ebx, hwnd, wmsg, wparam, lparam
    local ps:PAINTSTRUCT, rect:RECT
    mov ebx, [app_ptr]
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_LBUTTONDOWN
    je .wm_lbutton_down
    cmp [wmsg], WM_COMMAND
    je .wm_command
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .finish
.wm_create:
    mov ebx, [ebx + APP.buttons]
    copy32 ebx + BUTTONS.hwnd, hwnd
    stdcall vbox__add_button, ebx, btn_text_shl, WS_DISABLED, ID_SHIFT_LEFT
    mov [ebx + BUTTONS.hwnd_shl], eax
    stdcall vbox__add_button, ebx, btn_text_shr, WS_DISABLED, ID_SHIFT_RIGHT
    mov [ebx + BUTTONS.hwnd_shr], eax
    stdcall vbox__add_button, ebx, btn_text_ones, 0, ID_ALL_ONES
    mov [ebx + BUTTONS.hwnd_ones], eax
    stdcall vbox__add_button, ebx, btn_text_zeros, 0, ID_ALL_ZEROS
    mov [ebx + BUTTONS.hwnd_zeros], eax
    stdcall update_ui_state, [hwnd]
    xor eax, eax
    jmp .finish
.wm_lbutton_down:
    stdcall handle_click, [hwnd], [lparam]
    xor eax, eax
    jmp .finish
.wm_command:
    mov eax, [wparam]
    cmp ax, ID_SHIFT_LEFT
    je .cmd_shl
    cmp ax, ID_SHIFT_RIGHT
    je .cmd_shr
    cmp ax, ID_ALL_ONES
    je .cmd_ones
    cmp ax, ID_ALL_ZEROS
    je .cmd_zeros
    jmp .cmd_done
.cmd_shl:
    shl [ebx + APP.bit_values], 1
    stdcall update_ui_state, [hwnd]
    jmp .cmd_done
.cmd_shr:
    shr [ebx + APP.bit_values], 1
    stdcall update_ui_state, [hwnd]
    jmp .cmd_done
.cmd_ones:
    mov [ebx + APP.bit_values], 0xFFFF
    stdcall update_ui_state, [hwnd]
    jmp .cmd_done
.cmd_zeros:
    mov [ebx + APP.bit_values], 0
    stdcall update_ui_state, [hwnd]
.cmd_done:
    xor eax, eax
    jmp .finish
.wm_paint:
    invoke BeginPaint, [hwnd], addr ps
   ;stdcall bits_widget__draw_bounding_box, [ps.hdc]
    stdcall bits_widget__draw, [ps.hdc]
    stdcall sum_widget__draw, [ps.hdc]
    invoke EndPaint, [hwnd], addr ps
    xor eax, eax
    jmp .finish
.wm_destroy:
    invoke DeleteObject, [ebx + APP.h_font]
    mov ebx, [ebx + APP.bits_widget]
    invoke DeleteObject, [ebx + BITS_WIDGET.color1]
    invoke PostQuitMessage, 0
    xor eax, eax
.finish:
    ret
endp

proc bits_widget__draw_bounding_box, hdc
    local rect:RECT
    mov ecx, [app_ptr]
    mov ecx, [ecx + APP.bits_widget]
    copy32 rect.left, ecx + BITS_WIDGET.pos_x
    add eax, [ecx + BITS_WIDGET.total_width]
    mov [rect.right], eax
    copy32 rect.top, ecx + BITS_WIDGET.pos_y
    add eax, [ecx + BITS_WIDGET.box_h]
    mov [rect.bottom], eax
    invoke FillRect, [hdc], addr rect, COLOR_HIGHLIGHT+1
    ret
endp

proc bits_widget__draw uses ebx esi, hdc
    local counter:DWORD, current_x:DWORD, rect:RECT, h_brush:DWORD
    local bit_values:WORD, char_buf:BYTE, old_font:DWORD
    mov [counter], 0
    mov [char_buf], '0'
    invoke SetBkMode, [hdc], TRANSPARENT
    invoke SetTextColor, [hdc], 0
    mov ebx, [app_ptr]
    copy16 bit_values, ebx + APP.bit_values
    invoke SelectObject, [hdc], [ebx + APP.h_font]
    mov [old_font], eax
    mov esi, [ebx + APP.bits_widget]
    copy32 current_x, esi + BITS_WIDGET.pos_x
.loop_bits:
    cmp [counter], 16
    jg .loop_done
    cmp [counter], 8
    je .draw_dot
    shl [bit_values], 1
    setc al
    mov cl, '0'
    add cl, al
    mov [char_buf], cl
    movzx eax, al
    shl eax, 2
    lea ecx, [esi + BITS_WIDGET.color0]
    add eax, ecx
    copy32 h_brush, eax
    copy32 rect.left, current_x
    add eax, [esi + BITS_WIDGET.box_w]
    mov [rect.right], eax
    copy32 rect.top, esi + BITS_WIDGET.pos_y
    add eax, [esi + BITS_WIDGET.box_h]
    mov [rect.bottom], eax
    invoke SelectObject, [hdc], [h_brush]
    mov [h_brush], eax
    invoke RoundRect, [hdc], [rect.left], [rect.top], [rect.right], [rect.bottom], 7, 7
    invoke SelectObject, [hdc], [h_brush]
    invoke DrawText, [hdc], addr char_buf, 1, addr rect,\
        DT_CENTER + DT_VCENTER + DT_SINGLELINE
    mov eax, [esi + BITS_WIDGET.box_w]
    add eax, [esi + BITS_WIDGET.gap]
    add [current_x], eax
    jmp .continue
.draw_dot:
    copy32 rect.left, current_x
    add eax, [esi + BITS_WIDGET.dot_size]
    mov [rect.right], eax
    mov eax, [esi + BITS_WIDGET.pos_y]
    add eax, [esi + BITS_WIDGET.box_h]
    mov [rect.bottom], eax
    sub eax, [esi + BITS_WIDGET.dot_size]
    mov [rect.top], eax
    invoke GetStockObject, BLACK_BRUSH
    invoke SelectObject, [hdc], eax
    mov [h_brush], eax
    invoke Ellipse, [hdc], [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke SelectObject, [hdc], [h_brush]
    mov eax, [esi + BITS_WIDGET.dot_size]
    add eax, [esi + BITS_WIDGET.gap]
    add [current_x], eax
.continue:
    inc [counter]
    jmp .loop_bits
.loop_done:
    invoke SelectObject, [hdc], [old_font]
    ret
endp

proc sum_widget__draw uses ebx esi, hdc
    local term_buf[64]:BYTE, pow_buf[32]:BYTE
    local counter:DWORD, has_terms:DWORD, bit_mask:DWORD
    local current_y:DWORD, old_font:DWORD
    mov ebx, [app_ptr]
    mov eax, [ebx + APP.h_font]
    invoke SelectObject, [hdc], eax
    mov [old_font], eax
    mov esi, [ebx + APP.sum_widget]
    copy32 current_y, esi + SUM_WIDGET.pos_y
    mov [counter], 0
    mov [has_terms], 0
    mov [bit_mask], 0x8000
    locals
        pow_val dd 7
        term_val dd 0
    endl
    invoke SetBkMode, [hdc], TRANSPARENT
    invoke SetTextColor, [hdc], 0
.loop_terms:
    cmp [counter], 16
    jge .loop_done
    mov eax, [bit_mask]
    test [ebx + APP.bit_values], ax
    jz .next_term
    mov [has_terms], 1
    cmp [counter], 8
    jge .fractional_part
    mov ecx, 7
    sub ecx, [counter]
    mov [pow_val], ecx
    mov eax, 1
    shl eax, cl
    mov [term_val], eax
    cinvoke sprintf, addr term_buf, fmt_int, [term_val]
    cinvoke sprintf, addr pow_buf, fmt_pow_pos, [pow_val]
    stdcall sum_widget__draw_row, [hdc], addr term_buf, addr pow_buf, [current_y]
    add [current_y], 20
    jmp .next_term
.fractional_part:
    mov eax, [counter]
    sub eax, 7
    mov [pow_val], eax
    stdcall sum_widget__format_frac, eax, addr term_buf
    cinvoke sprintf, addr pow_buf, fmt_pow_neg, [pow_val]
    stdcall sum_widget__draw_row, [hdc], addr term_buf, addr pow_buf, [current_y]
    add [current_y], 20
.next_term:
    shr [bit_mask], 1
    inc [counter]
    jmp .loop_terms
.loop_done:
    cmp [has_terms], 0
    jne .draw_total
    cinvoke sprintf, addr term_buf, fmt_int, 0
    mov [pow_buf], 0
    stdcall sum_widget__draw_row, [hdc], addr term_buf, addr pow_buf, [current_y]
    add [current_y], 20
.draw_total:
    add [current_y], 5
    invoke MoveToEx, [hdc], [esi + SUM_WIDGET.col1], [current_y], 0
    invoke LineTo, [hdc], [esi + SUM_WIDGET.col2], [current_y]
    add [current_y], 7
    stdcall format_total_value, addr term_buf
    mov [pow_buf], 0
    stdcall sum_widget__draw_row, [hdc], addr term_buf, addr pow_buf, [current_y]
.finish:
    invoke SelectObject, [hdc], [old_font]
    ret
endp

proc draw_text hdc, pos_x, pos_y, buf
    invoke lstrlenA, [buf]
    invoke TextOutA, [hdc], [pos_x], [pos_y], [buf], eax
    ret
endp

proc sum_widget__draw_row uses ebx, hdc, str_num, str_pow, y_pos
    mov ebx, [app_ptr]
    mov ebx, [ebx + APP.sum_widget]
    mov eax, [ebx + SUM_WIDGET.col1]
    stdcall draw_text, [hdc], eax, [y_pos], [str_num]
    mov eax, [ebx + SUM_WIDGET.col2]
    stdcall draw_text, [hdc], eax, [y_pos], [str_pow]
    ret
endp

proc sum_widget__format_frac uses esi, pow, buffer
    mov eax, 100000000
    mov ecx, [pow]
    shr eax, cl
    mov esi, [buffer]
    cinvoke sprintf, esi, '  0.%08d', eax
    add esi, eax
.trim_back:
    dec esi
    cmp byte [esi], '0'
    jne .finish
    mov byte [esi], 0
    jmp .trim_back
.finish:
    ret
endp

proc format_total_value1 uses esi, buffer
    mov eax, [app_ptr]
    movzx eax, word [eax + APP.bit_values]
    mov edx, eax
    shr edx, 8
    movzx eax, al
    imul eax, 390625
    test eax, eax
    jnz .has_frac
    cinvoke sprintf, [buffer], fmt_int, edx
    jmp .finish
.has_frac:
    mov esi, [buffer]
    cinvoke sprintf, esi, '%d.%08d', edx, eax
    add esi, eax
.trim_loop:
    dec esi
    cmp byte [esi], '0'
    jne .finish
    mov byte [esi], 0
    jmp .trim_loop
.finish:
    ret
endp

proc format_total_value uses esi,buffer
    mov eax, [app_ptr]
    movzx eax, word [eax + APP.bit_values]
    mov edx, eax
    shr edx, 8
    movzx eax, al
    imul eax, 390625
    mov esi, [buffer]
    cinvoke sprintf, esi, '%3d.%08d', edx, eax
    add esi, eax
.trim_loop:
    dec esi
    cmp byte [esi], '0'
    je .strip_char
    cmp byte [esi], '.'
    jne .finish
    cmp esi, [buffer]
    je .keep_zero
    mov byte [esi], 0
    jmp .finish
.strip_char:
    mov byte [esi], 0
    jmp .trim_loop
.keep_zero:
    mov byte [esi], '0'
.finish:
    ret
endp

proc update_ui_state uses ebx esi edi, hwnd
    mov ebx, [app_ptr]
    movzx eax, [ebx + APP.bit_values]
    test eax, eax
    setnz dl
    test eax, 0x8000
    setz cl
    and cl, dl
    movzx esi, cl
    test eax, 1
    setz cl
    and cl, dl
    movzx edi, cl
    mov ebx, [ebx + APP.buttons]
    invoke EnableWindow, [ebx + BUTTONS.hwnd_shl], esi
    invoke EnableWindow, [ebx + BUTTONS.hwnd_shr], edi
    invoke InvalidateRect, [hwnd], NULL, TRUE
    ret
endp

proc check_boxes, click_x, box_right
    ret
endp

proc handle_click uses ebx esi, hwnd, lparam
    locals
        click_x     dd 0
        click_y     dd 0
        counter     dd 0
        box_left    dd 0
        box_right   dd 0
        bit_mask    dd 0x8000
    endl
    mov eax, [lparam]
    and eax, 0xFFFF
    mov [click_x], eax
    mov eax, [lparam]
    shr eax, 16
    mov [click_y], eax
    mov ebx, [app_ptr]
    mov esi, [ebx + APP.bits_widget]
    mov eax, [esi + BITS_WIDGET.pos_y]
    cmp [click_y], eax
    jl .finish
    add eax, [esi + BITS_WIDGET.box_h]
    cmp [click_y], eax
    jg .finish
    mov eax, [esi + BITS_WIDGET.pos_x]
    cmp [click_x], eax
    jl .finish
    add eax, [esi + BITS_WIDGET.total_width]
    cmp [click_x], eax
    jg .finish
    mov eax, [esi + BITS_WIDGET.pos_x]
    mov [box_left], eax
.loop_hit:
    cmp [counter], 16
    jg .finish
    cmp [counter], 8
    je .skip
    mov eax, [box_left]
    add eax, [esi + BITS_WIDGET.box_w]
    mov [box_right], eax
    mov eax, [click_x]
    cmp eax, [box_left]
    jl .next_box
    cmp eax, [box_right]
    jg .next_box
    mov eax, [bit_mask]
    xor [ebx + APP.bit_values], ax
    stdcall update_ui_state, [hwnd]
    jmp .finish
.skip:
    mov eax, [esi + BITS_WIDGET.dot_size]
    add eax, [esi + BITS_WIDGET.gap]
    add [box_left], eax
    jmp .continue
.next_box:
    mov eax, [esi + BITS_WIDGET.box_w]
    add eax, [esi + BITS_WIDGET.gap]
    add [box_left], eax
    shr [bit_mask], 1
.continue:
    inc [counter]
    jmp .loop_hit
.finish:
    ret
endp

.data
include 'util/format.data.inc'
include 'boilerplate/register_class.data.inc'
include 'boilerplate/create_window.data.inc'
include 'boilerplate/vbox.data.inc'

btn_text_shl        db 'Shift left', 0
btn_text_shr        db 'Shift right', 0
btn_text_ones       db 'All ones', 0
btn_text_zeros      db 'All zeros', 0
str_Consolas        db 'Consolas', 0
str_Lucida_Console  db 'Lucida Console', 0
str_Courier_New     db 'Courier New', 0
fmt_int             db '%3d', 0
fmt_pow_pos         db ' (2^%d)', 0
fmt_pow_neg         db ' (2^-%d)', 0
app_ptr             dd ?

.idata
library kernel32,           'kernel32.dll',\
        user32,             'user32.dll',\
        gdi32,              'gdi32.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        GetModuleHandle,    'GetModuleHandleA',\
        lstrlenA,           'lstrlenA',\
        GetProcessHeap,     'GetProcessHeap',\
        HeapAlloc,          'HeapAlloc',\
        HeapFree,           'HeapFree',\
        ExitProcess,        'ExitProcess'
import  user32,\
        LoadCursor,         'LoadCursorA',\
        RegisterClass,      'RegisterClassA',\
        CreateWindowEx,     'CreateWindowExA',\
        GetMessage,         'GetMessageA',\
        DispatchMessage,    'DispatchMessageA',\
        DefWindowProc,      'DefWindowProcA',\
        PostQuitMessage,    'PostQuitMessage',\
        BeginPaint,         'BeginPaint',\
        EndPaint,           'EndPaint',\
        DrawText,           'DrawTextA',\
        FillRect,           'FillRect',\
        SendMessage,        'SendMessageA',\
        SetWindowText,      'SetWindowTextA',\
        EnableWindow,       'EnableWindow',\
        InvalidateRect,     'InvalidateRect'
import  gdi32,\
        GetStockObject,     'GetStockObject',\
        CreateSolidBrush,   'CreateSolidBrush',\
        CreateFont,         'CreateFontA',\
        SelectObject,       'SelectObject',\
        DeleteObject,       'DeleteObject',\
        SetBkMode,          'SetBkMode',\
        SetTextColor,       'SetTextColor',\
        RoundRect,          'RoundRect',\
        Ellipse,            'Ellipse',\
        TextOutA,           'TextOutA',\
        MoveToEx,           'MoveToEx',\
        LineTo,             'LineTo'
import  msvcrt,\
        sprintf,            'sprintf',\
        printf,             'printf',\
        puts,               'puts'
