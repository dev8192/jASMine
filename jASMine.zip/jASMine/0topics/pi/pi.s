include 'compiler/header.x86.inc'
include 'pi.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall print_pi_frac1
    stdcall print_pi_frac2
    stdcall print_pi_frac3
    ret
endp

include 'compiler/footer.inc'
