format PE CONSOLE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt         db 'Input: %d -> Normal: %d, Branchless: %d', 10, 0

section '.code' code readable executable
start:
    push    [test_val1]
    stdcall    print_abs_results, -42

    push    [test_val2]
    stdcall    print_abs_results, 15

    invoke  ExitProcess, 0

proc print_abs_results val
    stdcall abs1, [val]
    mov     ebx, eax

    stdcall abs2, [val]
    
    invoke  printf, fmt, [val], ebx, eax
    ret
endp

proc abs1 val
    mov     eax, [val]
    test    eax, eax
    jge     .done
    neg     eax
.done:
    ret
endp

; --- METHOD 2: BRANCHLESS (Bit Twiddling) ---
; Uses CDQ to create a sign mask (0 if pos, -1 if neg).
proc abs2 val
    mov     eax, [val]
    cdq                 ; EAX -> EDX:EAX. EDX becomes 0x00000000 (pos) or 0xFFFFFFFF (neg)
    xor     eax, edx    ; If neg: flips all bits (1s complement)
    sub     eax, edx    ; If neg: subtracts -1 (effectively adds 1), completing 2s complement
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
