include 'boilerplate/header.x64.inc'
include 'util/leap_year.text.x64.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    local normal_years:QWORD, leap_years:QWORD
    stdcall count_leap_years, 1601, 1970
    mov [leap_years], rax
    mov rax, 1970
    sub rax, 1601
    sub rax, [leap_years]
    mov [normal_years], rax
    cinvoke printf, fmt_llu, [normal_years]
    cinvoke printf, fmt_llu, 280
    cinvoke printf, fmt_llu, [leap_years]
    cinvoke printf, fmt_llu, 89
    ret
endp

proc main uses rbx
    cinvoke puts, '*** main11 ***'
    stdcall count_leap_years, 1601, 1970
    mov rbx, rax
    mov rax, 1970
    sub rax, 1601
    sub rax, rbx
    cinvoke printf, fmt_llu, rax
    cinvoke printf, fmt_llu, 280
    cinvoke printf, fmt_llu, rbx
    cinvoke printf, fmt_llu, 89
    ret
endp

proc main2 uses rbx
    cinvoke puts, '*** main2 ***'
    mov rax, 280
    imul rax, 365
    mov rcx, 89
    imul rcx, 366
    add rax, rcx
    mov rbx, rax
    cinvoke printf, fmt_llu, rbx ; days
    cinvoke printf, fmt_llu, 134774

    mov rax, rbx
    imul rax, 24
    mov rbx, rax
    cinvoke printf, fmt_llu, rbx ; hours
    cinvoke printf, fmt_llu, 3234576

    mov rax, rbx
    imul rax, 60
    mov rbx, rax
    cinvoke printf, fmt_llu, rbx ; minutes
    cinvoke printf, fmt_llu, 194074560

    mov rax, rbx
    imul rax, 60
    mov rbx, rax
    cinvoke printf, fmt_llu, rbx ; seconds
    cinvoke printf, fmt_llu, 11644473600

    mov rax, rbx
    imul rax, 1000
    mov rbx, rax
    cinvoke printf, fmt_llu, rbx ; milliseconds
    cinvoke printf, fmt_llu, 11644473600000

    mov rax, rbx
    imul rax, 1000
    mov rbx, rax
    cinvoke printf, fmt_llu, rbx ; microseconds
    cinvoke printf, fmt_llu, 11644473600000000

    mov rax, rbx
    imul rax, 10
    mov rbx, rax
    cinvoke printf, fmt_llu, rbx ; 100-nanosecond intervals
    cinvoke printf, fmt_llu, 116444736000000000
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    mov rax, 280
    imul rax, 365
    mov rcx, 89
    imul rcx, 366
    add rax, rcx
    imul rax, 24
    imul rax, 60
    imul rax, 60
    imul rax, 1000
    imul rax, 1000
    imul rax, 10
    cinvoke printf, fmt_llu, rax
    cinvoke printf, fmt_llu, 116444736000000000
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    mov rax, 24
    imul rax, 60
    imul rax, 60
    imul rax, 1000
    imul rax, 1000
    imul rax, 10
    cinvoke printf, fmt_llu, rax
    cinvoke printf, fmt_llu, 864000000000
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    mov rax, 280
    imul rax, 365
    mov rcx, 89
    imul rcx, 366
    add rax, rcx
    mov rcx, 864000000000
    imul rax, rcx
    cinvoke printf, fmt_llu, rax
    cinvoke printf, fmt_llu, 116444736000000000
    ret
endp

include 'boilerplate/footer.inc'
