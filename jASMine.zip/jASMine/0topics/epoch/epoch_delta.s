include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    mov eax, 24
    mov ecx, 60
    mul ecx
    mul ecx
    cinvoke printf, fmt_d, eax
    cinvoke printf, fmt_d, 86400
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local result:QWORD
    mov eax, 280
    imul eax, 365
    mov ecx, 89
    imul ecx, 366
    add eax, ecx
    mov dword [result], eax
    cinvoke printf, fmt_llu, double [result] ; days
    cinvoke printf, fmt_llu, double 134774

    mov eax, dword [result]
    mov ecx, 86400
    mul ecx
    mov dword [result], eax
    mov dword [result + 4], edx
    cinvoke printf, fmt_llu, double [result] ; seconds
    cinvoke printf, fmt_llu, double 11644473600

    mov ecx, 10000000
    mov eax, dword [result]
    mul ecx
    mov dword [result], eax
    push edx
    mov eax, dword [result + 4]
    mul ecx
    pop edx
    add eax, edx
    mov dword [result + 4], eax
    cinvoke printf, fmt_llu, double [result] ; 100-nanosecond intervals
    cinvoke printf, fmt_llu, double 116444736000000000

    ret
endp

include 'boilerplate/footer.inc'
