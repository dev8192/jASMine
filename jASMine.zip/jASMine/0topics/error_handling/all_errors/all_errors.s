; not working
format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable

    szFmt           db "[%s]", 10, "Error %d: %s", 0
    
    szMissingFile   db "C:\ThisFileDoesNotExist_12345.txt", 0
    szMissingPath   db "C:\This\Path\Does\Not\Exist\file.txt", 0
    szSystemDir     db "C:\Windows", 0
    szValidFile     db "NUL", 0
    szBadName       db "C:\<Invalid>\Name.txt", 0

    szCtx1          db "DeleteFile on non-existent file (ERROR_FILE_NOT_FOUND)", 0
    szCtx2          db "CreateFile on non-existent path (ERROR_PATH_NOT_FOUND)", 0
    szCtx3          db "CreateFile writing to C:\Windows (ERROR_ACCESS_DENIED)", 0
    szCtx4          db "CloseHandle on invalid handle (ERROR_INVALID_HANDLE)", 0
    szCtx5          db "CreateFile with invalid creation disposition (ERROR_INVALID_PARAMETER)", 0
    szCtx6          db "CreateFile with invalid characters in name (ERROR_INVALID_NAME)", 0

section '.code' code readable executable

proc PrintError szContext
    local errCode dd ?
    local pBuffer dd ?

    invoke  GetLastError
    mov     [errCode], eax

    lea     eax, [pBuffer]
    invoke  FormatMessage, 1300h, 0, [errCode], 0, eax, 0, 0

    cinvoke printf, szFmt, szContext, [errCode], [pBuffer]

    invoke  LocalFree, [pBuffer]
    ret
endp

start:
    invoke  DeleteFile, szMissingFile
    invoke  PrintError, szCtx1

    invoke  CreateFile, szMissingPath, GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0
    invoke  PrintError, szCtx2

    invoke  CreateFile, szSystemDir, GENERIC_WRITE, 0, 0, OPEN_EXISTING, 0, 0
    invoke  PrintError, szCtx3

    invoke  CloseHandle, 12345678h
    invoke  PrintError, szCtx4

    invoke  CreateFile, szValidFile, GENERIC_READ, 0, 0, 0, 0, 0
    invoke  PrintError, szCtx5

    invoke  CreateFile, szBadName, GENERIC_READ, 0, 0, OPEN_EXISTING, 0, 0
    invoke  PrintError, szCtx6

    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           CloseHandle, 'CloseHandle',\
           CreateFile, 'CreateFileA',\
           DeleteFile, 'DeleteFileA',\
           ExitProcess, 'ExitProcess',\
           FormatMessage, 'FormatMessageA',\
           GetLastError, 'GetLastError',\
           LocalFree, 'LocalFree'

    import msvcrt,\
           printf, 'printf'
