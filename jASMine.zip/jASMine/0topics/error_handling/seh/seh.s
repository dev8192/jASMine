format PE CONSOLE
entry start

include 'win32a.inc'

ExceptionContinueExecution equ 0
CONTEXT_EIP_OFFSET         equ 0xB8

section '.data' data readable writeable
    szBefore    db 'Triggering access violation (writing to address 0)...', 10, 0
    szRecovered db 'Access violation caught! Execution resumed safely.', 10, 0

section '.code' code readable executable
start:
    push    seh_handler
    push    dword [fs:0]
    mov     dword [fs:0], esp
    cinvoke printf, szBefore
    xor     eax, eax
    mov     dword [eax], 0

safe_landing:
    pop     dword [fs:0]
    add     esp, 4
    cinvoke printf, szRecovered
    invoke  ExitProcess, 0

seh_handler1:
    mov     eax, [esp + 12]
    mov     dword [eax + CONTEXT_EIP_OFFSET], safe_landing
    mov     eax, ExceptionContinueExecution
    ret

proc seh_handler c, pExceptionRecord, pEstablisherFrame, pContextRecord, pDispatcherContext
    mov     eax, [pContextRecord]
    mov     dword [eax + CONTEXT_EIP_OFFSET], safe_landing
    mov     eax, ExceptionContinueExecution
    ret
endp

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL',\
            msvcrt,   'MSVCRT.DLL'

    import  kernel32,\
            ExitProcess, 'ExitProcess'

    import  msvcrt,\
            printf, 'printf'
