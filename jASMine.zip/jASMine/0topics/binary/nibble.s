; 'nibble' is a 4-bit number
include 'boilerplate/header.x86.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_3d, 0000b, 0x0, 0
    cinvoke printf, fmt_3d, 0001b, 0x1, 1
    cinvoke printf, fmt_3d, 0010b, 0x2, 2
    cinvoke printf, fmt_3d, 0011b, 0x3, 3
    cinvoke printf, fmt_3d, 0100b, 0x4, 4
    cinvoke printf, fmt_3d, 0101b, 0x5, 5
    cinvoke printf, fmt_3d, 0110b, 0x6, 6
    cinvoke printf, fmt_3d, 0111b, 0x7, 7
    cinvoke printf, fmt_3d, 1000b, 0x8, 8
    cinvoke printf, fmt_3d, 1001b, 0x9, 9
    cinvoke printf, fmt_3d, 1010b, 0xA, 10
    cinvoke printf, fmt_3d, 1011b, 0xB, 11
    cinvoke printf, fmt_3d, 1100b, 0xC, 12
    cinvoke printf, fmt_3d, 1101b, 0xD, 13
    cinvoke printf, fmt_3d, 1110b, 0xE, 14
    cinvoke printf, fmt_3d, 1111b, 0xF, 15
    ret
endp

include 'boilerplate/footer.inc'
