format PE
entry start

include 'win32a.inc'

BITS_PER_BYTE   = 8

section '.data' data readable writeable
    buf1        db 'abc', 0
    buf1_len    = $ - buf1

section '.text' code readable executable
start:
    invoke print_binary, buf1, buf1_len
    invoke ExitProcess, 0

proc print_binary uses ebx esi edi, pbuf, len
    mov esi, [pbuf]
    mov edi, [len]
    test edi, edi
    jle .done

.byte_loop:
    push edi
    mov bl, byte [esi]
    mov edi, BITS_PER_BYTE

.bit_loop:
    push edi
    shl bl, 1
    setc al
    add al, '0'
    movzx eax, al
    cinvoke putchar, eax
    pop edi
    dec edi
    jnz .bit_loop

    cinvoke putchar, ' '
    pop edi
    inc esi
    dec edi
    jnz .byte_loop

.done:
    cinvoke putchar, 10
    ret
endp

section '.idata' import data readable

    library msvcrt, 'MSVCRT.DLL', \
        kernel32, 'KERNEL32.DLL'

    import msvcrt, \
        putchar, 'putchar'

    import kernel32, \
        ExitProcess, 'ExitProcess'
