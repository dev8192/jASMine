format binary as 'bmp'

; === BITMAP FILE HEADER (14 bytes) ===
db 'BM'                ; Magic number (2 bytes)
dd file_end                  ; Total file size in bytes (4 bytes)
dw 0, 0                ; Reserved fields (4 bytes total)
dd pixel_data          ; Offset to pixel data start (4 bytes)

; === BITMAP CORE HEADER / DIB (12 bytes) ===
dd 12                  ; Header size (4 bytes)
dw 1                   ; Width: 1 pixel (2 bytes)
dw 1                   ; Height: 1 pixel (2 bytes)
dw 1                   ; Planes: must be 1 (2 bytes)
dw 24                  ; Bits per pixel: 24-bit True Color (2 bytes)

; === PIXEL DATA (4 bytes) ===
pixel_data:
db 0x00, 0x00, 0xFF    ; Blue, Green, Red (BGR format = Pure Red)
db 0x00                ; Padding byte to align row to 4-byte boundary

file_end = $%%
