format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_d       db '%d', 10, 0
    fname       db 'image.bmp', 0
    fmode       db 'wb', 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, sizeof.BITMAPFILEHEADER ; 14
    cinvoke printf, fmt_d, sizeof.BITMAPINFOHEADER ; 40
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    local width:DWORD, height:DWORD
    local pixel_count:DWORD, buf_size:DWORD, file_size:DWORD
    mov [width], 256
    mov [height], 256
    mov eax, [width]
    mul [height]
    mov [pixel_count], eax
    mov ecx, 3
    mul ecx
    mov [buf_size], eax
    add eax, sizeof.BITMAPFILEHEADER + sizeof.BITMAPINFOHEADER
    mov [file_size], eax
    cinvoke printf, fmt_d, [pixel_count]    ; 65536
    cinvoke printf, fmt_d, [buf_size]       ; 196608
    cinvoke printf, fmt_d, [file_size]      ; 196662
    ret
endp

proc main9 uses edi
    cinvoke puts, '*** main9 ***'
    local file_handle:DWORD, bfh:BITMAPFILEHEADER, bih:BITMAPINFOHEADER
    local hHeap:DWORD, pMem:DWORD, pixel_count:DWORD

    mov [bih.biSize], sizeof.BITMAPINFOHEADER
    mov [bih.biWidth], 256
    mov [bih.biHeight], 256
    mov [bih.biPlanes], 1
    mov [bih.biBitCount], 24
    mov [bih.biCompression], 0

    mov eax, [bih.biWidth]
    mul [bih.biHeight]
    mov [pixel_count], eax
    mov ecx, 3
    mul ecx
    mov [bih.biSizeImage], eax

    mov [bih.biXPelsPerMeter], 0
    mov [bih.biYPelsPerMeter], 0
    mov [bih.biClrUsed], 0
    mov [bih.biClrImportant], 0

    mov [bfh.bfType], 'BM'
    mov dword [bfh.bfReserved1], 0
    mov [bfh.bfOffBits], sizeof.BITMAPFILEHEADER + sizeof.BITMAPINFOHEADER
    mov eax, [bih.biSizeImage]
    add eax, [bfh.bfOffBits]
    mov [bfh.bfSize], eax

    invoke GetProcessHeap
    mov [hHeap], eax
    invoke HeapAlloc, [hHeap], 0, [bih.biSizeImage]
    mov [pMem], eax

   ;stdcall fill_with_color, [pMem], [pixel_count], 0, 0, 255
    stdcall fill_with_color2, [pMem], [pixel_count], 0xFF0000
   ;stdcall create_gradient, [pMem], [pixel_count]

    cinvoke fopen, fname, fmode
    test eax, eax
    jz .exit
    mov [file_handle], eax

    cinvoke fwrite, addr bfh, 1, sizeof.BITMAPFILEHEADER, [file_handle]
    cinvoke fwrite, addr bih, 1, sizeof.BITMAPINFOHEADER, [file_handle]
    cinvoke fwrite, [pMem], 1, [bih.biSizeImage], [file_handle]
    cinvoke fclose, [file_handle]
    invoke HeapFree, [hHeap], 0, [pMem]
.exit:
    ret
endp

proc fill_with_color, pMem, pixel_count, red, green, blue
    mov edx, [pMem]
    mov ecx, [pixel_count]
    mov eax, [red]
    shl eax, 8
    or eax, [green]
    shl eax, 8
    or eax, [blue]
.fill:
    mov dword [edx], eax
    add edx, 3
    loop .fill
    ret
endp

proc fill_with_color2, pMem, pixel_count, color
    mov edx, [pMem]
    mov ecx, [pixel_count]
    mov eax, [color]
.fill:
    mov [edx], eax
    add edx, 3
    loop .fill
    ret
endp

; red (0, 0, 255) --> white (255, 255, 255)
; magenta (255, 0, 255)
; yellow (0, 255, 255)
proc create_gradient, pMem, pixel_count
    mov edx, [pMem]
    mov ecx, [pixel_count]
    xor eax, eax
.fill:
    mov [edx], al
    mov [edx + 1], ah
    mov byte [edx + 2], 255
    add edx, 3
    inc eax
    loop .fill
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetProcessHeap, 'GetProcessHeap',\
            HeapAlloc,      'HeapAlloc',\
            HeapFree,       'HeapFree',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            fopen,          'fopen',\
            fwrite,         'fwrite',\
            fclose,         'fclose',\
            printf,         'printf',\
            puts,           'puts'
