
include 'win32a.inc'

image_width = 10
image_height = 10
BITMAPCOREHEADER 12, image_width, image_height * 3, 1, 24
