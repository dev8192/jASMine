format binary as 'bmp'

include 'win32a.inc'

image_width = 10
image_height = 10

BITMAPFILEHEADER 'BM', file_end, 0, 0, pixel_data
;BITMAPCOREHEADER 12, image_width, image_height * 3, 1, 24
BITMAPINFOHEADER 40, image_width, image_height * 3, 1, 24, 0, 0, 0, 0, 0, 0

; === PIXEL DATA (320 bytes) ===
; In 24-bit BMP files, rows must be padded to a multiple of 4 bytes.
; 10 pixels * 3 bytes per pixel = 30 bytes per row.
; The next multiple of 4 is 32. Therefore, each row needs 2 padding bytes.
pixel_data:
repeat image_height
    repeat image_width
        db 0x00, 0x00, 0xFF
    end repeat
    db 0x00, 0x00
end repeat
repeat image_height
    repeat image_width
        db 0x00, 0xFF, 0x00
    end repeat
    db 0x00, 0x00
end repeat
repeat image_height
    repeat image_width
        db 0x00, 0x00, 0xFF
    end repeat
    db 0x00, 0x00
end repeat

file_end = $%%
