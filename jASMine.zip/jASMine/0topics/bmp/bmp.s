format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    bfh         BITMAPFILEHEADER
    bih         BITMAPINFOHEADER
    fmt         db "%d", 10, 0

section '.code' code readable executable

screen_width = 1920
screen_height = 1080

start:
    ;cinvoke printf, fmt, sizeof.BITMAPFILEHEADER ; 14
    ;cinvoke printf, fmt, sizeof.BITMAPINFOHEADER ; 40

    mov [bfh.bfType], 0x4D42h ; 'BM'
    mov eax, screen_width
    imul eax, 3
    add eax, 3
    and eax, not 3
    imul eax, screen_height
    add eax, sizeof.BITMAPFILEHEADER + sizeof.BITMAPINFOHEADER
    mov [bfh.bfSize], eax
    mov [bfh.bfOffBits], sizeof.BITMAPFILEHEADER + sizeof.BITMAPINFOHEADER

    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit',\
            printf, 'printf'
