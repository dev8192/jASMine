include 'boilerplate/header.x86.inc'
include 'winbase.inc'

proc main
    cinvoke puts, '*** main1 ***'
    local thread_handles[2]:DWORD, counter:DWORD
    mov [counter], 0
    invoke CreateThread, 0, 0, thread_proc, addr counter, 0, 0
    mov [thread_handles + 0], eax
    invoke CreateThread, 0, 0, thread_proc, addr counter, 0, 0
    mov [thread_handles + 4], eax
    invoke WaitForMultipleObjects, 2, addr thread_handles, 1, INFINITE
    invoke CloseHandle, [thread_handles + 0]
    invoke CloseHandle, [thread_handles + 4]
    cinvoke printf, fmt_d, [counter]
    ret
endp

proc thread_proc, param
    mov eax, [param]
    mov ecx, 1000000
.loop:
   ;inc dword [eax]
    lock inc dword [eax]
    dec ecx
    jnz .loop
    ret
endp

include 'boilerplate/footer_data.inc'

.idata
library kernel32,               'kernel32.dll',\
        msvcrt,                 'msvcrt.dll'
import  kernel32,\
        CreateThread,           'CreateThread',\
        WaitForMultipleObjects, 'WaitForMultipleObjects',\
        CloseHandle,            'CloseHandle',\
        ExitProcess,            'ExitProcess'
import  msvcrt,\
        printf,                 'printf',\
        puts,                   'puts'
