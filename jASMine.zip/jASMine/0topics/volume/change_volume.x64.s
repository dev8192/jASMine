format PE64 GUI 6.0
entry start

include 'win64w.inc'

section '.data' data readable writeable
    ; COM GUIDs required for Core Audio
    CLSID_MMDeviceEnumerator     GUID {0xBCDE0395, 0xE52F, 0x467C, {0x8E, 0x3D, 0xC4, 0x57, 0x92, 0x91, 0x69, 0x2E}}
    IID_IMMDeviceEnumerator      GUID {0xA95664D2, 0x9614, 0x4F35, {0xA7, 0x46, 0xDE, 0x8D, 0xB6, 0x36, 0x17, 0xE6}}
    IID_IAudioEndpointVolume     GUID {0x5CDF2C82, 0x841E, 0x4546, {0x97, 0x22, 0x0C, 0x11, 0xEF, 0x58, 0x63, 0x50}}

    ; Variables to store interface pointers
    pEnumerator         dq 0
    pDevice             dq 0
    pEndpointVolume     dq 0

    ; The target volume level: 32-bit float (0.0 to 1.0)
    ; 0.50 = 50% Volume
    TargetVolume        dd 0.50 

section '.text' code readable executable
start:
    sub     rsp, 56                     ; Allocate shadow space + alignment

    ; 1. Initialize COM library
    xor     ecx, ecx                    ; pvReserved = NULL
    call    [CoInitialize]
    test    eax, eax
    js      exit_program                ; Exit if initialization fails

    ; 2. Create MMDeviceEnumerator instance
    lea     rcx, [CLSID_MMDeviceEnumerator]
    xor     edx, edx                    ; pUnkOuter = NULL
    mov     r8d, 1                      ; CLSCTX_INPROC_SERVER = 1
    lea     r9, [IID_IMMDeviceEnumerator]
    lea     rax, [pEnumerator]
    mov     [rsp + 32], rax             ; 5th parameter on the stack
    call    [CoCreateInstance]
    test    eax, eax
    js      exit_program

    ; 3. Get Default Audio Endpoint (Output / eRender)
    ; COM Vtable Call: pEnumerator->GetDefaultAudioEndpoint(eRender, eConsole, &pDevice)
    mov     rcx, [pEnumerator]          ; 'this' pointer
    mov     rax, [rcx]                  ; Fetch vtable address
    xor     edx, edx                    ; eRender = 0 (Playback)
    xor     r8d, r8d                    ; eConsole = 0 (Default role)
    lea     r9, [pDevice]               ; Destination pointer
    call    [rax + 32]                  ; GetDefaultAudioEndpoint is at vtable offset 32 (4th method)
    test    eax, eax
    js      release_enumerator

    ; 4. Activate IAudioEndpointVolume Interface
    ; COM Vtable Call: pDevice->Activate(IID_IAudioEndpointVolume, CLSCTX_INPROC_SERVER, NULL, &pEndpointVolume)
    mov     rcx, [pDevice]              ; 'this' pointer
    mov     rax, [rcx]                  ; Fetch vtable address
    lea     rdx, [IID_IAudioEndpointVolume]
    mov     r8d, 1                      ; CLSCTX_INPROC_SERVER = 1
    xor     r9d, r9d                    ; pActivationParams = NULL
    lea     r11, [pEndpointVolume]
    mov     [rsp + 32], r11             ; 5th parameter on the stack
    call    [rax + 24]                  ; Activate is at vtable offset 24 (3rd method)
    test    eax, eax
    js      release_device

    ; 5. Set Master Volume Level Scalar (0.0 to 1.0)
    ; COM Vtable Call: pEndpointVolume->SetMasterVolumeLevelScalar(TargetVolume, NULL)
    mov     rcx, [pEndpointVolume]      ; 'this' pointer
    mov     rax, [rcx]                  ; Fetch vtable address
    movss   xmm1, [TargetVolume]        ; Parameter 2 (float): Passed via XMM1 register in x64 vector call
    xor     r8, r8                      ; Parameter 3 (pguidEventContext): NULL
    call    [rax + 56]                  ; SetMasterVolumeLevelScalar is at offset 56 (7th method)

release_volume:
    mov     rcx, [pEndpointVolume]
    mov     rax, [rcx]
    call    [rax + 16]                  ; IUnknown::Release (Offset 16)

release_device:
    mov     rcx, [pDevice]
    mov     rax, [rcx]
    call    [rax + 16]                  ; IUnknown::Release

release_enumerator:
    mov     rcx, [pEnumerator]
    mov     rax, [rcx]
    call    [rax + 16]                  ; IUnknown::Release
    call    [CoUninitialize]

exit_program:
    xor     ecx, ecx
    call    [ExitProcess]

section '.idata' import data readable
    library kernel32, 'KERNEL32.DLL', \
            ole32,    'OLE32.DLL'

    import kernel32, ExitProcess, 'ExitProcess'
    import ole32,    CoInitialize, 'CoInitialize', \
                     CoUninitialize, 'CoUninitialize', \
                     CoCreateInstance, 'CoCreateInstance'
