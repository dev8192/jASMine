include 'boilerplate/header.x86.inc'
include 'boilerplate/create_app.text.inc'

struct APP
    process_heap    dd ?
    max_scale_steps dd ?
    vowel_scale     dd ?
    string_ptr      dd ?
    string_len      dd ?
ends

struct ITEM
    value       db ?
    visible     db ?
ends

RECT_WIDTH = 50
RECT_HEIGHT = 60
ROUND_CORNER = 15
GAP_SIZE = 10
TEXT_BUFFER_SIZE = 2

proc main
    cinvoke puts, '*** main1 ***'
    
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall create_app
    ret
endp

proc window_proc uses ebx, hwnd, wmsg, wparam, lparam
    invoke GetWindowLong, [hwnd], GWL_USERDATA
    mov ebx, eax
    cmp [wmsg], WM_CREATE
    je .wm_create
    cmp [wmsg], WM_PAINT
    je .wm_paint
    cmp [wmsg], WM_KEYDOWN
    je .wm_keydown
    cmp [wmsg], WM_DESTROY
    je .wm_destroy
.default_processing:
    invoke DefWindowProc, [hwnd], [wmsg], [wparam], [lparam]
    jmp .exit
.wm_create:
    invoke GetProcessHeap
    push eax
    invoke HeapAlloc, eax, 0, sizeof.APP
    mov ebx, eax
    pop eax
    mov [ebx + APP.process_heap], eax
    mov [ebx + APP.max_scale_steps], 10
    mov eax, mov [ebx + APP.max_scale_steps]
    mov [ebx + APP.vowel_scale], eax
    mov [ebx + APP.string_ptr], alphabet__data.alphabet_lowercase
    mov [ebx + APP.string_len], 26
    invoke SetWindowLong, [hwnd], GWL_USERDATA, ebx
    xor eax, eax
    jmp .exit
.wm_paint:
    stdcall paint_row, [hwnd], ebx
    xor eax, eax
    jmp .exit
.wm_keydown:
    cmp [wparam], VK_SPACE
    jne .default_processing
    mov eax, [ebx + APP.vowel_scale]
    test eax, eax
    jz .no_decrement
    dec eax
    mov [ebx + APP.vowel_scale], eax
    invoke InvalidateRect, [hwnd], 0, 1
.no_decrement:
    xor eax, eax
    jmp .exit
.wm_destroy:
    invoke HeapFree, [ebx + APP.process_heap], 0, ebx
    invoke PostQuitMessage, 0
    xor eax, eax
.exit:
    ret
endp

proc paint_row uses ebx, hwnd, state_ptr
    local ps PAINTSTRUCT
    local loop_index:DWORD
    local current_left:DWORD
    local current_width:DWORD
    local current_char:DWORD

    mov ebx, [state_ptr]
    mov [loop_index], 0
    mov [current_left], 10
    invoke BeginPaint, [hwnd], addr ps

.paint_loop:
    mov ecx, [loop_index]
    cmp ecx, [ebx + APP.string_len]
    jge .loop_done

    mov edx, [ebx + APP.string_ptr]
    movzx eax, byte [edx + ecx]
    mov [current_char], eax

    stdcall calculate_char_width, ebx, [current_char]
    mov [current_width], eax

    test eax, eax
    jz .skip_draw

    stdcall draw_element, [ps.hdc],\
        [current_char], [current_left], [current_width]

    mov eax, [current_width]
    add eax, GAP_SIZE
    add [current_left], eax

.skip_draw:
    inc [loop_index]
    jmp .paint_loop

.loop_done:
    invoke EndPaint, [hwnd], addr ps
    ret
endp

proc calculate_char_width state_ptr, character
    invoke is_vowel, [character]
    test eax, eax
    jnz .vowel_width
    mov eax, RECT_WIDTH
    jmp .exit
.vowel_width:
    mov edx, [state_ptr]
    cvtsi2ss xmm0, [edx + APP.vowel_scale]
    cvtsi2ss xmm1, [edx + APP.max_scale_steps]
    divss xmm0, xmm1
    mov dword [esp - 4], RECT_WIDTH
    cvtsi2ss xmm2, dword [esp - 4]
    mulss xmm0, xmm2
    cvttss2si eax, xmm0
.exit:
    ret
endp

proc draw_element hdc, character, left, width
    local rect RECT
    local rgn_handle:DWORD
    local brush_handle:DWORD
    local pen_handle:DWORD
    local old_brush:DWORD
    local old_pen:DWORD
    local buf[TEXT_BUFFER_SIZE] db ?

    mov eax, [left]
    mov [rect.left], eax
    add eax, [width]
    mov [rect.right], eax
    mov [rect.top], 20
    mov [rect.bottom], 20 + RECT_HEIGHT

    invoke CreateSolidBrush, 0x00E0FFE0
    mov [brush_handle], eax
    invoke CreatePen, PS_SOLID, 1, 0x00000000
    mov [pen_handle], eax

    invoke SelectObject, [hdc], [brush_handle]
    mov [old_brush], eax
    invoke SelectObject, [hdc], [pen_handle]
    mov [old_pen], eax

    invoke RoundRect, [hdc], [rect.left], [rect.top], [rect.right],\
        [rect.bottom], ROUND_CORNER, ROUND_CORNER

    invoke is_vowel, [character]
    test eax, eax
    jnz .cleanup

    mov al, byte [character]
    mov [buf], al
    mov [buf + 1], 0
    invoke SetBkMode, [hdc], TRANSPARENT
    invoke DrawText, [hdc], addr buf, 1, addr rect,\
        DT_CENTER or DT_VCENTER or DT_SINGLELINE

.cleanup:
    invoke SelectObject, [hdc], [old_brush]
    invoke SelectObject, [hdc], [old_pen]
    invoke DeleteObject, [brush_handle]
    invoke DeleteObject, [pen_handle]
    invoke DeleteObject, [rgn_handle]

    ret
endp

include 'boilerplate/footer_data.inc'
include 'boilerplate/create_app.data.inc'
err_dc db 'Error: Failed to create drawing objects.', 10, 0

.idata
library kernel32,           'kernel32.dll',\
        user32,             'user32.dll',\
        gdi32,              'gdi32.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        GetModuleHandle,    'GetModuleHandleA',\
        GetProcessHeap,     'GetProcessHeap',\
        HeapAlloc,          'HeapAlloc',\
        HeapFree,           'HeapFree',\
        ExitProcess,        'ExitProcess'
import  user32,\
        LoadCursor,         'LoadCursorA',\
        RegisterClass,      'RegisterClassA',\
        CreateWindowEx,     'CreateWindowExA',\
        GetMessage,         'GetMessageA',\
        DispatchMessage,    'DispatchMessageA',\
        DefWindowProc,      'DefWindowProcA',\
        PostQuitMessage,    'PostQuitMessage',\
        DefWindowProc,      'DefWindowProcA',\
        SetWindowLong,      'SetWindowLongA',\
        GetWindowLong,      'GetWindowLongA',\
        BeginPaint,         'BeginPaint',\
        EndPaint,           'EndPaint',\
        DrawText,           'DrawTextA',\
        InvalidateRect,     'InvalidateRect'
import  gdi32,\
        CreateRoundRectRgn, 'CreateRoundRectRgn',\
        CreateSolidBrush,   'CreateSolidBrush',\
        CreatePen,          'CreatePen',\
        SelectObject,       'SelectObject',\
        DeleteObject,       'DeleteObject',\
        SetBkMode,          'SetBkMode',\
        RoundRect,          'RoundRect'
import  msvcrt,\
        printf,             'printf',\
        puts,               'puts'
