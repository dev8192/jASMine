include 'boilerplate/header.x86.inc'
include 'util/print_bytes.text.inc'
include 'echo.text.inc'

proc set_endcoding, encoding
    invoke SetConsoleCP, [encoding]
    invoke SetConsoleOutputCP, [encoding]
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    stdcall echo, [ReadConsoleW], [WriteConsoleW], 16
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    stdcall set_endcoding, 1251     ; e0 e1 e2 0d 0a
    stdcall set_endcoding, CP_UTF8  ; d0 b0 d0 b1 d0 b2 0d 0a
    stdcall echo, [ReadConsoleA], [WriteConsoleA], 16
    ret
endp

.data
include 'util/format.data.inc'
include 'util/print_bytes.data.inc'

.idata
library kernel32,           'kernel32.dll',\
        msvcrt,             'msvcrt.dll'
import  kernel32,\
        GetStdHandle,       'GetStdHandle',\
        WriteConsoleA,      'WriteConsoleA',\
        WriteConsoleW,      'WriteConsoleW',\
        ReadConsoleA,       'ReadConsoleA',\
        ReadConsoleW,       'ReadConsoleW',\
        SetConsoleCP,       'SetConsoleCP',\
        SetConsoleOutputCP, 'SetConsoleOutputCP',\
        GetProcessHeap,     'GetProcessHeap',\
        HeapAlloc,          'HeapAlloc',\
        HeapFree,           'HeapFree',\
        ExitProcess,        'ExitProcess'
import  msvcrt,\
        memset,             'memset',\
        printf,             'printf',\
        puts,               'puts'
