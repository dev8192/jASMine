format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt db "%d", 10, 0

section '.code' code readable executable

start:
@@:
    invoke getch
    cmp al, 'q'
    je .exit
    cinvoke printf, fmt, eax
    jmp @b
.exit:
    cinvoke exit, 0

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import msvcrt,\
        printf, 'printf',\
        getch, '_getch',\
        exit, 'exit'
