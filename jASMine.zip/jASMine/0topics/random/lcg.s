format PE GUI 4.0
entry start

include 'win32a.inc'

ID_BTN = 101
ID_TXT = 102

section '.data' data readable writeable

    hInstance   dd ?
    hwnd        dd ?
    hTxt        dd ?
    wc          WNDCLASS
    msg         MSG

    seed        dd 0

    szClass     db 'LcgApp', 0
    szTitle     db 'LCG Randomizer', 0
    szBtnClass  db 'BUTTON', 0
    szBtnText   db 'Generate', 0
    szTxtClass  db 'STATIC', 0
    szTxtInit   db 'Click Generate!', 0
    szFmt       db '%u', 0
    buffer      rb 32

section '.text' code readable executable

start:
    invoke  GetTickCount
    mov     [seed], eax

    invoke  GetModuleHandle, 0
    mov     [hInstance], eax

    mov     [wc.style], CS_HREDRAW or CS_VREDRAW
    mov     [wc.lpfnWndProc], WindowProc
    mov     [wc.hInstance], eax
    invoke  LoadIcon, 0, IDI_APPLICATION
    mov     [wc.hIcon], eax
    invoke  LoadCursor, 0, IDC_ARROW
    mov     [wc.hCursor], eax
    mov     [wc.hbrBackground], COLOR_WINDOW
    mov     [wc.lpszClassName], szClass
    invoke  RegisterClass, wc

    invoke  CreateWindowEx, 0, szClass, szTitle, WS_VISIBLE or WS_OVERLAPPEDWINDOW xor WS_THICKFRAME xor WS_MAXIMIZEBOX, \
            CW_USEDEFAULT, CW_USEDEFAULT, 220, 140, 0, 0, [hInstance], 0
    mov     [hwnd], eax

    invoke  CreateWindowEx, 0, szTxtClass, szTxtInit, WS_VISIBLE or WS_CHILD or SS_CENTER, \
            10, 20, 184, 20, [hwnd], ID_TXT, [hInstance], 0
    mov     [hTxt], eax

    invoke  CreateWindowEx, 0, szBtnClass, szBtnText, WS_VISIBLE or WS_CHILD or BS_PUSHBUTTON, \
            50, 50, 100, 30, [hwnd], ID_BTN, [hInstance], 0

msg_loop:
    invoke  GetMessage, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessage, msg
    jmp     msg_loop

end_loop:
    invoke  ExitProcess, [msg.wParam]

proc WindowProc hwnd_p, wmsg, wparam, lparam
    cmp     [wmsg], WM_COMMAND
    je      .wmcommand
    cmp     [wmsg], WM_DESTROY
    je      .wmdestroy

.defwndproc:
    invoke  DefWindowProc, [hwnd_p], [wmsg], [wparam], [lparam]
    ret

.wmcommand:
    mov     eax, [wparam]
    and     eax, 0FFFFh
    cmp     eax, ID_BTN
    je      .generate
    jmp     .finish

.generate:
    mov     eax, [seed]
    imul    eax, 214013
    add     eax, 2531011
    mov     [seed], eax

    shr     eax, 16
    and     eax, 07FFFh

    cinvoke wsprintf, buffer, szFmt, eax
    invoke  SetWindowText, [hTxt], buffer
    jmp     .finish

.wmdestroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret

.finish:
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable

    library kernel32, 'KERNEL32.DLL',\
            user32, 'USER32.DLL'

    import kernel32,\
        ExitProcess, 'ExitProcess',\
        GetModuleHandle, 'GetModuleHandleA',\
        GetTickCount, 'GetTickCount'

    import user32,\
        CreateWindowEx, 'CreateWindowExA',\
        DefWindowProc, 'DefWindowProcA',\
        DispatchMessage, 'DispatchMessageA',\
        GetMessage, 'GetMessageA',\
        LoadCursor, 'LoadCursorA',\
        LoadIcon, 'LoadIconA',\
        PostQuitMessage, 'PostQuitMessage',\
        RegisterClass, 'RegisterClassA',\
        SetWindowText, 'SetWindowTextA',\
        TranslateMessage, 'TranslateMessage',\
        wsprintf, 'wsprintfA'
