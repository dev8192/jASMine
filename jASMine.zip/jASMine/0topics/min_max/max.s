format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    stdcall .max_signed, 5, 10
    stdcall .max_signed, 10, 15
    ret
endp

proc .max_signed, num1, num2
    mov eax, [num1]  ; Load first number into eax
    mov ecx, [num2]  ; Load second number into ecx
    cmp eax, ecx     ; Compare eax with ecx
    cmovl eax, ecx   ; If eax < ecx (signed), move ecx into eax
    cinvoke printf, fmt_d, eax
    ret
endp

proc .max_unsigned, num1, num2
    mov eax, [num1]
    mov ecx, [num2]
    cmp eax, ecx
    cmovb eax, ecx
    cinvoke printf, fmt_d, eax
    ret
endp

proc .max2, num1, num2
    mov eax, [num1]
    mov ecx, [num2]
    sub eax, ecx
    sbb edx, edx     ; edx = -1 if eax < ecx, else 0
    and eax, edx     ; eax = (eax-ecx) if eax < ecx, else 0
    add eax, ecx     ; eax = max(eax, ecx)
    cinvoke printf, fmt_d, eax
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
