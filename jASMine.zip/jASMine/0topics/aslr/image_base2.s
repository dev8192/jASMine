format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_08x db '%08x', 10, 0

section '.text' code readable executable
start:
    mov eax, [fs:0x30]
    mov eax, [eax + 8]
    cinvoke printf, fmt_08x, eax       ; 0x00400000
    cinvoke printf, fmt_08x, fmt_08x   ; 0x00401000
    cinvoke printf, fmt_08x, start     ; 0x00402000
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'

section '.reloc' fixups data readable discardable
