include 'compiler/header.x86.inc'

proc main
    print_s '*** main1 ***'
    print_08x main
    ret
endp

include 'compiler/footer.inc'

section '.reloc' fixups data readable discardable
