include 'compiler/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main1
    print_s '*** main1 ***'
    mov eax, [fs:0x30]
    mov eax, [eax + 8]
    print_08x eax
    print_08x main
    print_08x fmt_d
    ret
endp

proc main
    print_s '*** main2 ***'
    mov eax, [fs:0x30]
    mov eax, [eax + 8]
    stdcall print_bytes, eax, 16
    print_c 0x4d
    print_c 0x5a
    ret
endp

include 'compiler/footer.inc'

;section '.reloc' fixups data readable discardable
