format PE GUI 4.0 DLL

include 'win32a.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    _title db "Hello", 0

section '.text' code readable executable
; VOID ShowErrorMessage(HWND hWnd,DWORD dwError);
proc ShowErrorMessage hWnd, dwError
    local   lpBuffer:DWORD
    lea     eax,[lpBuffer]
    invoke  FormatMessage,\
            FORMAT_MESSAGE_ALLOCATE_BUFFER + FORMAT_MESSAGE_FROM_SYSTEM,\
            0,[dwError],LANG_ENGLISH_US,eax,0,0
    invoke  MessageBoxEx, [hWnd], [lpBuffer], _title, MB_ICONERROR+MB_OK, LANG_ENGLISH_US
    invoke  LocalFree,[lpBuffer]
    ret
endp

; VOID ShowLastError(HWND hWnd);
proc ShowLastError hWnd
    invoke  GetLastError
    stdcall ShowErrorMessage, [hWnd], eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'KERNEL32.DLL',\
            user32,         'USER32.DLL'
    import  kernel32,\
            GetLastError,   'GetLastError',\
            SetLastError,   'SetLastError',\
            FormatMessage,  'FormatMessageA',\
            LocalFree,      'LocalFree'
    import  user32,\
            MessageBoxEx,   'MessageBoxExA'

section '.edata' export data readable
    export  'hello.dll',\
            ShowLastError,      'ShowLastError33'

section '.reloc' fixups data readable discardable
