format PE GUI 4.0 DLL
entry DllEntryPoint

include 'win32a.inc'

LANG_ENGLISH_US = 0x0409

section '.data' data readable writeable
    DLL_PROCESS_DETACH_msg  db 'DLL_PROCESS_DETACH', 10, 0
    DLL_PROCESS_ATTACH_msg  db 'DLL_PROCESS_ATTACH', 10, 0
    DLL_THREAD_ATTACH_msg   db 'DLL_THREAD_ATTACH', 10, 0
    DLL_THREAD_DETACH_msg   db 'DLL_THREAD_DETACH', 10, 0
    something_new_msg       db 'something_new', 10, 0

; DLL_PROCESS_ATTACH = 1
; DLL_THREAD_ATTACH  = 2
; DLL_THREAD_ATTACH  = 2
; DLL_PROCESS_DETACH = 0
section '.text' code readable executable
proc DllEntryPoint hinstDLL,fdwReason,lpvReserved
    cmp [fdwReason], DLL_PROCESS_DETACH
    je  .print_DLL_PROCESS_DETACH_msg
    cmp [fdwReason], DLL_PROCESS_ATTACH
    je  .print_DLL_PROCESS_ATTACH_msg
    cmp [fdwReason], DLL_THREAD_ATTACH
    je  .print_DLL_THREAD_ATTACH_msg
    cmp [fdwReason], DLL_THREAD_DETACH
    je  .print_DLL_THREAD_DETACH_msg
    jmp .print_something_new_msg

.print_DLL_PROCESS_DETACH_msg:
    cinvoke printf, DLL_PROCESS_DETACH_msg
    jmp @f
.print_DLL_PROCESS_ATTACH_msg:
    cinvoke printf, DLL_PROCESS_ATTACH_msg
    jmp @f
.print_DLL_THREAD_ATTACH_msg:
    cinvoke printf, DLL_THREAD_ATTACH_msg
    jmp @f
.print_DLL_THREAD_DETACH_msg:
    cinvoke printf, DLL_THREAD_DETACH_msg
    jmp @f
.print_something_new_msg:
    cinvoke printf, something_new_msg
@@:
    mov    eax, TRUE
    ret
endp

; VOID ShowErrorMessage(HWND hWnd,DWORD dwError);
proc ShowErrorMessage hWnd, dwError
    local   lpBuffer:DWORD
    lea     eax,[lpBuffer]
    invoke  FormatMessage,\
            FORMAT_MESSAGE_ALLOCATE_BUFFER + FORMAT_MESSAGE_FROM_SYSTEM,\
            0,[dwError],LANG_ENGLISH_US,eax,0,0
    invoke  MessageBoxEx, [hWnd], [lpBuffer], NULL, MB_ICONERROR+MB_OK, LANG_ENGLISH_US
    invoke  LocalFree,[lpBuffer]
    ret
endp

; VOID ShowLastError(HWND hWnd);
proc ShowLastError hWnd
    invoke  GetLastError
    stdcall ShowErrorMessage, [hWnd], eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32,       'KERNEL32.DLL',\
            user32,         'USER32.DLL',\
            msvcrt,         'MSVCRT.DLL'
    import  kernel32,\
            GetLastError,   'GetLastError',\
            SetLastError,   'SetLastError',\
            FormatMessage,  'FormatMessageA',\
            LocalFree,      'LocalFree'
    import  user32,\
            MessageBoxEx,   'MessageBoxExA'
    import  msvcrt,\
            printf,         'printf'

section '.edata' export data readable
    export  'hello.dll',\
            ShowLastError,      'ShowLastError33'

section '.reloc' fixups data readable discardable
