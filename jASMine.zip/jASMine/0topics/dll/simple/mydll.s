format PE console DLL
entry DllEntryPoint

include 'win32a.inc'

section '.code' code readable executable

proc DllEntryPoint hinstDLL, fdwReason, lpvReserved
    mov eax, 1 ; Return TRUE to allow loading
    ret
endp

; A simple function to export
proc MyFunction
    invoke MessageBox, 0, "Hello from the custom DLL!", "Success", 0
    ret
endp

section '.idata' import data readable
    library user32, 'user32.dll'
    import user32, MessageBox, 'MessageBoxA'

section '.edata' export data readable
    export 'mydll.dll', \
           MyFunction, 'MyFunction' ; Internal label, Exported name

section '.reloc' fixups data readable discardable
