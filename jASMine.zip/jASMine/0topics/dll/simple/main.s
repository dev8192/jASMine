format PE console DLL
entry DllEntryPoint

include 'win32a.inc'

section '.data' data readable writeable
    _title db "Success", 0
    _text  db "Hello from the custom DLL!", 0

section '.code' code readable executable

proc DllEntryPoint hinstDLL, fdwReason, lpvReserved
    mov eax, 1
    ret
endp

proc MyFunction
    ; Pass the addresses of the strings, not the strings themselves
    invoke MessageBox, 0, _text, _title, 0
    ret
endp

section '.idata' import data readable
    library user32, 'user32.dll'
    import user32, MessageBox, 'MessageBoxA'

section '.edata' export data readable
    export 'mydll.dll', \
           MyFunction, 'MyFunction'

section '.reloc' fixups data readable discardable
