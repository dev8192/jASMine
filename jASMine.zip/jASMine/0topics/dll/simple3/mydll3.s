format PE GUI 4.0 DLL
entry DllEntryPoint

include 'win32a.inc'

section '.data' data readable writeable

    dummy dd 0

section '.code' code readable executable

proc DllEntryPoint hinstDLL, fdwReason, lpvReserved
    mov     [dummy], 1
    mov     eax, 1
    ret
endp

proc AddNumbers c a, b
    mov     eax, [a]
    add     eax, [b]
    ret
endp

section '.edata' export data readable

    export 'mydll.dll',\
           AddNumbers, 'AddNumbers'

section '.reloc' fixups data discardable
