format ELF use32

section '.text' executable
public main
main:
    finit
    fldz                ; ST0 = running sum accumulator

    mov ecx, [arr_len]  ; Loop counter
    xor edi, edi        ; Array index pointer offset (starts at 0)

    ; Allocate a local 12-byte aligned buffer on the CPU stack
    sub esp, 12

.loop_start:
    jecxz .loop_done

    ; 1. Grab the raw data pointer and its size property (4 or 8) arithmetically
    mov esi, [arr_pointers + edi*4]
    mov edx, [arr_sizes + edi*4]     ; EDX will be 4 or 8

    ; 2. Branchless Read: Load the first 4 bytes regardless of size
    mov eax, [esi]      
    
    ; Load the next 4 bytes. For a 32-bit float, this reads adjacent memory garbage,
    ; but we will neutralize it arithmetically next.
    mov ebx, [esi + 4]  

    ; 3. Branchless Normalization to 64-bit Extended Format
    ; If size is 4 (32-bit float), we need to expand it to 80-bit format.
    ; If size is 8 (64-bit float), we need to expand it to 80-bit format.
    ; To avoid branching, we convert them arithmetically by leveraging the FPU's
    ; own hardware loading system. 
    
    ; We write the raw integer bits directly into our stack buffer
    mov [esp], eax
    mov [esp + 4], ebx

    ; To avoid writing two different FLD instructions, we use an FPU Environment hack.
    ; We store the instruction opcode we WANT to run inside a memory variable,
    ; and execute it using a self-modifying or table-driven execution window.
    
    ; Alternative: Use the x87 FSTSW/FLDENV state structure to trick the FPU pointer.
    ; Smoother approach: We use an instruction table offset.
    
    mov ebx, [opcode_table + edx]    ; Grabs exact machine code snippet pointer
    call ebx                         ; Executes uniform function call with zero jumps

    faddp st1, st0      ; Add to accumulator

    inc edi
    dec ecx
    jmp .loop_start

.loop_done:
    add esp, 12         ; Clean up stack buffer
    ret

; --- This table holds the absolute branchless jump targets without conditions ---
align 4
.load_dd:
    fld dword [esi]
    ret
align 4
.load_dq:
    fld qword [esi]
    ret

section '.data' writeable
    num1    dd 1.0
    num2    dq 2.0
    num3    dd 3.0
    num4    dq 4.0

    arr_pointers dd num1, num2, num3, num4
    arr_sizes    dd 4,    8,    4,    8
    arr_len      dd ($ - arr_sizes) / 4

    ; Lookup table mapping size (4 or 8) directly to the execution offset
    align 4
    opcode_table dd 0, 0, 0, 0, main.load_dd, 0, 0, 0, main.load_dq
