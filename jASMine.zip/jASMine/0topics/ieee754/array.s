format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%.1f', 10, 0
    arr1:       dd 10.0, 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 10.7, 10.8, 10.9
                dd 11.0, 11.1, 11.2, 11.3, 11.4, 11.5, 11.6, 11.7, 11.8, 11.9
                dd 12.0, 12.1, 12.2, 12.3, 12.4, 12.5
    arr1_len    = ($ - arr1) / 4
    num1        dd 1.0
    num2        dq 2.0
    num3        dd 3.0
    num4        dq 4.0
    arr2        dd num1, num2, num3, num4
    arr2_len    = ($ - arr2) / 4

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    local num1:QWORD
    fld dword [arr1 + 2 * 4]
    fstp [num1]
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    ret
endp

proc main2 uses ebx esi
    cinvoke puts, '*** main2 ***'
    local num1:QWORD
    mov ebx, arr1_len
    mov esi, arr1
.loop:
    fld dword [esi]
    fstp [num1]
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    add esi, 4
    dec ebx
    jnz .loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
