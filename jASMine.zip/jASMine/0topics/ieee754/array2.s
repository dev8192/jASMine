format PE
entry start

include 'win32ax.inc'

;include 'array2_macro3.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0

;create_fp_array, arr,\
;    dd, 1.0,\
;    dq, 2.0,\
;    dt, 3.0,\
;    dd, 1.0,\
;    dq, 2.0,\
;    dt, 3.0

    num1        dd 1.0
    num2        dq 2.0
    num3        dt 3.0
    num4        dd 1.0
    num5        dq 2.0
    num6        dt 3.0
    arr1        dd num1, num2, num3, num4, num5, num6
    arr1_len    = ($ - arr1) / 4
    arr2        db 4, 8, 10, 4, 8, 10

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main uses ebx esi
    cinvoke puts, '*** main1 ***'
    local result:QWORD
    finit
    xor ebx, ebx
.loop:
    cmp ebx, arr1_len
    je .done
    mov esi, [arr1 + ebx * 4]
    mov al, [arr2 + ebx]
    cmp al, 4
    je .load_32bit
    cmp al, 8
    je .load_64bit
    fld tword [esi]
    jmp .do_math
.load_32bit:
    fld dword [esi]
    jmp .do_math
.load_64bit:
    fld qword [esi]
.do_math:
    fstp [result]
    cinvoke printf, fmt_f, dword [result], dword [result + 4]
    inc ebx
    jmp .loop
.done:
    ret
endp

proc main2 uses esi
    cinvoke puts, '*** main2 ***'
    local result:QWORD
    finit
    fldz
    xor ecx, ecx
.loop:
    cmp ecx, arr1_len
    je .done
    mov esi, [arr1 + ecx * 4]
    mov al, [arr2 + ecx]
    cmp al, 4
    je .load_32bit
    fld qword [esi]
    jmp .do_math
.load_32bit:
    fld dword [esi]
.do_math:
    faddp
    inc ecx
    jmp .loop
.done:
    fstp [result]
    cinvoke printf, fmt_f, dword [result], dword [result + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
