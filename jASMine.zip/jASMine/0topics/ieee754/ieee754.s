format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    locals
        num1    dq 0x7FEFFFFFFFFFFFFF
    endl
    stdcall print_bytes, addr num1, 8
    cinvoke printf, fmt_f, dword [num1], dword [num1 + 4]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    locals
        num1    dq 0x7FEFFFFFFFFFFFFF
        num2    dq 19999999999999999999999.0
        result  dq ?
    endl
    fld [num1]
   ;fadd [num2]
    fsub [num2]
   ;fchs
    fstp [result]
    cinvoke printf, fmt_f, dword [result], dword [result+4]
    stdcall print_bytes, addr num1, 8
    stdcall print_bytes, addr result, 8
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
