format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    locals
        max_val1    dq 0x7FEFFFFFFFFFFFFF
        max_val2    dq 1.7976931348623157e+308
        min_val1    dq 0x0000000000000001
        min_val2    dq 5e-324
    endl
    stdcall print_bytes, addr max_val1, 8
    stdcall print_bytes, addr max_val2, 8
    stdcall print_bytes, addr min_val1, 8
    stdcall print_bytes, addr min_val2, 8
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    locals
        max_val1    dq 0x7FEFFFFFFFFFFFFF
        max_val2    dq 1.7976931348623157e+308
        min_val1    dq 0x0000000000000001
        min_val2    dq 5e-324
        result      dq ?
    endl
    stdcall print_bytes, addr min_val1, 8
    fld [min_val1]
    fld1
    faddp
    fst [result]
    stdcall print_bytes, addr result, 8
    fld1
    fsubp
    fst [result]
    stdcall print_bytes, addr result, 8
    fld1
    fst [result]
    stdcall print_bytes, addr result, 8
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
