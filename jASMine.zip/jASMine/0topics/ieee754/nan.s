format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_f       db '%f', 10, 0
    fmt_d       db '%d', 10, 0
    fmt_x       db '%x', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

macro floats1 {
    float1      dd 123.0
    float2      dq 123.0
    float3      dt 123.0
}

macro quiet_nans {
   ;float1      dd 0x7FC00000
   ;float1      dd 01111111110000000000000000000000b
   ;float1      dd (0 shl 31) or (11111111b shl 23) or 10000000000000000000000b
    float1      dd (0 shl 31) or (255 shl 23) or (1 shl 22)

   ;float2      dq 0x7FF8000000000000
   ;float2      dq 0111111111111000000000000000000000000000000000000000000000000000b
   ;float2      dq (0 shl 63) or (11111111111b shl 52) or 1000000000000000000000000000000000000000000000000000b
    float2      dq (0 shl 63) or (2047 shl 52) or (1 shl 51)
    
   ;float3      db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC0, 0xFF, 0x7F
   ;float3      dq 0xC000000000000000
   ;float3_hi   dw 0x7FFF
    float3      dq 1100000000000000000000000000000000000000000000000000000000000000b
    float3_hi   dw 0111111111111111b
}

macro real_indeterminates {
   ;float1      dd 0xFFC00000
    float1      dd (1 shl 31) or (11111111b shl 23) or 10000000000000000000000b

   ;float2      dq 0xFFF8000000000000
    float2      dq (1 shl 63) or (11111111111b shl 52) or 1000000000000000000000000000000000000000000000000000b
    
   ;float3      db 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xC0, 0xFF, 0xFF
    float3      dq 1100000000000000000000000000000000000000000000000000000000000000b
    float3_hi   dw 1111111111111111b
}

macro signaling_nans {
    float1      dd 0x7F800001
   ;float1      dd (0 shl 31) or (11111111b shl 23) or 00000000000000000000001b

   ;float2      dq 0x7FF0000000000001
    float2      dq (0 shl 63) or (11111111111b shl 52) or 0000000000000000000000000000000000000000000000000001b
    
   ;float3      db 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0xFF, 0x7F
    float3      dq 1000000000000000000000000000000000000000000000000000000000000001b
    float3_hi   dw 0111111111111111b
}

proc main1
    cinvoke puts, '*** main1 ***'
    locals
        quiet_nans
       ;real_indeterminates
       ;signaling_nans
        float4      dq ?
    endl
    fld [float1]
    fstp [float4]
    cinvoke printf, fmt_f, dword [float4], dword [float4 + 4]

    fld [float2]
    fstp [float4]
    cinvoke printf, fmt_f, dword [float4], dword [float4 + 4]

    fld tword [float3]
    fstp [float4]
    cinvoke printf, fmt_f, dword [float4], dword [float4 + 4]
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    locals
        quiet_nans
        int1        dd ?
        int2        dd 0x80000000
    endl
    fld [float1]
    fistp [int1]
    cinvoke printf, fmt_d, [int1]

    fld [float2]
    fistp [int1]
    cinvoke printf, fmt_d, [int1]

    fld tword [float3]
    fistp [int1]
    cinvoke printf, fmt_d, [int1]

    cinvoke printf, fmt_d, [int2]
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    locals
        buf1        rb 108
        quiet_nans
    endl
    finit
    fld [float1]
    fld [float2]
    fld tword [float3]
    lea eax, [buf1]
    fsave [eax]
    lea eax, [buf1 + 28]
    stdcall print_bytes, eax, 10
    lea eax, [buf1 + 28 + 10]
    stdcall print_bytes, eax, 10
    lea eax, [buf1 + 28 + 20]
    stdcall print_bytes, eax, 10
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    stdcall test_nan, 0x7FC00000
    stdcall test_nan, 0x7F800001
    ret
endp

proc test_nan num32
    local float0:QWORD
    fld [num32]
    fld1
    faddp
    fstsw ax
    movzx eax, ax
    cinvoke printf, fmt_x, eax
    fstp [float0]
    cinvoke printf, fmt_f, dword [float0], dword [float0 + 4]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
