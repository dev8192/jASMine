include 'boilerplate/header.x86.inc'
include 'util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main ***'
    locals
        num1    dq 0x001FFFFF_FFFFFFFF
        num2    dq 9007199254740991
        num3    dq (1 shl 53) - 1
    endl
    cinvoke printf, fmt_llu, double [num1]
    cinvoke printf, fmt_llu, double [num2]
    cinvoke printf, fmt_llu, double [num3]
    stdcall compute_max_safe_int
    ret
endp

proc compute_max_safe_int
    locals
        num1 dq 9007199254740991.0
        num2 dq ?
    endl
    mov eax, 1
    cvtsi2sd xmm0, eax
    mov eax, 2
    cvtsi2sd xmm1, eax
    mov ecx, 53
.loop:
    mulsd xmm0, xmm1
    loop .loop
    mov eax, 1
    cvtsi2sd xmm1, eax
    subsd xmm0, xmm1
    movsd [num2], xmm0
    cinvoke printf, fmt_f, double [num2]
    cinvoke printf, fmt_f, double [num1]
    ret
endp

include 'boilerplate/footer_data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        vprintf,        'vprintf',\
        printf,         'printf',\
        puts,           'puts'
