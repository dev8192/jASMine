format PE
entry start

include 'win32ax.inc'

STDOUT_FILENO = 1
_O_U16TEXT = 0x20000

section '.data' data readable writeable
    globe_utf8      db 0xF0, 0x9F, 0x8C, 0x8E, 0
    globe_utf16     du 0xD83C, 0xDF0E, 0
    fmt_x           db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    invoke SetConsoleOutputCP, CP_UTF8
    cinvoke puts, globe_utf8
    cinvoke puts, globe_utf8
    ret
endp

; not working
proc main
    cinvoke puts, '*** main2 ***'
    cinvoke _setmode, STDOUT_FILENO, _O_U16TEXT
    cinvoke _putws, globe_utf16
    cinvoke _putws, globe_utf16
    ret
endp

; not working
proc main21
    cinvoke puts, '*** main21 ***'
    cinvoke __p__iob
    add eax, 32
    cinvoke _setmode, eax, _O_U16TEXT
    cinvoke _putws, globe_utf16
    cinvoke _putws, globe_utf16
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            SetConsoleOutputCP, 'SetConsoleOutputCP',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            __p__iob,           '__p__iob',\
            _putws,             '_putws',\
            _setmode,           '_setmode',\
            printf,             'printf',\
            puts,               'puts'
