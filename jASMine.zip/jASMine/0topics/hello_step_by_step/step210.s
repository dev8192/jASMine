; ----------
; Add exit()
; ----------

format PE console

include 'win32a.inc'

section '.text' code readable executable
    cinvoke exit, 33

section '.idata' import data readable
    library msvcrt, 'msvcrt.dll'
    import  msvcrt,\
            exit,   'exit'
