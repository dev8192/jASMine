format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    invoke Sleep, 60000
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            Sleep,          'Sleep',\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'

section '.rsrc' resource data readable
    directory RT_VERSION, versions
    resource versions, 1, LANG_NEUTRAL, version
   ;versioninfo version, VOS__WINDOWS32, VFT_APP, VFT2_UNKNOWN, LANG_NEUTRAL, 0,\ 
    versioninfo version, VOS__WINDOWS32, VFT_APP, VFT2_UNKNOWN, LANG_ENGLISH+SUBLANG_DEFAULT, 0,\
        'FileDescription',      'Hello there!',\
        'OriginalFilename',     'prog.exe'
