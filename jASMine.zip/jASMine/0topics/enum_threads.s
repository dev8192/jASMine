format PE CONSOLE 4.0
entry main

include 'win32ax.inc'

THREAD_QUERY_SET_WIN32_START_ADDRESS equ 9
STATUS_SUCCESS equ 0
MODULE_BUFFER_SIZE equ 256
MAX_MODULE_NAME_LENGTH equ 255
DWORD_SIZE equ 4

struct App_Context
    target_pid dd ?
    module_buffer rb MODULE_BUFFER_SIZE
ends

section '.data' data readable writeable

error_snap_thread db 'Error: Failed to create thread snapshot', 10, 0
error_thread_first db 'Error: Thread32First failed', 10, 0
error_open_thread db 'Error: Failed to open thread', 10, 0
error_query_thread db 'Error: NtQueryInformationThread failed', 10, 0
error_snap_module db 'Error: Failed to create module snapshot', 10, 0
error_module_first db 'Error: Module32First failed', 10, 0
msg_thread_info db 'Thread ID: %lu, Module: %s', 10, 0
str_unknown db 'Unknown', 0

section '.text' code readable executable

proc main
    locals
        app_ctx App_Context
    endl

    invoke GetCurrentProcessId
    mov [app_ctx.target_pid], eax

    lea ebx, [app_ctx]
    stdcall enumerate_threads, ebx

    ret
endp

proc enumerate_threads app_ctx
    locals
        snapshot_handle dd ?
        thread_entry THREADENTRY32
        status dd ?
    endl

    mov [status], 0

    invoke CreateToolhelp32Snapshot, TH32CS_SNAPTHREAD, 0
    cmp eax, INVALID_HANDLE_VALUE
    jne .snapshot_ok
    cinvoke printf, error_snap_thread
    jmp .exit

.snapshot_ok:
    mov [snapshot_handle], eax
    mov [thread_entry.dwSize], sizeof.THREADENTRY32

    invoke Thread32First, [snapshot_handle], addr thread_entry
    test eax, eax
    jnz .loop_start
    cinvoke printf, error_thread_first
    jmp .cleanup

.loop_start:
    mov ebx, [app_ctx]
    mov eax, [thread_entry.th32OwnerProcessID]
    cmp eax, [ebx + App_Context.target_pid]
    jne .next_thread

    stdcall process_thread, ebx, [thread_entry.th32ThreadID]

.next_thread:
    invoke Thread32Next, [snapshot_handle], addr thread_entry
    test eax, eax
    jnz .loop_start

    mov [status], 1

.cleanup:
    invoke CloseHandle, [snapshot_handle]

.exit:
    mov eax, [status]
    ret
endp

proc process_thread app_ctx, thread_id
    locals
        start_address dd ?
        status dd ?
    endl

    mov [status], 0
    stdcall get_thread_start_address, [thread_id], addr start_address
    test eax, eax
    jz .exit

    mov ebx, [app_ctx]
    lea eax, [ebx + App_Context.module_buffer]
    stdcall get_module_by_address, [ebx + App_Context.target_pid], [start_address], eax
    
    lea eax, [ebx + App_Context.module_buffer]
    cinvoke printf, msg_thread_info, [thread_id], eax
    mov [status], 1

.exit:
    mov eax, [status]
    ret
endp

proc get_thread_start_address thread_id, out_address
    locals
        thread_handle dd ?
        status dd ?
    endl

    mov [status], 0
    invoke OpenThread, THREAD_QUERY_INFORMATION, 0, [thread_id]
    test eax, eax
    jnz .open_ok
    cinvoke printf, error_open_thread
    jmp .exit

.open_ok:
    mov [thread_handle], eax
    invoke NtQueryInformationThread, [thread_handle], THREAD_QUERY_SET_WIN32_START_ADDRESS,\
           [out_address], DWORD_SIZE, 0
    cmp eax, STATUS_SUCCESS
    je .query_ok
    cinvoke printf, error_query_thread
    jmp .cleanup

.query_ok:
    mov [status], 1

.cleanup:
    invoke CloseHandle, [thread_handle]

.exit:
    mov eax, [status]
    ret
endp

proc get_module_by_address target_pid, start_address, out_buffer
    locals
        snapshot_handle dd ?
        module_entry MODULEENTRY32
        status dd ?
        snap_flags dd ?
    endl

    mov [status], 0
    mov eax, TH32CS_SNAPMODULE
    or eax, TH32CS_SNAPMODULE32
    mov [snap_flags], eax

    invoke CreateToolhelp32Snapshot, [snap_flags], [target_pid]
    cmp eax, INVALID_HANDLE_VALUE
    jne .snapshot_ok
    cinvoke printf, error_snap_module
    jmp .set_unknown

.snapshot_ok:
    mov [snapshot_handle], eax
    mov [module_entry.dwSize], sizeof.MODULEENTRY32

    invoke Module32First, [snapshot_handle], addr module_entry
    test eax, eax
    jnz .loop_start
    cinvoke printf, error_module_first
    jmp .cleanup

.loop_start:
    mov eax, [module_entry.modBaseAddr]
    mov ecx, [start_address]
    cmp ecx, eax
    jb .next_module
    add eax, [module_entry.modBaseSize]
    cmp ecx, eax
    jae .next_module

    cinvoke strncpy, [out_buffer], addr module_entry.szModule, MAX_MODULE_NAME_LENGTH
    mov eax, [out_buffer]
    mov byte [eax + MAX_MODULE_NAME_LENGTH], 0
    jmp .found

.next_module:
    invoke Module32Next, [snapshot_handle], addr module_entry
    test eax, eax
    jnz .loop_start

.cleanup:
    invoke CloseHandle, [snapshot_handle]

.set_unknown:
    cinvoke strncpy, [out_buffer], str_unknown, MAX_MODULE_NAME_LENGTH
    jmp .exit

.found:
    invoke CloseHandle, [snapshot_handle]
    mov [status], 1

.exit:
    mov eax, [status]
    ret
endp

section '.idata' import data readable writeable

library kernel32, 'kernel32.dll',\
        ntdll, 'ntdll.dll',\
        msvcrt, 'msvcrt.dll'

import kernel32,\
       CloseHandle, 'CloseHandle',\
       CreateToolhelp32Snapshot, 'CreateToolhelp32Snapshot',\
       GetCurrentProcessId, 'GetCurrentProcessId',\
       Module32First, 'Module32First',\
       Module32Next, 'Module32Next',\
       OpenThread, 'OpenThread',\
       Thread32First, 'Thread32First',\
       Thread32Next, 'Thread32Next'

import ntdll,\
       NtQueryInformationThread, 'NtQueryInformationThread'

import msvcrt,\
       printf, 'printf',\
       strncpy, 'strncpy'
