include 'win32a.inc'

format PE GUI 4.0
entry start

section '.data' data readable writeable
    szTitle  db 'WebP Viewer', 0
    szClass  db 'WebPClass', 0

    ;wszFile  du 'C:/llprog_priv/images/hotel.webp', 0
    wszFile  du 'C:/llprog_priv/images/moscow.webp', 0
    
    szError  db 'Failed to load WebP. Ensure image.webp is in the folder or passed via command line.', 0

    wc       WNDCLASS 0, WindowProc, 0, 0, 0, 0, 0, COLOR_WINDOW+1, 0, szClass
    msg      MSG
    ps       PAINTSTRUCT

    CLSID_WICImagingFactory:
        dd 0x317D06E8
        dw 0x5F24, 0x433D
        db 0xBD, 0xF7, 0x79, 0xCE, 0x68, 0xD8, 0xAB, 0xC2

    IID_IWICImagingFactory:
        dd 0xEC5EC8A9
        dw 0xC395, 0x4314
        db 0x9C, 0x77, 0x54, 0xD7, 0xA9, 0x35, 0xFF, 0x70

    GUID_WICPixelFormat32bppPBGRA:
        dd 0x6FDDC324
        dw 0x4E03, 0x4BFE
        db 0xB1, 0x85, 0x3D, 0x77, 0x76, 0x8D, 0xC9, 0x05

    pFactory   dd 0
    pDecoder   dd 0
    pFrame     dd 0
    pConverter dd 0

    img_w      dd 0
    img_h      dd 0
    stride     dd 0
    cbSize     dd 0
    pPixels    dd 0
    hBitmap    dd 0
    pFile      dd 0
    argc       dd 0
    argv       dd 0

    align 4
    bmi:
      .biSize          dd 40
      .biWidth         dd 0
      .biHeight        dd 0
      .biPlanes        dw 1
      .biBitCount      dw 32
      .biCompression   dd 0
      .biSizeImage     dd 0
      .biXPelsPerMeter dd 0
      .biYPelsPerMeter dd 0
      .biClrUsed       dd 0
      .biClrImportant  dd 0

section '.text' code readable executable
start:
    invoke  GetCommandLineW
    invoke  CommandLineToArgvW, eax, argc
    mov     [argv], eax

    cmp     dword [argc], 2
    jl      .use_default
    mov     eax, [argv]
    mov     ebx, [eax+4]
    mov     [pFile], ebx
    jmp     .init_wic

.use_default:
    mov     [pFile], wszFile

.init_wic:
    invoke  CoInitialize, 0

    invoke  CoCreateInstance, CLSID_WICImagingFactory, 0, 1, IID_IWICImagingFactory, pFactory
    test    eax, eax
    jnz     .error

    mov     eax, [pFactory]
    mov     edx, [eax]
    stdcall dword [edx+12], eax, [pFile], 0, 0x80000000, 0, pDecoder
    test    eax, eax
    jnz     .error

    mov     eax, [pDecoder]
    mov     edx, [eax]
    stdcall dword [edx+52], eax, 0, pFrame
    test    eax, eax
    jnz     .error

    mov     eax, [pFactory]
    mov     edx, [eax]
    stdcall dword [edx+40], eax, pConverter
    test    eax, eax
    jnz     .error

    mov     eax, [pConverter]
    mov     edx, [eax]
    stdcall dword [edx+32], eax, [pFrame], GUID_WICPixelFormat32bppPBGRA, 0, 0, 0, 0, 0
    test    eax, eax
    jnz     .error

    mov     eax, [pConverter]
    mov     edx, [eax]
    stdcall dword [edx+12], eax, img_w, img_h

    mov     [bmi.biSize], 40
    mov     eax, [img_w]
    mov     [bmi.biWidth], eax
    mov     eax, [img_h]
    neg     eax
    mov     [bmi.biHeight], eax
    mov     [bmi.biPlanes], 1
    mov     [bmi.biBitCount], 32
    mov     [bmi.biCompression], 0

    invoke  CreateDIBSection, 0, bmi, 0, pPixels, 0, 0
    mov     [hBitmap], eax

    mov     eax, [img_w]
    shl     eax, 2
    mov     [stride], eax
    imul    eax, [img_h]
    mov     [cbSize], eax

    mov     eax, [pConverter]
    mov     edx, [eax]
    stdcall dword [edx+28], eax, 0, [stride], [cbSize], [pPixels]

    mov     eax, [pConverter]
    mov     edx, [eax]
    stdcall dword [edx+8], eax

    mov     eax, [pFrame]
    mov     edx, [eax]
    stdcall dword [edx+8], eax

    mov     eax, [pDecoder]
    mov     edx, [eax]
    stdcall dword [edx+8], eax

    mov     eax, [pFactory]
    mov     edx, [eax]
    stdcall dword [edx+8], eax
    jmp     .win_init

.error:
    invoke  MessageBoxA, 0, szError, szTitle, 0x10
    invoke  ExitProcess, 1

.win_init:
    invoke  GetModuleHandleA, 0
    mov     [wc.hInstance], eax
    invoke  RegisterClassA, wc

    invoke  CreateWindowExA, 0, szClass, szTitle, WS_OVERLAPPEDWINDOW or WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, 800, 600, 0, 0, [wc.hInstance], 0

msg_loop:
    invoke  GetMessageA, msg, 0, 0, 0
    test    eax, eax
    jz      end_loop
    invoke  TranslateMessage, msg
    invoke  DispatchMessageA, msg
    jmp     msg_loop

end_loop:
    cmp     [hBitmap], 0
    je      .skip_del
    invoke  DeleteObject, [hBitmap]
.skip_del:
    invoke  CoUninitialize
    invoke  ExitProcess, 0

proc WindowProc uses ebx esi, hwnd, wmsg, wparam, lparam
    cmp     [wmsg], WM_PAINT
    je      .wm_paint
    cmp     [wmsg], WM_DESTROY
    je      .wm_destroy

.def:
    invoke  DefWindowProcA, [hwnd], [wmsg], [wparam], [lparam]
    ret

.wm_paint:
    invoke  BeginPaint, [hwnd], ps
    cmp     [hBitmap], 0
    je      .end_paint

    invoke  CreateCompatibleDC, [ps.hdc]
    mov     ebx, eax
    invoke  SelectObject, ebx, [hBitmap]
    mov     esi, eax

    invoke  BitBlt, [ps.hdc], 0, 0, [img_w], [img_h], ebx, 0, 0, SRCCOPY

    invoke  SelectObject, ebx, esi
    invoke  DeleteDC, ebx

.end_paint:
    invoke  EndPaint, [hwnd], ps
    xor     eax, eax
    ret

.wm_destroy:
    invoke  PostQuitMessage, 0
    xor     eax, eax
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL',\
        user32, 'USER32.DLL',\
        gdi32, 'GDI32.DLL',\
        ole32, 'OLE32.DLL',\
        shell32, 'SHELL32.DLL'

    import kernel32,\
        GetModuleHandleA, 'GetModuleHandleA',\
        GetCommandLineW, 'GetCommandLineW',\
        ExitProcess, 'ExitProcess'

    import user32,\
        RegisterClassA, 'RegisterClassA',\
        CreateWindowExA, 'CreateWindowExA',\
        GetMessageA, 'GetMessageA',\
        TranslateMessage, 'TranslateMessage',\
        DispatchMessageA, 'DispatchMessageA',\
        DefWindowProcA, 'DefWindowProcA',\
        BeginPaint, 'BeginPaint',\
        EndPaint, 'EndPaint',\
        PostQuitMessage, 'PostQuitMessage',\
        MessageBoxA, 'MessageBoxA'

    import gdi32,\
        CreateDIBSection, 'CreateDIBSection',\
        CreateCompatibleDC, 'CreateCompatibleDC',\
        SelectObject, 'SelectObject',\
        BitBlt, 'BitBlt',\
        DeleteDC, 'DeleteDC',\
        DeleteObject, 'DeleteObject'

    import ole32,\
        CoInitialize, 'CoInitialize',\
        CoCreateInstance, 'CoCreateInstance',\
        CoUninitialize, 'CoUninitialize'

    import shell32,\
        CommandLineToArgvW, 'CommandLineToArgvW'
