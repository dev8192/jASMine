format PE GUI 4.0
entry start

include 'win32a.inc'

section '.data' data readable writeable
    h_dc dd ?
    h_cdc dd ?
    h_bmp dd ?
    h_old dd ?
    p_bits dd ?
    h_file dd ?
    bytes_written dd ?
    bmi BITMAPINFO
    header db 'RIFF', 0, 0, 0, 0, 'WEBPVP8L', 0, 0, 0, 0, 0x2F
    db 0x8F, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
    filename db 'output.webp', 0

section '.text' code readable executable
    proc start
        invoke GetDC, NULL
        mov [h_dc], eax
        invoke CreateCompatibleDC, [h_dc]
        mov [h_cdc], eax
        mov [bmi.bmiHeader.biSize], sizeof.BITMAPINFOHEADER
        mov [bmi.bmiHeader.biWidth], 400
        mov [bmi.bmiHeader.biHeight], -400
        mov [bmi.bmiHeader.biPlanes], 1
        mov [bmi.bmiHeader.biBitCount], 32
        mov [bmi.bmiHeader.biCompression], BI_RGB
        invoke CreateDIBSection, [h_cdc], bmi, DIB_RGB_COLORS, p_bits, NULL, 0
        mov [h_bmp], eax
        invoke SelectObject, [h_cdc], [h_bmp]
        mov [h_old], eax
        invoke CreateSolidBrush, 0x000000FF
        push eax
        invoke SelectObject, [h_cdc], eax
        push eax
        invoke Ellipse, [h_cdc], 50, 50, 250, 250
        pop eax
        invoke SelectObject, [h_cdc], eax
        invoke DeleteObject, eax
        invoke CreateSolidBrush, 0x00FF0000
        push eax
        invoke SelectObject, [h_cdc], eax
        push eax
        invoke Rectangle, [h_cdc], 150, 150, 350, 300
        pop eax
        invoke SelectObject, [h_cdc], eax
        invoke DeleteObject, eax
        mov ecx, 160000
        mov edi, [p_bits]
    .loop:
        or dword [edi], 0xFF0000FF
        add edi, 4
        dec ecx
        jnz .loop
        mov eax, 640021
        mov dword [header+4], eax
        mov eax, 640013
        mov dword [header+12], eax
        invoke CreateFile, filename, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL
        mov [h_file], eax
        invoke WriteFile, [h_file], header, 29, bytes_written, NULL
        invoke WriteFile, [h_file], [p_bits], 640000, bytes_written, NULL
        invoke CloseHandle, [h_file]
        invoke SelectObject, [h_cdc], [h_old]
        invoke DeleteObject, [h_bmp]
        invoke DeleteDC, [h_cdc]
        invoke ReleaseDC, NULL, [h_dc]
        invoke ExitProcess, 0
    endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll', \
            user32, 'user32.dll', \
            gdi32, 'gdi32.dll'

    import kernel32, \
           CreateFile, 'CreateFileA', \
           WriteFile, 'WriteFile', \
           CloseHandle, 'CloseHandle', \
           ExitProcess, 'ExitProcess'

    import user32, \
           GetDC, 'GetDC', \
           ReleaseDC, 'ReleaseDC'

    import gdi32, \
           CreateCompatibleDC, 'CreateCompatibleDC', \
           CreateDIBSection, 'CreateDIBSection', \
           SelectObject, 'SelectObject', \
           CreateSolidBrush, 'CreateSolidBrush', \
           DeleteObject, 'DeleteObject', \
           DeleteDC, 'DeleteDC', \
           Ellipse, 'Ellipse', \
           Rectangle, 'Rectangle'
