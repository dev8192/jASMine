format PE CONSOLE 4.0
entry start

section '.code' code readable executable

start:
    ; -------------------------------------------------------------------------
    ; 1. Locate NTDLL.DLL Base Address from the PEB (Process Environment Block)
    ; -------------------------------------------------------------------------
    mov     eax, [fs:0x30]          ; EAX = Pointer to PEB
    mov     eax, [eax + 0x0C]       ; EAX = Pointer to PEB_LDR_DATA
    mov     eax, [eax + 0x1C]       ; EAX = InInitializationOrderModuleList (1st node: ntdll)
    mov     eax, [eax]              ; EAX = 2nd node (kernel32 or ntdll depending on OS)
    
.find_ntdll_loop:
    mov     ebx, [eax + 0x08]       ; EBX = Module Base Address
    mov     edi, [eax + 0x20]       ; EDI = Pointer to BaseDllName (Unicode String Buffer)
    
    ; Simple hash check or letter check for 'n' or 'N' to ensure it is ntdll.dll
    movzx   cx, word [edi]          ; Get first wide char of DLL name
    cmp     cx, 'n'
    je      .found_ntdll
    cmp     cx, 'N'
    je      .found_ntdll
    mov     eax, [eax]              ; Advance to next module in list
    jmp     .find_ntdll_loop

.found_ntdll:
    mov     [ntdll_base], ebx       ; Save NTDLL base address

    ; -------------------------------------------------------------------------
    ; 2. Resolve API Functions via Export Directory Parsing
    ; -------------------------------------------------------------------------
    mov     edx, [hash_sprintf]
    call    GetProcAddressByHash
    mov     [_sprintf], eax

    mov     edx, [hash_NtDisplayString]
    call    GetProcAddressByHash
    mov     [_NtDisplayString], eax

    mov     edx, [hash_NtDelayExecution]
    call    GetProcAddressByHash
    mov     [_NtDelayExecution], eax

    ; -------------------------------------------------------------------------
    ; 3. Fetch current Process ID via the TEB (Thread Environment Block)
    ; -------------------------------------------------------------------------
    mov     eax, [fs:0x18]          ; EAX = Pointer to TEB
    mov     eax, [eax + 0x20]       ; EAX = ClientId -> UniqueProcessId
    mov     [current_pid], eax

    ; -------------------------------------------------------------------------
    ; 4. Format output text using ntdll!sprintf
    ; -------------------------------------------------------------------------
    push    [current_pid]
    push    szFormat
    push    szBuffer
    call    [_sprintf]
    add     esp, 12                 ; C-decl stack cleanup

    ; -------------------------------------------------------------------------
    ; 5. Print to console using low-level ntdll!NtDisplayString
    ; -------------------------------------------------------------------------
    ; NtDisplayString expects a pointer to a counted UNICODE_STRING structure.
    ; For absolute minimal structural overhead, we convert our text inline to wide format.
    lea     esi, [szBuffer]
    lea     edi, [szUnicodeBuf]
    xor     ecx, ecx
.ascii_to_unicode:
    lodsb
    stosb
    mov     byte [edi], 0
    inc     edi
    inc     ecx
    test    al, al
    jnz     .ascii_to_unicode
    
    ; Populate the UNICODE_STRING structure parameters
    shl     ecx, 1                  ; Length in bytes (chars * 2)
    sub     ecx, 2                  ; Exclude null terminator
    mov     [uni_Length], cx
    add     cx, 2
    mov     [uni_MaxLength], cx

    lea     eax, [uni_Length]
    push    eax
    call    [_NtDisplayString]

    ; -------------------------------------------------------------------------
    ; 6. True Indefinite Sleep Loop via ntdll!NtDelayExecution
    ; -------------------------------------------------------------------------
.infinite_sleep_loop:
    ; NtDelayExecution takes (BOOLEAN Alertable, PLARGE_INTEGER DelayInterval)
    ; A negative value specifies a relative time interval in 100-nanosecond units.
    ; 0x8000000000000000 is the largest possible negative 64-bit int (roughly 29,227 years).
    push    delay_high
    push    delay_low
    mov     eax, esp                ; EAX points to our 64-bit LARGE_INTEGER timeout structure on stack
    
    push    eax                     ; Parameter 2: PLARGE_INTEGER
    push    0                       ; Parameter 1: Alertable = FALSE
    call    [_NtDelayExecution]
    
    add     esp, 8                  ; Clean stack variables
    jmp     .infinite_sleep_loop    ; Loop back immediately if it ever wakes up


; =============================================================================
; Helper Routine: GetProcAddressByHash
; Inputs:  EBX = NTDLL Base, EDX = Targeted Function Name ROR13 Hash
; Output:  EAX = Function Pointer
; Destroys: EAX, ECX, ESI, EDI
; =============================================================================
GetProcAddressByHash:
    push    ebp
    push    edx
    mov     esi, [ebx + 0x3C]       ; ESI = DOS -> PE Header Offset
    mov     esi, [ebx + esi + 0x78] ; ESI = Export Data Directory RVA
    add     esi, ebx                ; ESI = Export Directory Virtual Address
    
    mov     ecx, [esi + 0x18]       ; ECX = Number of Named Functions
    mov     ebp, [esi + 0x20]       ; EBP = AddressOfNames RVA
    add     ebp, ebx                ; EBP = AddressOfNames Virtual Address

.search_loop:
    dec     ecx
    js      .failed
    mov     edi, [ebp + ecx*4]      ; EDI = Function Name RVA
    add     edi, ebx                ; EDI = Function Name String Address
    
    ; Compute ROR13 Hash of the current string name
    push    ecx
    xor     eax, eax
    xor     ecx, ecx
.hash_char_loop:
    mov     cl, [edi]
    test    cl, cl
    jz      .hash_finished
    ror     eax, 13
    add     eax, ecx
    inc     edi
    jmp     .hash_char_loop
.hash_finished:
    pop     ecx
    
    cmp     eax, [esp]              ; Compare computed hash with requested hash
    jne     .search_loop            ; If not a match, test next function
    
    ; Extract correct Ordinal
    mov     edi, [esi + 0x24]       ; EDI = AddressOfNameOrdinals RVA
    add     edi, ebx
    movzx   ecx, word [edi + ecx*2] ; ECX = Function Ordinal Index
    
    ; Extract Address Function Pointer
    mov     edi, [esi + 0x1C]       ; EDI = AddressOfFunctions RVA
    add     edi, ebx
    mov     eax, [edi + ecx*4]      ; EAX = Function RVA
    add     eax, ebx                ; EAX = Functional Absolute Memory Pointer
    jmp     .done

.failed:
    xor     eax, eax                ; Return NULL if not found
.done:
    pop     edx
    pop     ebp
    ret

; =============================================================================
; Data Space allocated inline inside the code segment (No data sections)
; =============================================================================
align 4
ntdll_base          dd 0
current_pid         dd 0

; Function Table Target Resolution References
_sprintf            dd 0
_NtDisplayString    dd 0
_NtDelayExecution   dd 0

; Pre-calculated ROR13 Hashes for targeted exports
hash_sprintf         dd 0x7D943015  ; "sprintf"
hash_NtDisplayString dd 0x6E4AA235  ; "NtDisplayString"
hash_NtDelayExecution dd 0x17316A7B ; "NtDelayExecution"

; Large Integer Time limits parameters (0x8000000000000000)
delay_low            dd 0x00000000
delay_high           dd 0x80000000

; Strings & IO Workspace
szFormat            db 'Current Process ID via NTDLL: %d', 13, 10, 0
szBuffer            db 128 dup (0)

; Native Win32 Counted Unicode String Layout Structure
uni_Length          dw 0
uni_MaxLength       dw 0
uni_BufferPtr       dd szUnicodeBuf
szUnicodeBuf        db 256 dup (0)
