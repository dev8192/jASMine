include 'compiler/header.x86.inc'
include 'kernel32/code_page.inc'
include 'util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke puts, str1
    cinvoke puts, str2
    invoke SetConsoleOutputCP, CP_UTF8
    cinvoke puts, str1
    cinvoke puts, str2
    invoke SetConsoleOutputCP, CP_WIN1251
    cinvoke puts, str1
    cinvoke puts, str2
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local temp_buf[32]:BYTE, out_buf[32]:BYTE
    invoke MultiByteToWideChar, CP_UTF8, 0, str1, -1, addr temp_buf, 32
    test eax, eax
    jnz .wide_char_to_multi_byte
    cinvoke puts, 'MultiByteToWideChar error'
    jmp .exit
.wide_char_to_multi_byte:
    invoke WideCharToMultiByte, CP_WIN1251, 0, addr temp_buf, -1, addr out_buf, 32, 0, 0
    test eax, eax
    jnz .print_result
    cinvoke puts, 'WideCharToMultiByte error'
    jmp .exit
.print_result:
    invoke SetConsoleOutputCP, CP_WIN1251
    cinvoke puts, addr out_buf
    stdcall print_bytes, addr out_buf, 16
    stdcall print_bytes, addr str2, 7
.exit:
    ret
endp

include 'compiler/footer_data.inc'
str1     db 'привет', 0
str2     db 0xEF, 0xF0, 0xE8, 0xE2, 0xE5, 0xF2, 0

.idata
library kernel32,               'kernel32.dll',\
        msvcrt,                 'msvcrt.dll'
import  kernel32,\
        MultiByteToWideChar,    'MultiByteToWideChar',\
        WideCharToMultiByte,    'WideCharToMultiByte',\
        SetConsoleOutputCP,     'SetConsoleOutputCP',\
        ExitProcess,            'ExitProcess'
import  msvcrt,\
        printf,                 'printf',\
        puts,                   'puts'
