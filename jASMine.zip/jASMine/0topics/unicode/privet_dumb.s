format PE CONSOLE 4.0
entry start

include 'win32w.inc'

section '.code' code readable executable
  start:
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax

    ; Use the Wide version of the console writer
    invoke WriteConsoleW, [stdout], msg, msg_len, written, 0
    invoke ExitProcess, 0

section '.data' data readable writeable
    ; Hex codes for "привет мир" (UTF-16 Little Endian)
    ; п=043f, р=0440, и=0438, в=0432, е=0435, т=0442, [space]=0020, м=043c, и=0438, р=0440
    msg      dw 043fh, 0440h, 0438h, 0432h, 0435h, 0442h, 0020h, 043ch, 0438h, 0440h, 000dh, 000ah
    msg_len  = ($ - msg) / 2
    stdout   dd ?
    written  dd ?

section '.idata' import data readable
    library kernel32, 'kernel32.dll'
    import kernel32, \
           GetStdHandle, 'GetStdHandle', \
           WriteConsoleW, 'WriteConsoleW', \
           ExitProcess, 'ExitProcess'
