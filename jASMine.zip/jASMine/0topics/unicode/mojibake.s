include 'compiler/header.x86.inc'
include 'kernel32/code_page.inc'
include 'util/print_bytes.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    cinvoke puts, str1
    cinvoke puts, str2
    invoke SetConsoleOutputCP, CP_UTF8
    cinvoke puts, str1
    cinvoke puts, str2
    invoke SetConsoleOutputCP, CP_WIN1251
    cinvoke puts, str1
    cinvoke puts, str2
    ret
endp

include 'compiler/footer_data.inc'
str1     db 'привет', 0
str2     db 0xEF, 0xF0, 0xE8, 0xE2, 0xE5, 0xF2, 0

.idata
library kernel32,               'kernel32.dll',\
        msvcrt,                 'msvcrt.dll'
import  kernel32,\
        SetConsoleOutputCP,     'SetConsoleOutputCP',\
        ExitProcess,            'ExitProcess'
import  msvcrt,\
        printf,                 'printf',\
        puts,                   'puts'
