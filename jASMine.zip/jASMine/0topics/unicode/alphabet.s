format PE console 4.0
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    mode_u16_text = 0x00020000
    alphabet_buffer rw 70

section '.code' code readable executable

; Generates a case-specific Russian alphabet block into EDI pointer
proc generate_alphabet_block base_char, yo_char
    push edi
    mov ecx, 32
    mov dx, [base_char]
.loop_chars:
    mov [edi], dx
    add edi, 2
    
    ; If we just wrote 'Е' or 'е', inject 'Ё' or 'ё' right after it
    cmp dx, 0x0415              ; Upper case 'Е'
    je .inject_yo
    cmp dx, 0x0435              ; Lower case 'е'
    je .inject_yo
    jmp .next_iteration

.inject_yo:
    push ax
    mov ax, [yo_char]
    mov [edi], ax
    add edi, 2
    pop ax

.next_iteration:
    inc dx
    dec ecx
    jnz .loop_chars
    
    pop edi
    ret
endp

proc start
    locals
        string_builder dd ?
    endl
    cinvoke __p__iob
    add eax, 32
    cinvoke _setmode, eax, mode_u16_text
    
    lea eax, [alphabet_buffer]
    mov [string_builder], eax
    
    ; 1. Generate Uppercase Block (А to Я with Ё in place)
    invoke generate_alphabet_block, 0x0410, 0x0401
    
    ; 2. Advance pointer past uppercase letters (33 letters * 2 bytes = 66)
    mov eax, [string_builder]
    add eax, 66
    
    ; 3. Inject a formatting space between the blocks
    mov word [eax], 0x0020
    add eax, 2
    mov [string_builder], eax
    
    ; 4. Generate Lowercase Block (а to я with ё in place)
    invoke generate_alphabet_block, 0x0430, 0x0451
    
    ; 5. Null-terminate the completed wide string array
    mov eax, [string_builder]
    mov word [eax + 66], 0
    
    ; 6. Print the completely assembled sequence
    cinvoke _putws, alphabet_buffer
    
    invoke ExitProcess, 0
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt, 'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess'

    import msvcrt,\
           __p__iob, '__p__iob',\
           _putws, '_putws',\
           _setmode, '_setmode'
