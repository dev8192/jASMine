
; Range               | Size   | Pattern                             | Capacity
; 0x0000 to 0x007F    | 1 (8)  | 0xxxxxxx                            | 7
; 0x0080 to 0x07FF    | 2 (16) | 110xxxxx 10xxxxxx                   | 5 + 6 * 1 = 5 + 6 = 11
; 0x0800 to 0xFFFF    | 3 (24) | 1110xxxx 10xxxxxx 10xxxxxx          | 4 + 6 * 2 = 4 + 12 = 16
; 0x10000 to 0x10FFFF | 4 (32) | 11110xxx 10xxxxxx 10xxxxxx 10xxxxxx | 3 + 6 * 3 = 3 + 18 = 21

format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

; There are 1114112 code points in the Unicode
; (from 0x0000 to 0x10FFFF)
proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, fmt_d, 0x0010FFFF + 1
    cinvoke printf, fmt_d, 00000000_00010000_11111111_11111111b + 1
    cinvoke printf, fmt_d, 1114112
    mov eax, 1111111111111111b
    inc eax
    add eax, 11111111111111111111b
    inc eax
    cinvoke printf, fmt_d, eax
    mov eax, 1 shl 16
    add eax, 1 shl 20
    cinvoke printf, fmt_d, eax
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    cinvoke printf, fmt_x, 0xD800
    cinvoke printf, fmt_x, 11011000_00000000b
    cinvoke printf, fmt_x, 0xDBFF
    cinvoke printf, fmt_x, 11011011_11111111b
    cinvoke printf, fmt_x, 0xDC00
    cinvoke printf, fmt_x, 11011100_00000000b
    cinvoke printf, fmt_x, 0xDFFF
    cinvoke printf, fmt_x, 11011111_11111111b
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    cinvoke printf, fmt_x, 11111111111111111111b
    cinvoke printf, fmt_x, 0xFFFFF
    mov eax, 0x10FFFF
    sub eax, 0x10000
    cinvoke printf, fmt_x, eax
    ret
endp

; Hex:       1    0    F    F    F    F
; Binary:    1 0000 1111 1111 1111 1111

; Template:  1 1 1 1 0 x x x   1 0 x x x x x x   1 0 x x x x x x   1 0 x x x x x x
; Your Bits:           1 0 0       0 0 1 1 1 1       1 1 1 1 1 1       1 1 1 1 1 1
; Result:    1 1 1 1 0 1 0 0   1 0 0 0 1 1 1 1   1 0 1 1 1 1 1 1   1 0 1 1 1 1 1 1
;                         F4                8F                BF                BF

proc main
    cinvoke puts, '*** main4 ***'
    cinvoke printf, fmt_x, 0x007F
    cinvoke printf, fmt_x, (1 shl 7) - 1
    cinvoke printf, fmt_x, 0x07FF
    cinvoke printf, fmt_x, (1 shl 11) - 1
    cinvoke printf, fmt_x, 0xFFFF
    cinvoke printf, fmt_x, (1 shl 16) - 1
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
