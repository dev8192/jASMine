format PE
entry start

include 'win32ax.inc'

LC_ALL  = 0

section '.data' data readable writeable
    str1      db 'привет мир', 10, 0
    str1_len  = $ - str1 - 1
    fmt_s       db '%s', 10, 0
    locale_utf8     db '.UTF-8', 0

section '.code' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    local stdout:DWORD, written:DWORD
    invoke SetConsoleOutputCP, CP_UTF8
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax
    invoke WriteFile, [stdout], str1, str1_len, addr written, 0
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    invoke SetConsoleOutputCP, CP_UTF8
   ;cinvoke setlocale, LC_ALL, locale_utf8
   ;cinvoke printf, str1
    cinvoke printf, fmt_s, str1
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            SetConsoleOutputCP, 'SetConsoleOutputCP',\
            GetStdHandle,       'GetStdHandle',\
            WriteFile,          'WriteFile',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            setlocale,          'setlocale',\
            printf,             'printf',\
            puts,               'puts'
