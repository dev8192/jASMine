format PE
entry start

include 'win32a.inc'
include 'encoding/utf8.inc'

section '.data' data readable writeable
    msg      du 'привет мир', 10 
    msg_len  = ($ - msg) / 2
    stdout   dd ?
    written  dd ?

section '.text' code readable executable
start:
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax
    invoke WriteConsoleW, [stdout], msg, msg_len, written, 0
    invoke ExitProcess, 0

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32, \
           GetStdHandle, 'GetStdHandle', \
           WriteConsoleW, 'WriteConsoleW', \
           ExitProcess, 'ExitProcess'
