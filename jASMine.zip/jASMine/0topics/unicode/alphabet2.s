format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str1        db 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ', 0
    str1_len    = $ - str1
    fmt_c       db '%c', 10, 0
    fmt_s       db '%s', 10, 0

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include '../../util/print_bytes.text.inc'

proc print_char, buf, pos
    local temp[3]:BYTE
    mov edx, [buf]
    mov eax, [pos]
    shl eax, 1
    add edx, eax
    mov eax, [edx]
    mov [temp], al
    mov eax, [edx + 1]
    mov [temp + 1], al
    mov [temp + 2], 0
    cinvoke puts, addr temp
    ret
endp

proc main
    cinvoke puts, '*** main1 ***'
    invoke SetConsoleOutputCP, CP_UTF8
    cinvoke puts, str1
    stdcall print_char, str1, 0
    stdcall print_char, str1, 1
    stdcall print_char, str1, 2
    stdcall print_char, str1, 32
    stdcall print_bytes, str1, str1_len
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            SetConsoleOutputCP, 'SetConsoleOutputCP',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
