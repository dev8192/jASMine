format PE
entry start

include 'win32ax.inc'

STDOUT_FILENO = 1
_O_U16TEXT  = 0x20000

section '.data' data readable writeable
    fmt_x       db '%x', 10, 0
    fmt_d_space db '%d ', 0
    newline     db 10, 0

    str1        db 'АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ', 0
    str2        db 'абвгдеёжзийклмнопрстуфхцчшщъыьэюя', 0
    arr1        dd  0x0410, 0x0411, 0x0412, 0x0413, 0x0414, 0x0415, 0x0401, 0x0416,\
                    0x0417, 0x0418, 0x0419, 0x041A, 0x041B, 0x041C, 0x041D, 0x041E,\
                    0x041F, 0x0420, 0x0421, 0x0422, 0x0423, 0x0424, 0x0425, 0x0426,\
                    0x0427, 0x0428, 0x0429, 0x042A, 0x042B, 0x042C, 0x042D, 0x042E,\
                    0x042F, 0x0000
    arr2        dd  0x0430, 0x0431, 0x0432, 0x0433, 0x0434, 0x0435, 0x0451, 0x0436,\
                    0x0437, 0x0438, 0x0439, 0x043A, 0x043B, 0x043C, 0x043D, 0x043E,\
                    0x043F, 0x0440, 0x0441, 0x0442, 0x0443, 0x0444, 0x0445, 0x0446,\
                    0x0447, 0x0448, 0x0449, 0x044A, 0x044B, 0x044C, 0x044D, 0x044E,\
                    0x044F, 0x0000

include '../../util/print_bytes.data.inc'

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

include 'code_point.text.inc'
include '../../util/print_bytes.text.inc'

proc main1 uses ebx esi edi
    cinvoke puts, '*** main1 ***'
    mov ebx, 33
    mov esi, arr1
    mov edi, arr2
.loop:
    mov eax, [edi]
    sub eax, [esi]
    cinvoke printf, fmt_d_space, eax
    add esi, 4
    add edi, 4
    dec ebx
    jnz .loop
    cinvoke printf, newline
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local buf[34]:WORD
    cinvoke _setmode, STDOUT_FILENO, _O_U16TEXT
    stdcall code_point_to_utf16, addr buf, arr1, 34
    cinvoke _putws, addr buf
    stdcall code_point_to_utf16, addr buf, arr2, 34
    cinvoke _putws, addr buf
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    local buf[34]:WORD
    invoke SetConsoleOutputCP, CP_UTF8
    
    cinvoke puts, str1
    stdcall code_point_to_utf8, addr buf, arr1, 34
    stdcall print_bytes, addr buf, 34 * 2
   ;cinvoke puts, addr buf

   ;cinvoke puts, str2
   ;stdcall code_point_to_utf8, addr buf, arr2, 34
   ;cinvoke puts, addr buf
    ret
endp

proc main
    cinvoke puts, '*** main4 ***'
   ;stdcall code_point_to_utf8_single, 0x0410
    stdcall code_point_to_utf8_single, 0
    cinvoke printf, fmt_x, eax
    movzx eax, word [str1]
    cinvoke printf, fmt_x, eax
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            SetConsoleOutputCP, 'SetConsoleOutputCP',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            _putws,             '_putws',\
            _setmode,           '_setmode',\
            printf,             'printf',\
            puts,               'puts'
