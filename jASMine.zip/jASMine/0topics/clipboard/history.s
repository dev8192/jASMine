; Win + V

format PE
entry start

include 'win32a.inc'

KEY_ALL_ACCESS          = 000F003Fh
REG_OPTION_NON_VOLATILE = 0
REG_DWORD               = 4
ERROR_SUCCESS           = 0

section '.data' data readable writeable
    reg_path db 'Software\Microsoft\Clipboard', 0
    reg_val  db 'EnableClipboardHistory', 0
    msg_on   db 'Clipboard history turned ON', 10, 0
    msg_off  db 'Clipboard history turned OFF', 10, 0
    msg_err  db 'Registry error', 10, 0

    hKey     dd ?
    val      dd 0
    vsz      dd 4

section '.text' code readable executable
start:
    stdcall toggle_clipboard_history
    invoke ExitProcess, 0

proc toggle_clipboard_history
    invoke RegCreateKeyEx, HKEY_CURRENT_USER, reg_path, 0, 0,\
        REG_OPTION_NON_VOLATILE, KEY_ALL_ACCESS, 0, hKey, 0
    cmp eax, ERROR_SUCCESS
    jne .error

    mov [vsz], 4
    invoke RegQueryValueEx, [hKey], reg_val, 0, 0, val, vsz
    cmp eax, ERROR_SUCCESS
    je .toggle

    mov [val], 0

.toggle:
    xor [val], 1
    invoke RegSetValueEx, [hKey], reg_val, 0, REG_DWORD, val, 4
    cmp eax, ERROR_SUCCESS
    jne .error_close

    cmp [val], 1
    je .print_on

    cinvoke printf, msg_off
    jmp .close_key

.print_on:
    cinvoke printf, msg_on

.close_key:
    invoke RegCloseKey, [hKey]
    ret

.error_close:
    invoke RegCloseKey, [hKey]
.error:
    cinvoke printf, msg_err
    ret
endp

section '.idata' import data readable
    library advapi32,           'advapi32.dll',\
            msvcrt,             'msvcrt.dll',\
            kernel32,           'kernel32.dll'
    import  advapi32,\
            RegCreateKeyEx,     'RegCreateKeyExA',\
            RegQueryValueEx,    'RegQueryValueExA',\
            RegSetValueEx,      'RegSetValueExA',\
            RegCloseKey,        'RegCloseKey'
    import  msvcrt,\
            printf,             'printf'
    import  kernel32,\
            ExitProcess,        'ExitProcess'
