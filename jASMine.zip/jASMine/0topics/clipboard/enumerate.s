format PE Console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    hClipboardData  dd 0
    pText           dd 0
    error_msg       db 'No text found in clipboard.', 0
    fmt_text        db '"%s"', 10, 0

section '.text' code readable executable
start:
    invoke  OpenClipboard, 0
    test    eax, eax
    jz      .exit_error

    invoke  GetClipboardData, CF_TEXT
    test    eax, eax
    jz      .close_and_error
    mov     [hClipboardData], eax

    invoke  GlobalLock, [hClipboardData]
    test    eax, eax
    jz      .close_and_error
    mov     [pText], eax

    cinvoke printf, fmt_text, [pText]

    invoke  GlobalUnlock, [hClipboardData]
    invoke  CloseClipboard
    jmp     .finish

.close_and_error:
    invoke  CloseClipboard
.exit_error:
    cinvoke printf, error_msg
.finish:
    invoke  ExitProcess, 0

section '.idata' import data readable

    library kernel32, 'kernel32.dll',\
            user32,   'user32.dll',\
            msvcrt,   'msvcrt.dll'

    import kernel32,\
           ExitProcess, 'ExitProcess',\
           GlobalLock,  'GlobalLock',\
           GlobalUnlock,'GlobalUnlock'

    import user32,\
           OpenClipboard,    'OpenClipboard',\
           GetClipboardData, 'GetClipboardData',\
           CloseClipboard,   'CloseClipboard'

    import msvcrt,\
           printf, 'printf'
