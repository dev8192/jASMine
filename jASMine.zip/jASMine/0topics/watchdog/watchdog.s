format PE console
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    szWatchdogArg  db '/watchdog', 0
    szMainMode     db '[MAIN] Running. Watchdog PID: %u. Press ENTER to close normally...', 10, 0
    szWatchMode    db '[WATCHDOG] Monitoring Main App (PID: %u)...', 10, 0
    szRestarting   db '[WATCHDOG] ALERT: Main App terminated unexpectedly! Restarting it...', 10, 0
    szNormalExit   db '[WATCHDOG] Main App closed cleanly. Exiting watchdog.', 10, 0
    
    ; Structure storage for Process Creation
    pi             PROCESS_INFORMATION ?
    si             STARTUPINFO ?
    
    hTargetProcess dd ?
    dwTargetPID    dd ?
    szSelfPath     db MAX_PATH dup(0)
    szCmdLine      db MAX_PATH + 20 dup(0)
    szFormatCmd    db '"%s" /watchdog', 0

section '.code' code readable executable
start:
    ; 1. Get the command line arguments to see how we were launched
    invoke GetCommandLine
    ; Check if "/watchdog" string exists in the command line
    invoke StrStr, eax, szWatchdogArg
    test eax, eax
    jnz .run_as_watchdog

; =========================================================================
; MAIN PROCESS MODE
; =========================================================================
.run_as_main:
    ; A. Get path to our own executable so we can launch a copy of it
    invoke GetModuleFileName, 0, szSelfPath, MAX_PATH
    
    ; B. Format command line: "path_to_exe" /watchdog
    cinvoke wsprintf, szCmdLine, szFormatCmd, szSelfPath
    
    ; C. Initialize STARTUPINFO structure
    invoke RtlZeroMemory, si, sizeof.STARTUPINFO
    mov [si.cb], sizeof.STARTUPINFO
    
    ; D. Spawn the Watchdog instance
    invoke CreateProcess, 0, szCmdLine, 0, 0, FALSE, 0, 0, 0, si, pi
    test eax, eax
    jz .failed_start
    
    ; Save watchdog handles
    mov eax, [pi.dwProcessId]
    mov [dwTargetPID], eax
    mov eax, [pi.hProcess]
    mov [hTargetProcess], eax
    invoke CloseHandle, [pi.hThread] ; Thread handle not needed
    
    cinvoke printf, szMainMode, [dwTargetPID]
    
    ; Keep Main alive until user hits ENTER (simulating real runtime)
    cinvoke getchar
    
    ; Clean up and close watchdog before a graceful exit
    invoke TerminateProcess, [hTargetProcess], 0
    invoke CloseHandle, [hTargetProcess]
    invoke ExitProcess, 0

.failed_start:
    invoke ExitProcess, 1

; =========================================================================
; WATCHDOG PROCESS MODE
; =========================================================================
.run_as_watchdog:
    ; The creator process is always the parent process. 
    ; In a production app, you can pass the explicit PID via command line, 
    ; but for this demo, we will open the Parent Process.
    ; To reliably get parent handle, we grab it from PPID or inherit it.
    ; For user-mode reliability, we grab the calling process ID.
    ; NOTE: For simple demonstration, Watchdog obtains the PPID via ToolHelp snapshot
    call GetParentProcessId
    mov [dwTargetPID], eax
    test eax, eax
    jz .watchdog_exit
    
    ; Open the Main Process with SYNCHRONIZE rights to wait on it
    invoke OpenProcess, SYNCHRONIZE, FALSE, [dwTargetPID]
    mov [hTargetProcess], eax
    test eax, eax
    jz .watchdog_exit

    cinvoke printf, szWatchMode, [dwTargetPID]

.watch_loop:
    ; Infinite wait until Main App process handle becomes signaled (terminates)
    invoke WaitForSingleObject, [hTargetProcess], INFINITE
    
    ; If we reach here, Main App died! 
    ; Check its exit code to see if it was a crash/kill or normal close
    ; (Since Main kills watchdog on normal exit, reaching here usually means a crash/kill)
    cinvoke printf, szRestarting
    
    ; Clean up old handle
    invoke CloseHandle, [hTargetProcess]
    
    ; Relaunch the Main App (without arguments)
    invoke GetModuleFileName, 0, szSelfPath, MAX_PATH
    invoke RtlZeroMemory, si, sizeof.STARTUPINFO
    mov [si.cb], sizeof.STARTUPINFO
    
    invoke CreateProcess, szSelfPath, 0, 0, 0, FALSE, 0, 0, 0, si, pi
    test eax, eax
    jz .watchdog_exit
    
    ; Target the new Main app and repeat monitoring
    mov eax, [pi.dwProcessId]
    mov [dwTargetPID], eax
    mov eax, [pi.hProcess]
    mov [hTargetProcess], eax
    invoke CloseHandle, [pi.hThread]
    
    jmp .watch_loop

.watchdog_exit:
    invoke ExitProcess, 0

; =========================================================================
; HELPER: Find Parent PID using ToolHelp32 API
; =========================================================================
proc GetParentProcessId
    local pe32:PROCESSENTRY32, hSnapshot:DWORD, dwCurrentPID:DWORD
    
    invoke GetCurrentProcessId
    mov [dwCurrentPID], eax
    
    invoke CreateToolhelp32Snapshot, TH32CS_SNAPPROCESS, 0
    mov [hSnapshot], eax
    cmp eax, INVALID_HANDLE_VALUE
     je .error
     
    mov [pe32.dwSize], sizeof.PROCESSENTRY32
    invoke Process32First, [hSnapshot], addr pe32
    test eax, eax
    jz .close_snap
    
 .loop:
    mov eax, [pe32.th32ProcessID]
    cmp eax, [dwCurrentPID]
    jne .next
    
    ; Found our process entry, return the parent ID
    mov eax, [pe32.th32ParentProcessID]
    push eax
    invoke CloseHandle, [hSnapshot]
    pop eax
    ret
    
 .next:
    invoke Process32Next, [hSnapshot], addr pe32
    test eax, eax
    jnz .loop
    
 .close_snap:
    invoke CloseHandle, [hSnapshot]
 .error:
    xor eax, eax
    ret
endp

section '.idata' import data readable
    library kernel32, 'kernel32.dll',\
            msvcrt,   'msvcrt.dll',\
            shlwapi,  'shlwapi.dll'

    import kernel32,\
           GetModuleFileName, 'GetModuleFileNameA',\
           GetCommandLine,    'GetCommandLineA',\
           CreateProcess,     'CreateProcessA',\
           OpenProcess,       'OpenProcess',\
           GetCurrentProcessId,'GetCurrentProcessId',\
           CreateToolhelp32Snapshot, 'CreateToolhelp32Snapshot',\
           Process32First,    'Process32FirstA',\
           Process32Next,     'Process32NextA',\
           WaitForSingleObject,'WaitForSingleObject',\
           TerminateProcess,  'TerminateProcess',\
           CloseHandle,       'CloseHandle',\
           RtlZeroMemory,     'RtlZeroMemory',\
           ExitProcess,       'ExitProcess'

    import msvcrt,\
           printf,  'printf',\
           wsprintf,'wsprintfA',\
           getchar, 'getchar'
           
    import shlwapi,\
           StrStr,  'StrStrA'
