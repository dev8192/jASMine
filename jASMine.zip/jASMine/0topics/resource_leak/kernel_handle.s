format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_d       db '%d', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1 uses ebx
    cinvoke puts, '*** main1 ***'
    local handle_count:DWORD
    invoke GetCurrentProcess
    invoke GetProcessHandleCount, eax, addr handle_count
    cinvoke printf, fmt_d, [handle_count]
    mov ebx, [handle_count]
.loop:
    invoke CreateEvent, 0, 0, 0, 0
    test eax, eax
    jz .failed
    inc ebx
    jmp .loop
.failed:
    invoke GetLastError
    cinvoke printf, fmt_d, eax ; 1450 (ERROR_NO_SYSTEM_RESOURCES)
    cinvoke printf, fmt_d, ebx ; 16711680
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    locals
        handle_table_size   dd 1 shl 24
        sub_pages           dd 1 shl 16
        page_size           dd 1 shl 12
        entries_per_page    dd 1 shl 8
        handle_size         dd 1 shl 4
    endl
    cinvoke printf, fmt_d, [handle_table_size]
    cinvoke printf, fmt_d, [sub_pages]
    cinvoke printf, fmt_d, [page_size]
    cinvoke printf, fmt_d, [entries_per_page]
    cinvoke printf, fmt_d, [handle_size]
    mov eax, [handle_table_size]
    sub eax, [sub_pages]
    cinvoke printf, fmt_d, eax ; 16711680
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            GetCurrentProcess,      'GetCurrentProcess',\
            GetProcessHandleCount,  'GetProcessHandleCount',\
            CreateEvent,            'CreateEventA',\
            GetLastError,           'GetLastError',\
            ExitProcess,            'ExitProcess'
    import  msvcrt,\
            printf,                 'printf',\
            puts,                   'puts'
