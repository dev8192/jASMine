format PE
entry start

include 'win32ax.inc'

MS_PER_SECOND = 1000
SECONDS_PER_MINUTE = 60
MINUTES_PER_HOUR = 60
HOURS_PER_DAY = 24

section '.data' data readable writeable
    fmt db "days: %u, hours: %u, minutes: %u, ",\
            "seconds: %u, milliseconds: %u", 0

    days_val dd ?
    hours_val dd ?
    mins_val dd ?
    secs_val dd ?
    msecs_val dd ?

section '.test' code readable executable
start:
    stdcall test10
    invoke ExitProcess, 0

proc test10
    local outbuf[128]:BYTE
    local uptime:DWORD

    invoke GetTickCount
    mov [uptime], eax
    cinvoke printf, "%u%c", [uptime], 10
    stdcall format_uptime, addr outbuf, [uptime]
    cinvoke puts, addr outbuf

    mov [uptime], -1
    cinvoke printf, "%u%c", [uptime], 10
    stdcall format_uptime, addr outbuf, [uptime]
    cinvoke puts, addr outbuf
    
    ret
endp

proc format_uptime, outbuf, uptime
    mov eax, [uptime]

    xor edx, edx
    mov ecx, MS_PER_SECOND
    div ecx
    mov [msecs_val], edx
    
    xor edx, edx
    mov ecx, SECONDS_PER_MINUTE
    div ecx
    mov [secs_val], edx
    
    xor edx, edx
    mov ecx, MINUTES_PER_HOUR
    div ecx
    mov [mins_val], edx
    
    xor edx, edx
    mov ecx, HOURS_PER_DAY
    div ecx
    mov [hours_val], edx
    mov [days_val], eax

    cinvoke wsprintf, [outbuf], fmt, [days_val],\
            [hours_val], [mins_val], [secs_val], [msecs_val]
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            user32,         'user32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            GetTickCount,   'GetTickCount',\
            ExitProcess,    'ExitProcess'
    import  user32,\
            wsprintf,       'wsprintfA'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
