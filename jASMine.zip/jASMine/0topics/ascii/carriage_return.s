format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    str_a               db 5 dup('a'), 0
    str_b               db 3 dup('b'), 0
    carriage_return     db 13, 0
    line_feed           db 10, 0
    fmt                 db 'Counter: %d', 13, 0

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main1
    cinvoke puts, '*** main1 ***'
    cinvoke printf, str_a
    cinvoke printf, carriage_return
    cinvoke printf, str_b
    cinvoke printf, line_feed
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main2 ***'
    xor ebx, ebx
.loop:
    inc ebx
    cinvoke printf, fmt, ebx
    invoke Sleep, 1000
    jmp .loop
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess',\
            Sleep,          'Sleep'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
