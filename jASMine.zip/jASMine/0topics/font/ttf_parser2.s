format PE
entry start

include 'win32ax.inc'

TTF_HEADER_SIZE     equ 12
TTF_DIR_ENTRY_SIZE  equ 16

SEEK_SET = 0
SEEK_CUR = 1
SEEK_END = 2

section '.data' data readable writeable
    file_name       db 'c:\WINDOWS\Fonts\CONSOLA.TTF', 0
    mode_read       db 'rb', 0
    fmt_d           db '%d', 10, 0
    fmt_size        db 'Expected size : %d', 10
                    db 'Actual size   : %d', 10, 0
    fmt_err         db 'Error opening file', 10, 0
    fmt_tag         db '%.*s', 10, 0
    fmt_tag2        db '%c%c%c%c', 10, 0

    align 4
    ttf_header:
        .sfnt           dd ?
        .numTables      dw ?
        .searchRange    dw ?
        .entrySelector  dw ?
        .rangeShift     dw ?
    fmt_hdr         db 'sfntVersion   : %08X', 10
                    db 'numTables     : %u', 10
                    db 'searchRange   : %u', 10
                    db 'entrySelector : %u', 10
                    db 'rangeShift    : %u', 10, 0

    fmt_thdr        db 'Tag  | CheckSum | Offset   | Length   | Padding', 10
                    db '-----+----------+----------+----------+--------', 10, 0

    align 4
    dir_entry:
        .tag        dd ?
        .checkSum   dd ?
        .offset     dd ?
        .length     dd ?
    fmt_row         db '%c%c%c%c | %08X | %8u | %8u | %u', 10, 0

    align 4
    dir_entry2:
        .tag        rb 4
        .checkSum   dd ?
        .offset     dd ?
        .length     dd ?
    fmt_row2         db '%.*s | %08X | %8u | %8u | %u', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc print_header uses ebx
    movzx eax, word [ttf_header.rangeShift]
    movzx ecx, word [ttf_header.entrySelector]
    movzx edx, word [ttf_header.searchRange]
    movzx ebx, word [ttf_header.numTables]
    cinvoke printf, fmt_hdr, [ttf_header.sfnt], ebx, edx, ecx, eax
    ret
endp

proc print_row, padding
    cinvoke printf, fmt_row,\
            [dir_entry.tag + 0], [dir_entry.tag + 1],\
            [dir_entry.tag + 2], [dir_entry.tag + 3],\
            [dir_entry.checkSum], [dir_entry.offset],\
            [dir_entry.length], [padding]
    ret
endp

proc print_row2, padding
    cinvoke printf, fmt_row, 4, dir_entry.tag,\
            [dir_entry.checkSum], [dir_entry.offset],\
            [dir_entry.length], [padding]
    ret
endp

proc main
    stdcall parse_ttf
    ret
endp

proc parse_ttf uses esi edi
    local hFile:DWORD, num_tables:DWORD
    local expected_size:DWORD, actual_size:DWORD
    mov [actual_size], TTF_HEADER_SIZE

    cinvoke fopen, file_name, mode_read
    test eax, eax
    jz .err_fopen
    mov [hFile], eax

    cinvoke fseek, [hFile], 0, SEEK_END
    cinvoke ftell, [hFile]
    mov [expected_size], eax
    cinvoke fseek, [hFile], 0, SEEK_SET

    cinvoke fread, ttf_header, 1, TTF_HEADER_SIZE, [hFile]

    mov eax, [ttf_header.sfnt]
    bswap eax
    mov [ttf_header.sfnt], eax

    movzx eax, word [ttf_header.numTables]
    xchg al, ah
    mov word [ttf_header.numTables], ax
    movzx eax, ax
    mov [num_tables], eax
    mov ecx, TTF_DIR_ENTRY_SIZE
    mul ecx
    add [actual_size], eax

    movzx eax, word [ttf_header.searchRange]
    xchg al, ah
    mov word [ttf_header.searchRange], ax

    movzx eax, word [ttf_header.entrySelector]
    xchg al, ah
    mov word [ttf_header.entrySelector], ax

    movzx eax, word [ttf_header.rangeShift]
    xchg al, ah
    mov word [ttf_header.rangeShift], ax

    stdcall print_header

    cinvoke putchar, 10
    cinvoke printf, fmt_thdr

    xor esi, esi
.loop:
    cmp esi, [num_tables]
    jae .done

    cinvoke fread, dir_entry, 1, TTF_DIR_ENTRY_SIZE, [hFile]

    mov eax, [dir_entry.checkSum]
    bswap eax
    mov [dir_entry.checkSum], eax

    mov eax, [dir_entry.offset]
    bswap eax
    mov [dir_entry.offset], eax

    mov eax, [dir_entry.length]
    bswap eax
    mov [dir_entry.length], eax
    add [actual_size], eax

ALIGNMENT_SIZE      equ 4
ALIGNMENT_MASK      equ 3

    mov eax, [dir_entry.length]
    and eax, ALIGNMENT_MASK
    mov ecx, ALIGNMENT_SIZE
    sub ecx, eax
    and ecx, ALIGNMENT_MASK
    add [actual_size], ecx

    stdcall print_row, ecx

    inc esi
    jmp .loop

.err_fopen:
    cinvoke puts, 'err_fopen'
    jmp .exit

.done:
    cinvoke putchar, 10
    cinvoke fclose, [hFile]
    cinvoke printf, fmt_size, [expected_size], [actual_size]
.exit:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            fopen,          'fopen',\
            fread,          'fread',\
            fseek,          'fseek',\
            ftell,          'ftell',\
            fclose,         'fclose',\
            printf,         'printf',\
            puts,           'puts',\
            putchar,        'putchar'
