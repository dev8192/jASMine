format PE console
entry start

include 'win32a.inc'

CRYPT_STRING_HEX = 4
CRYPT_STRING_HEXRAW = 12
CRYPT_STRING_HEXADDR = 0x0000000a
CRYPT_STRING_HEXASCIIADDR = 0x0000000b
CRYPT_STRING_NOCRLF = 0x40000000

; 68656c6c6f00776f726c64
; h e l l o 0 w o r l d
; 68 65 6c 6c 6f 00 77 6f  72 6c 64
section '.data' data readable writeable
    input_str db 'hello', 0, 'world'
    ;input_str db 'hello world'
    input_len  = $ - input_str

    out_buf  rb 256
    out_len dd 256

    fmt_s  db '"%s"', 10, 0
    fmt_u  db '%u', 10, 0
    fmt_x  db '%x', 10, 0

section '.text' code readable executable
start:
    stdcall print_hex10, input_str, input_len
    invoke ExitProcess, 0

proc print_hex10, in_buf, in_len
    ;flags = CRYPT_STRING_HEX
    ;flags = CRYPT_STRING_HEXRAW
    flags = CRYPT_STRING_HEX or CRYPT_STRING_NOCRLF
    ;flags = CRYPT_STRING_HEXRAW or CRYPT_STRING_NOCRLF
    ;flags = CRYPT_STRING_HEXASCIIADDR

    invoke CryptBinaryToString, [in_buf], [in_len],\
        flags, out_buf, out_len
    cinvoke printf, fmt_u, [in_len]
    cinvoke printf, fmt_s, out_buf
    cinvoke printf, fmt_u, [out_len]
    ret
endp

proc test20
    invoke BinaryToString, [in_buf], [in_len], out_buf, out_len
    cinvoke printf, fmt_u, [in_len]
    cinvoke printf, fmt_s, out_buf
    cinvoke printf, fmt_u, [out_len]
    ret
endp

proc BinaryToString uses ebx esi, in_buf, in_len, out_buf, out_len
    ret
endp

section '.idata' import data readable
    library kernel32,               'kernel32.dll',\
            crypt32,                'crypt32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  kernel32,\
            ExitProcess,            'ExitProcess'
    import  crypt32,\
            CryptBinaryToString,    'CryptBinaryToStringA'
    import  msvcrt,\
            printf,                 'printf'
