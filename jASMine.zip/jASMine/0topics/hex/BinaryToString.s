; ----------------------------------------------------------------
; CryptBinaryToString with CRYPT_STRING_HEX or CRYPT_STRING_NOCRLF
; ----------------------------------------------------------------
format PE console
entry start

include 'win32a.inc'

HEX_A_OFFSET    = 27h
MASK_NIBBLE     = 0Fh
SHIFT_NIBBLE    = 4

section '.data' data readable writeable
    test_bin     db 0xDE, 0xAD, 0xBE, 0xEF, 0x01
    test_bin_len = $ - test_bin

    fmt_str      db '%s', 10, 'Chars written: %u', 10, 0
    fmt_fail     db 'Formatting failed', 10, 0

    str_buf      rb 64
    str_len      dd 64

section '.text' code readable executable
start:
    invoke BinaryToString, test_bin, test_bin_len, str_buf, str_len
    cmp eax, 1
    jne .error
    cinvoke printf, fmt_str, str_buf, [str_len]
    jmp .exit
.error:
    cinvoke printf, fmt_fail
.exit:
    invoke ExitProcess, 0

proc BinaryToString uses ebx esi edi, pbBinary, cbBinary, pszString, pcchString
    mov eax, [pcchString]
    test eax, eax
    jz .fail

    mov ecx, [cbBinary]
    test ecx, ecx
    jnz .calc_len

    mov ebx, 1
    jmp .check_buf

.calc_len:
    lea ebx, [ecx + ecx * 2]

.check_buf:
    mov edi, [pszString]
    test edi, edi
    jz .return_req_size

    mov edx, [eax]
    cmp edx, ebx
    jb .fail

    mov esi, [pbBinary]
    test ecx, ecx
    jz .write_null

.convert_loop:
    movzx eax, byte [esi]
    inc esi

    mov dl, al
    shr dl, SHIFT_NIBBLE
    add dl, '0'
    cmp dl, '9'
    jbe .high_ok
    add dl, HEX_A_OFFSET
.high_ok:
    mov byte [edi], dl
    inc edi

    mov dl, al
    and dl, MASK_NIBBLE
    add dl, '0'
    cmp dl, '9'
    jbe .low_ok
    add dl, HEX_A_OFFSET
.low_ok:
    mov byte [edi], dl
    inc edi

    dec ecx
    jz .write_null_no_space
    mov byte [edi], ' '
    inc edi
    jmp .convert_loop

.write_null_no_space:
    mov byte [edi], 0
    mov eax, [pcchString]
    lea ebx, [ebx - 1]
    mov [eax], ebx
    mov eax, 1
    jmp .done

.write_null:
    mov byte [edi], 0
    mov eax, [pcchString]
    mov dword [eax], 0
    mov eax, 1
    jmp .done

.return_req_size:
    mov [eax], ebx
    mov eax, 1
    jmp .done

.fail:
    mov eax, 0

.done:
    ret
endp

section '.idata' import data readable
    library msvcrt, 'MSVCRT.DLL', \
        kernel32, 'KERNEL32.DLL'
    import msvcrt, \
        printf, 'printf'
    import kernel32, \
        ExitProcess, 'ExitProcess'
