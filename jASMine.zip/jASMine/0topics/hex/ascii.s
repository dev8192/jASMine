format PE console
entry start

include 'win32a.inc'

CRYPT_STRING_HEXASCIIADDR = 0x0000000b

section '.data' data readable writeable
    ;pbBinary: times 128 db % - 1
    pbBinary: times 128 - 32 db % + 31
    cbBinary  = $ - pbBinary
    pszString  rb 1024
    pcchString dd 1024
    fmt1  db '%s', 0

section '.text' code readable executable
start:
    dwFlags = CRYPT_STRING_HEXASCIIADDR
    invoke CryptBinaryToString, pbBinary, cbBinary,\
        dwFlags, pszString, pcchString
    cinvoke printf, fmt1, pszString
    cinvoke exit, 0

section '.idata' import data readable
    library crypt32,                'crypt32.dll',\
            msvcrt,                 'msvcrt.dll'
    import  crypt32,\
            CryptBinaryToString,    'CryptBinaryToStringA'
    import  msvcrt,\
            exit,                   'exit',\
            printf,                 'printf'
