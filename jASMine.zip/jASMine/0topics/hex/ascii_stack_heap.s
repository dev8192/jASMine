format PE console
entry start
 
include 'win32a.inc'
 
CRYPT_STRING_HEXASCIIADDR equ 0x0000000B
 
section '.data' data readable writeable
    msg_stack db "--- Example 1: Stack Allocation ---", 10, 0
    msg_heap  db 10, "--- Example 2: Heap Allocation ---", 10, 0
 
    byte_array:
        repeat 96
            db 0x1f + %
        end repeat
    array_size = $ - byte_array
 
section '.text' code readable executable
example1:
    push    ebp
    mov     ebp, esp
    sub     esp, 4

    cinvoke printf, msg_stack
 
    lea     eax, [ebp-4]
    invoke  CryptBinaryToString, byte_array, array_size, CRYPT_STRING_HEXASCIIADDR, 0, eax
 
    mov     eax, [ebp-4]
    sub     esp, eax
    and     esp, -4
    mov     ecx, esp
 
    lea     eax, [ebp-4]
    invoke  CryptBinaryToString, byte_array, array_size, CRYPT_STRING_HEXASCIIADDR, ecx, eax
 
    cinvoke printf, ecx
 
    mov     esp, ebp
    pop     ebp
    ret

example2:
    push    ebp
    mov     ebp, esp
    sub     esp, 8

    cinvoke printf, msg_heap

    lea     eax, [ebp-4]
    invoke  CryptBinaryToString, byte_array, array_size, CRYPT_STRING_HEXASCIIADDR, 0, eax
 
    cinvoke malloc, [ebp-4]
    mov     [ebp-8], eax
 
    lea     eax, [ebp-4]
    invoke  CryptBinaryToString, byte_array, array_size, CRYPT_STRING_HEXASCIIADDR, [ebp-8], eax
 
    cinvoke printf, [ebp-8]
 
    cinvoke free, [ebp-8]
 
    mov     esp, ebp
    pop     ebp
    ret
 
start:
    call    example1
    call    example2
    cinvoke  exit, 0

section '.idata' import data readable
    library msvcrt,                 'msvcrt.dll',\
            crypt32,                'crypt32.dll'
    import  msvcrt,\
            exit,                   'exit',\
            printf,                 'printf',\
            malloc,                 'malloc',\
            free,                   'free'
    import  crypt32,\
            CryptBinaryToString,   'CryptBinaryToStringA'
