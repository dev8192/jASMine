format PE console
entry start

section '.text' code readable executable
start:
    ret
