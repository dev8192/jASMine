include 'compiler/header.x86.inc'
include 'util/introspection.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall op__r8__r8
    stdcall op__r32__r32
    stdcall op__r16__r16
    ret
endp

proc op__r8__r8
    cinvoke puts, '*** op__r8__r8 ***'
    jmp .intro_end
.intro1: mov al, al     ; 88 C0    (11)(00 0)(000)
.intro2: mov cl, al     ; 88 C1    (11)(00 0)(001)
.intro3: mov dl, al     ; 88 C2    (11)(00 0)(010)
.intro4: mov bl, al     ; 88 C3    (11)(00 0)(011)
.intro5: mov ah, al     ; 88 C4    (11)(00 0)(100)
.intro6: mov ch, al     ; 88 C5    (11)(00 0)(101)
.intro7: mov dh, al     ; 88 C6    (11)(00 0)(110)
.intro8: mov bh, al     ; 88 C7    (11)(00 0)(111)
.intro_end:
    introspect8
    ret
endp

proc op__r32__r32
    cinvoke puts, '*** op__r32__r32 ***'
    jmp .intro_end
.intro1: mov eax, eax     ; 89 C0    (11)(00 0)(000)
.intro2: mov ecx, eax     ; 89 C1    (11)(00 0)(001)
.intro3: mov edx, eax     ; 89 C2    (11)(00 0)(010)
.intro4: mov ebx, eax     ; 89 C3    (11)(00 0)(011)
.intro5: mov esp, eax     ; 89 C4    (11)(00 0)(100)
.intro6: mov ebp, eax     ; 89 C5    (11)(00 0)(101)
.intro7: mov esi, eax     ; 89 C6    (11)(00 0)(110)
.intro8: mov edi, eax     ; 89 C7    (11)(00 0)(111)
.intro_end:
    introspect8
    ret
endp

proc op__r16__r16
    cinvoke puts, '*** op__r16__r16 ***'
    jmp .intro_end
.intro1: mov ax, ax     ; 66 89 C0    (11)(00 0)(000)
.intro2: mov cx, ax     ; 66 89 C1    (11)(00 0)(001)
.intro3: mov dx, ax     ; 66 89 C2    (11)(00 0)(010)
.intro4: mov bx, ax     ; 66 89 C3    (11)(00 0)(011)
.intro5: mov sp, ax     ; 66 89 C4    (11)(00 0)(100)
.intro6: mov bp, ax     ; 66 89 C5    (11)(00 0)(101)
.intro7: mov si, ax     ; 66 89 C6    (11)(00 0)(110)
.intro8: mov di, ax     ; 66 89 C7    (11)(00 0)(111)
.intro_end:
    introspect8
    ret
endp

include 'compiler/footer.inc'
