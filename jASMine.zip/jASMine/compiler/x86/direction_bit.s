include 'compiler/header.x86.inc'
include 'util/introspection.text.inc'

; opcode dst, src
; when the second-to-last bit of opcode is 0, dst is stored in r/m
; when the second-to-last bit of opcode is 1, src is stored in r/m

; d | reg | r/m
; 0 | src | dst
; 1 | dst | src

proc main
    cinvoke puts, '*** main1 ***'
    stdcall test_instr      ; 84      1000 0100
    stdcall xchg_instr      ; 86      1000 0110
    stdcall mov_instr       ; 88      1000 1000
    stdcall mov_instr2      ; 8A      1000 1010
    ret
endp

proc test_instr
    cinvoke puts, '*** test_instr ***'
    jmp .intro_end
.intro1: test al, al      ; 84 C0    (11)(00 0)(000)
.intro2: test cl, al      ; 84 C1    (11)(00 0)(001)
.intro3: test dl, al      ; 84 C2    (11)(00 0)(010)
.intro4: test bl, al      ; 84 C3    (11)(00 0)(011)
.intro5: test ah, al      ; 84 C4    (11)(00 0)(100)
.intro6: test ch, al      ; 84 C5    (11)(00 0)(101)
.intro7: test dh, al      ; 84 C6    (11)(00 0)(110)
.intro8: test bh, al      ; 84 C7    (11)(00 0)(111)
.intro_end:
    introspect8
    ret
endp

proc xchg_instr
    cinvoke puts, '*** xchg_instr ***'
    jmp .intro_end
.intro1: xchg al, al      ; 86 C0    (11)(00 0)(000)
.intro2: xchg al, cl      ; 86 C1    (11)(00 0)(001)
.intro3: xchg al, dl      ; 86 C2    (11)(00 0)(010)
.intro4: xchg al, bl      ; 86 C3    (11)(00 0)(011)
.intro5: xchg al, ah      ; 86 C4    (11)(00 0)(100)
.intro6: xchg al, ch      ; 86 C5    (11)(00 0)(101)
.intro7: xchg al, dh      ; 86 C6    (11)(00 0)(110)
.intro8: xchg al, bh      ; 86 C7    (11)(00 0)(111)
.intro_end:
    introspect8
    ret
endp

proc mov_instr
    cinvoke puts, '*** mov_instr ***'
    jmp .intro_end
.intro1: mov al, al     ; 88 C0    (11)(00 0)(000)
.intro2: mov cl, al     ; 88 C1    (11)(00 0)(001)
.intro3: mov dl, al     ; 88 C2    (11)(00 0)(010)
.intro4: mov bl, al     ; 88 C3    (11)(00 0)(011)
.intro5: mov ah, al     ; 88 C4    (11)(00 0)(100)
.intro6: mov ch, al     ; 88 C5    (11)(00 0)(101)
.intro7: mov dh, al     ; 88 C6    (11)(00 0)(110)
.intro8: mov bh, al     ; 88 C7    (11)(00 0)(111)
.intro_end:
    introspect8
    ret
endp

proc mov_instr2
    cinvoke puts, '*** mov_instr2 ***'
    jmp .intro_end   ; fasm                      alternative
.intro1: mov al, al ; 88 C0 (11)(00 0)(000)     8A C0 (11)(00 0)(000)
.intro2: mov al, cl ; 88 C8 (11)(00 1)(000)     8A C1 (11)(00 0)(001)
.intro3: mov al, dl ; 88 D0 (11)(01 0)(000)     8A C2 (11)(00 0)(010)
.intro4: mov al, bl ; 88 D8 (11)(01 1)(000)     8A C3 (11)(00 0)(011)
.intro5: mov al, ah ; 88 E0 (11)(10 0)(000)     8A C4 (11)(00 0)(100)
.intro6: mov al, ch ; 88 E8 (11)(10 1)(000)     8A C5 (11)(00 0)(101)
.intro7: mov al, dh ; 88 F0 (11)(11 0)(000)     8A C6 (11)(00 0)(110)
.intro8: mov al, bh ; 88 F8 (11)(11 1)(000)     8A C7 (11)(00 0)(111)
.intro_end:
    introspect8
    ret
endp

include 'compiler/footer.inc'
