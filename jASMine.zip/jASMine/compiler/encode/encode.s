include 'boilerplate/header.x86.inc'
include 'util/print_bytes.text.inc'
include 'util/introspect.text.inc'



; 8B 04 8B
; 1000 1011  0000 0100  1000 1011
; 1000 1011  00 000 100  10 001 011
proc main1
    cinvoke puts, '*** main1 ***'
    jmp .introspection_end
.introspection_start:
   ;lea eax, [eax]      ; 8D 00
   ;lea ebx, [ebp]      ; 8D 5D 00
    mov eax, [ebx + ecx * 4]    ; 8B 04 8B
.introspection_end:
    stdcall introspect, .introspection_start, .introspection_end
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    jmp .introspection7
.introspection1:
    lea eax, [ebx + 0x10]                   ; 8D 43 10
.introspection2:                            ; 10 001 100  10 111 110
    lea ecx, [esi + edi * 4 + 0x12345678]   ; 8D 8C BE 78 56 34 12
   ; 10 000 100  10 001 101
   ;lea eax, [ebp + ecx * 4 + 0x12345678]   ; 8D 84 8D 78 56 34 12
.introspection3:    ; 10 000 101
    lea edx, [0x11223344]                   ; 8D 15 44 33 22 11
.introspection4:
    lea ebx, [ebp]                          ; 8D 5D 00
.introspection5:
    lea eax, [eax * 8]                      ; 8D 04 C5 00 00 00 00
.introspection6:
    lea edi, [esp + 8]                      ; 8D 7C 24 08
.introspection7:
    stdcall introspect, .introspection1, .introspection2
    stdcall introspect, .introspection2, .introspection3
    stdcall introspect, .introspection3, .introspection4
    stdcall introspect, .introspection4, .introspection5
    stdcall introspect, .introspection5, .introspection6
    stdcall introspect, .introspection6, .introspection7
    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    jmp .introspection4
.introspection1:
    lea ecx, [esi + edi * 4 + 0x12345678]   ; 8D 8C BE 78 56 34 12
.introspection2:
   ;mov ecx, [esi + edi * 4 + 0x12345678]   ; 8B 8C BE 78 56 34 12
    mov [esi + edi * 4 + 0x12345678], ecx   ; 89 8C BE 78 56 34 12
.introspection3:
    add ecx, [esi + edi * 4 + 0x12345678]   ; 03 8C BE 78 56 34 12
   ;add [esi + edi * 4 + 0x12345678], ecx   ; 01 8C BE 78 56 34 12
.introspection4:
    stdcall introspect, .introspection1, .introspection2
    stdcall introspect, .introspection2, .introspection3
    stdcall introspect, .introspection3, .introspection4
    ret
endp

proc main4
    cinvoke puts, '*** main4 ***'
    jmp .introspection_end
.introspection1:
    mov eax, [eax]      ; 8B 00 
.introspection2:
    mov eax, [ecx]      ; 8B 01 
.introspection3:
    mov eax, [edx]      ; 8B 02 
.introspection4:
    mov eax, [ebx]      ; 8B 03 
.introspection5:        ; 00 000 100  00 100 100
    mov eax, [esp]      ; 8B 04 24 
.introspection6:        ; 01 000 101
    mov eax, [ebp]      ; 8B 45 00 
.introspection7:
    mov eax, [esi]      ; 8B 06 
.introspection8:
    mov eax, [edi]      ; 8B 07 
.introspection_end:
    stdcall introspect, .introspection1, .introspection2
    stdcall introspect, .introspection2, .introspection3
    stdcall introspect, .introspection3, .introspection4
    stdcall introspect, .introspection4, .introspection5
    stdcall introspect, .introspection5, .introspection6
    stdcall introspect, .introspection6, .introspection7
    stdcall introspect, .introspection7, .introspection8
    stdcall introspect, .introspection8, .introspection_end
    ret
endp

proc main5
    cinvoke puts, '*** main5 ***'
    jmp .introspection_end
.introspection1:            ; 00 000 100  00 100 100
    mov eax, [esp]          ; 8B 04 24 
.introspection2:            ; 01 000 100  00 101 101
    mov eax, [ebp + ebp]    ; 8B 44 2D 00
.introspection_end:
    stdcall introspect, .introspection1, .introspection2
    stdcall introspect, .introspection2, .introspection_end
    ret
endp

proc main6
    cinvoke puts, '*** main6 ***'
    jmp .introspection_end
.introspection1:    ; 11 000 001
    test ecx, 5     ; F7 C1 05 00 00 00
.introspection2:    ; 11 011 001
    neg ecx         ; F7 D9
.introspection3:                        ; 01 011 100  11 001 000
    neg dword [eax + ecx * 8 + 0x12]    ; F7 5C C8 12 
.introspection4:                        ; 10 011 100  11 001 000
    neg dword [eax + ecx * 8 + 0x1234]  ; F7 9C C8 34 12 00 00 
.introspection_end:
    stdcall introspect, .introspection1, .introspection2
    stdcall introspect, .introspection2, .introspection3
    stdcall introspect, .introspection3, .introspection4
    stdcall introspect, .introspection4, .introspection_end
    ret
endp

proc main
    cinvoke puts, '*** main7 ***'
    jmp .introspection_end
.introspection1:
    neg dword [eax + eax * 8 + 0x12]    ; F7 5C C0 12
.introspection2:
    neg dword [ecx + eax * 8 + 0x12]    ; F7 5C C1 12
.introspection3:
    neg dword [edx + eax * 8 + 0x12]    ; F7 5C C2 12
.introspection4:
    neg dword [ebx + eax * 8 + 0x12]    ; F7 5C C3 12
.introspection5:
    neg dword [esp + eax * 8 + 0x12]    ; F7 5C C4 12
.introspection6:
    neg dword [ebp + eax * 8 + 0x12]    ; F7 5C C5 12
.introspection7:
    neg dword [esi + eax * 8 + 0x12]    ; F7 5C C6 12
.introspection8:
    neg dword [edi + eax * 8 + 0x12]    ; F7 5C C7 12
.introspection_end:    
    stdcall introspect, .introspection1, .introspection2
    stdcall introspect, .introspection2, .introspection3
    stdcall introspect, .introspection3, .introspection4
    stdcall introspect, .introspection4, .introspection5
    stdcall introspect, .introspection5, .introspection6
    stdcall introspect, .introspection6, .introspection7
    stdcall introspect, .introspection7, .introspection8
    stdcall introspect, .introspection8, .introspection_end
    ret
endp

proc main9
    cinvoke puts, '*** main9 ***'
    local buf[16]:BYTE
    invoke encode_lea, addr buf, REG_EAX, SCALE_1, REG_NONE, REG_EBX, 0x10
   ;invoke encode_lea, addr buf, REG_ECX, SCALE_4, REG_EDI, REG_ESI, 0x12345678
   ;invoke encode_lea, addr buf, REG_EDX, SCALE_1, REG_NONE, REG_NONE, 0x11223344
   ;invoke encode_lea, addr buf, REG_EBX, SCALE_1, REG_NONE, REG_EBP, 0
   ;invoke encode_lea, addr buf, REG_EAX, SCALE_8, REG_EAX, REG_NONE, 0
   ;invoke encode_lea, addr buf, REG_EDI, SCALE_1, REG_NONE, REG_ESP, 8
    stdcall print_bytes, addr buf, eax
    ret
endp

include 'boilerplate/footer.inc'
