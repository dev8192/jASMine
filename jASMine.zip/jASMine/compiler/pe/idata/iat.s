format PE
entry start

include 'win32a.inc'

section '.data' data readable writeable
    fmt3        db '%08x %08x %08x', 10, 0
    fmt_hex     db '%x', 10, 0

    mod_msvcrt    db 'msvcrt.dll', 0
    func_printf   db 'printf', 0

    mod_kernel32    db 'kernel32.dll', 0
    func_ExitProcess   db 'ExitProcess', 0

section '.text' code readable executable
start:
    stdcall test10

    stdcall print_info, printf
    stdcall print_info2, mod_msvcrt, func_printf

    stdcall print_info, ExitProcess
    stdcall print_info2, mod_kernel32, func_ExitProcess
    
    invoke ExitProcess, 0

proc test10 uses ebx
    cinvoke printf, fmt_hex, printf
    lea eax, [printf]
    cinvoke printf, fmt_hex, eax

    cinvoke printf, fmt_hex, [printf]
    mov ebx, [printf]
    cinvoke printf, fmt_hex, ebx

    cinvoke printf, fmt_hex, [ebx]
    ret
endp

proc print_info uses ebx esi edi, func_addr
    mov ebx, [func_addr]
    mov esi, [ebx]
    mov edi, [esi]
    cinvoke printf, fmt3, ebx, esi, edi
    ret
endp

proc print_info2 uses esi edi, mod_name, func_name
    invoke GetModuleHandle, [mod_name]
    invoke GetProcAddress, eax, [func_name]
    mov esi, eax
    mov edi, [esi]    
    cinvoke printf, fmt3, 0, esi, edi
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            GetProcAddress,     'GetProcAddress',\
            ExitProcess,        'ExitProcess'
    import  msvcrt,\
            printf,             'printf'
