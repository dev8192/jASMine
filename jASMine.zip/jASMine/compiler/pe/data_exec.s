format PE console
entry start

include 'win32ax.inc'
    
section '.data' data readable writeable
    num1    dd 0xAA
    num2    dd 0xBB
    fmt_x   db '%x', 10, 0

label1:
    cinvoke printf, fmt_x, [num1]
    jmp label2

section '.text' code readable executable
start:
    stdcall main
    invoke  ExitProcess, 0

proc main
    cinvoke puts, '*** main1 ***'
    mov dword [label1 + 2], num2
    jmp label1
label2:
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
