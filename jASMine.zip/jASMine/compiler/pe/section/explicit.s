; working!

format PE CONSOLE 4.0
entry start

include 'win32a.inc'

section '.code' code readable executable
  start:
    ; 1. Get the Handle for the console output (Standard Output)
    invoke GetStdHandle, STD_OUTPUT_HANDLE
    mov [stdout], eax

    ; 2. Write the string to the console
    ; WriteFile(handle, buffer, bytes_to_write, bytes_written_ptr, overlapped)
    invoke WriteFile, [stdout], msg, msg_len, written, 0

    ; 3. Exit
    invoke ExitProcess, 0

section '.data' data readable writeable
    msg      db 'Hello from pure Assembly!', 13, 10 ; 13, 10 is CRLF (newline)
    msg_len  = $ - msg                              ; Calculate string length automatically
    stdout   dd ?
    written  dd ?

section '.idata' import data readable
    library kernel32, 'kernel32.dll'

    import kernel32, \
           GetStdHandle, 'GetStdHandle', \
           WriteFile, 'WriteFile', \
           ExitProcess, 'ExitProcess'
