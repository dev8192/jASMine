format PE console
entry start

include 'win32a.inc'

section '.data' data readable writeable
    buf db 200000 dup (0)

section '.code' code readable executable
start:
    invoke ExitProcess, 0

section '.idata' import data readable writeable
    library kernel32, 'kernel32.dll'
    import kernel32, ExitProcess, 'ExitProcess'
