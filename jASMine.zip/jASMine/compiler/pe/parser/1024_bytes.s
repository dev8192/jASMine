format PE

push fmt
call [printf]
add esp, 4
push 0
call [ExitProcess]

fmt     db 'abc123', 10, 0

data import
    dd 0, 0, 0, rva kernel_name, rva kernel_table
    dd 0, 0, 0, rva msvcrt_name, rva msvcrt_table
    dd 0, 0, 0, 0, 0

    kernel_name db 'kernel32.dll', 0
    msvcrt_name db 'msvcrt.dll', 0

    kernel_table:
        ExitProcess dd rva _ExitProcess
        dd 0

    _ExitProcess dw 0
        db 'ExitProcess', 0

    msvcrt_table:
        printf dd rva _printf
        dd 0

    _printf dw 0
        db 'printf', 0
end data
