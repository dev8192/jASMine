format PE CONSOLE 4.0
entry start

include 'win32a.inc'

GENERIC_READ           equ 0x80000000
FILE_SHARE_READ        equ 1
OPEN_EXISTING          equ 3
FILE_ATTRIBUTE_NORMAL  equ 0x80
PAGE_READONLY          equ 2
FILE_MAP_READ          equ 4
INVALID_HANDLE_VALUE   equ -1
MAX_PATH               equ 260

IMAGE_DOS_SIGNATURE    equ 0x5A4D
IMAGE_NT_SIGNATURE     equ 0x00004550

struct IMAGE_DOS_HEADER
    e_magic  dw ?
    rb 58
    e_lfanew dd ?
ends

struct IMAGE_FILE_HEADER
    Machine              dw ?
    NumberOfSections     dw ?
    TimeDateStamp        dd ?
    PointerToSymbolTable dd ?
    NumberOfSymbols      dd ?
    SizeOfOptionalHeader dw ?
    Characteristics      dw ?
ends

struct IMAGE_OPTIONAL_HEADER32
    Magic                   dw ?
    MajorLinkerVersion      db ?
    MinorLinkerVersion      db ?
    SizeOfCode              dd ?
    SizeOfInitializedData   dd ?
    SizeOfUninitializedData dd ?
    AddressOfEntryPoint     dd ?
    BaseOfCode              dd ?
    BaseOfData              dd ?
    ImageBase               dd ?
    rb 68
ends

struct IMAGE_NT_HEADERS32
    Signature      dd ?
    FileHeader     IMAGE_FILE_HEADER
    OptionalHeader IMAGE_OPTIONAL_HEADER32
ends

struct IMAGE_SECTION_HEADER
    Name                 rb 8
    VirtualSize          dd ?
    VirtualAddress       dd ?
    SizeOfRawData        dd ?
    PointerToRawData     dd ?
    PointerToRelocations dd ?
    PointerToLinenumbers dd ?
    NumberOfRelocations  dw ?
    NumberOfLinenumbers  dw ?
    Characteristics      dd ?
ends

section '.data' data readable writeable
    path         rb MAX_PATH
    hFile        dd ?
    hMap         dd ?
    pBase        dd ?

    fmt_dos      db 'DOS Header Magic: %04X', 10, 0
    fmt_nt       db 'NT Signature: %08X', 10, 0
    fmt_file     db 'Machine: %04X, Sections: %d', 10, 0
    fmt_opt      db 'Entry Point: %08X, Image Base: %08X', 10, 0
    fmt_sec_hdr  db 10, 'Sections:', 10, 0
    fmt_sec      db '  Name: %.8s, VAddr: %08X, RawSize: %08X', 10, 0
    fmt_err      db 'Error or invalid PE file.', 10, 0

section '.text' code readable executable
start:
    invoke ParseFile
    invoke ExitProcess, 0

proc ParseFile
    invoke GetModuleFileName, NULL, path, MAX_PATH
    
    invoke CreateFile, path, GENERIC_READ, FILE_SHARE_READ, \
           NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL
    cmp eax, INVALID_HANDLE_VALUE
    je .error
    mov [hFile], eax

    invoke CreateFileMapping, [hFile], NULL, PAGE_READONLY, 0, 0, NULL
    test eax, eax
    jz .cleanup_file
    mov [hMap], eax

    invoke MapViewOfFile, [hMap], FILE_MAP_READ, 0, 0, 0
    test eax, eax
    jz .cleanup_map
    mov [pBase], eax

    mov esi, eax
    cmp word [esi + IMAGE_DOS_HEADER.e_magic], IMAGE_DOS_SIGNATURE
    jne .cleanup_view

    movzx eax, word [esi + IMAGE_DOS_HEADER.e_magic]
    cinvoke printf, fmt_dos, eax

    mov ebx, [esi + IMAGE_DOS_HEADER.e_lfanew]
    add ebx, esi

    cmp dword [ebx + IMAGE_NT_HEADERS32.Signature], IMAGE_NT_SIGNATURE
    jne .cleanup_view

    cinvoke printf, fmt_nt, dword [ebx + IMAGE_NT_HEADERS32.Signature]

    movzx eax, word [ebx + IMAGE_NT_HEADERS32.FileHeader.NumberOfSections]
    movzx ecx, word [ebx + IMAGE_NT_HEADERS32.FileHeader.Machine]
    cinvoke printf, fmt_file, ecx, eax

    cinvoke printf, fmt_opt, \
            dword [ebx + IMAGE_NT_HEADERS32.OptionalHeader.AddressOfEntryPoint], \
            dword [ebx + IMAGE_NT_HEADERS32.OptionalHeader.ImageBase]

    cinvoke printf, fmt_sec_hdr

    movzx eax, word [ebx + IMAGE_NT_HEADERS32.FileHeader.SizeOfOptionalHeader]
    lea edi, [ebx + eax + 24]

    movzx ecx, word [ebx + IMAGE_NT_HEADERS32.FileHeader.NumberOfSections]
    test ecx, ecx
    jz .cleanup_view

.print_sections:
    push ecx
    cinvoke printf, fmt_sec, edi, \
            dword [edi + IMAGE_SECTION_HEADER.VirtualAddress], \
            dword [edi + IMAGE_SECTION_HEADER.SizeOfRawData]
    add edi, sizeof.IMAGE_SECTION_HEADER
    pop ecx
    dec ecx
    jnz .print_sections

    jmp .cleanup_view

.error:
    cinvoke printf, fmt_err
    jmp .exit

.cleanup_view:
    invoke UnmapViewOfFile, [pBase]
.cleanup_map:
    invoke CloseHandle, [hMap]
.cleanup_file:
    invoke CloseHandle, [hFile]
.exit:
    ret
endp

section '.idata' import data readable writeable
    library kernel32, 'KERNEL32.DLL', \
            msvcrt, 'MSVCRT.DLL'

    import kernel32, \
        CloseHandle, 'CloseHandle', \
        CreateFile, 'CreateFileA', \
        CreateFileMapping, 'CreateFileMappingA', \
        ExitProcess, 'ExitProcess', \
        GetModuleFileName, 'GetModuleFileNameA', \
        MapViewOfFile, 'MapViewOfFile', \
        UnmapViewOfFile, 'UnmapViewOfFile'

    import msvcrt, \
        printf, 'printf'
