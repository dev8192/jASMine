format binary as 'exe'

; =============================================================================
; IMAGE_DOS_HEADER (64 bytes)
; =============================================================================
db 'MZ'                         ; e_magic
dw 0                            ; e_cblp (ignored)

; --- OVERLAP ZONE 1: Data Strings stored in unused DOS header fields ---
szFormat db 'hello', 10, 0      ; "hello\n" string stored in DOS space
szDll    db 'msvcrt.dll', 0     ; DLL name string stored in DOS space

times 0x3C-$ db 0               ; Pad out to the e_lfanew pointer
dd pe_header                    ; e_lfanew points directly to the NT Header

; =============================================================================
; IMAGE_NT_HEADERS / IMAGE_FILE_HEADER (4 + 20 bytes)
; =============================================================================
pe_header:
db 'PE',0,0                     ; Machine signature
dw 0x014C                       ; Machine: IMAGE_FILE_MACHINE_I386 (32-bit x86)
dw 0                            ; NumberOfSections = 0 (Sectionless Executable)
dd 0                            ; TimeDateStamp (ignored)
dd 0                            ; PointerToSymbolTable (ignored)
dd 0                            ; NumberOfSymbols (ignored)
dw optional_header_size         ; SizeOfOptionalHeader
dw 0x0102                       ; Characteristics: EXECUTABLE_IMAGE | 32BIT_MACHINE

; =============================================================================
; IMAGE_OPTIONAL_HEADER32 (224 bytes)
; =============================================================================
optional_header:
dw 0x010B                       ; Magic: PE32 (32-bit)
db 0, 0                         ; Major/Minor Linker Version (OVERWRITTEN / IGNORED)
dd 0                            ; SizeOfCode
dd 0                            ; SizeOfInitializedData
dd 0                            ; SizeOfUninitializedData
dd entry_point                  ; AddressOfEntryPoint (RVA)
dd entry_point                  ; BaseOfCode (Pointed safely to code entry)

; --- OVERLAP ZONE 2: Overlapping ImageBase ---
; We map the ImageBase to a standard fixed user-mode memory address block.
image_base = 0x00400000
dd image_base                   ; ImageBase = 0x00400000

dd 0x00001000                   ; SectionAlignment (Must be 4KB page size)
dd 0x00000200                   ; FileAlignment (Must be 512 or matching header rules)
dw 4, 0                         ; Major/Minor Operating System Version
dw 0, 0                         ; Major/Minor Image Version
dw 4, 0                         ; Major/Minor Subsystem Version
dd 0                            ; Win32VersionValue (ignored)
dd 268                          ; SizeOfImage (Explicitly set to the exact total binary file size)
dd pe_header                    ; SizeOfHeaders (Points to start of headers)
dd 0                            ; Checksum (ignored)

; --- OVERLAP ZONE 3: Subsystem Hijack ---
dw 2                            ; Subsystem: IMAGE_SUBSYSTEM_WINDOWS_GUI (Allows compact execution)
dw 0                            ; DllCharacteristics

dd 0x00100000                   ; SizeOfStackReserve
dd 0x00001000                   ; SizeOfStackCommit
dd 0x00100000                   ; SizeOfHeapReserve
dd 0x00001000                   ; SizeOfHeapCommit
dd 0                    	    ; LoaderFlags

; --- DATA DIRECTORIES ARRAY ---
dd 2                            ; NumberOfDataDirectories (We only supply Export and Import slots)
dd 0, 0                         ; DataDirectory[0]: Export Directory (Null)
dd import_directory, import_dir_size ; DataDirectory[1]: Import Directory (Points to our custom entry)

optional_header_size = $ - optional_header

; =============================================================================
; MANUALLY BUILT IMPORT DIRECTORY TABLE (IDT)
; =============================================================================
import_directory:
dd 0                            ; OriginalFirstThunk = 0 (Skipped to save 4 bytes!)
dd 0                            ; TimeDateStamp
dd 0                            ; ForwarderChain
dd szDll                        ; Name RVA -> Points to "msvcrt.dll" string up in DOS header
dd iat_start                    ; FirstThunk RVA -> Points to our raw IAT array
import_dir_size = $ - import_directory

; Null Descriptor (Required terminator so the loader doesn't read into your code)
dd 0, 0, 0, 0, 0

; =============================================================================
; IMPORT ADDRESS TABLE (IAT) & CODE EXEcUTION SPACE
; =============================================================================
iat_start:
_printf dd printf_name          ; Initially points to name; overwritten by loader with live address
_exit   dd exit_name            ; Initially points to name; overwritten by loader with live address
dd 0                            ; IAT Null Terminator

; --- RAW FUNCTION STRINGS (With embedded 2-byte hints filled with zero) ---
align 2
printf_name: dw 0
             db 'printf', 0
align 2
exit_name:   dw 0
             db 'exit', 0

; =============================================================================
; THE APPLICATION CODE INTERNALS
; =============================================================================
entry_point:
    ; Push the format string address onto the stack (VA = ImageBase + String Offset)
    push szFormat
    call [_printf]
    add esp, 4                  ; Clean up cdecl call stack

    ; Call exit(0) to terminate cleanly without throwing a loader exception
    push 0
    call [_exit]
