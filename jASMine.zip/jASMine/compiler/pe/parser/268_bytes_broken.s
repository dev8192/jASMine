format binary as 'exe'

; IMAGE_DOS_HEADER (64 bytes)
db 'MZ'                         ; e_magic
dw 0                            ; e_cblp

szFormat db 'hello', 10, 0
szDll    db 'msvcrt.dll', 0

times 0x3C-$ db 0               ; Pad out to the e_lfanew pointer
dd pe_header                    ; e_lfanew points directly to the NT Header

entry_point:
    push szFormat
    call [_printf]
    add esp, 4
    push 0
    call [_exit]

; IMAGE_NT_HEADERS / IMAGE_FILE_HEADER (4 + 20 bytes)
pe_header:
db 'PE',0,0                     ; Machine signature
dw 0x014C                       ; Machine: IMAGE_FILE_MACHINE_I386 (32-bit x86)
dw 0                            ; NumberOfSections = 0 (Sectionless Executable)
dd 0                            ; TimeDateStamp
dd 0                            ; PointerToSymbolTable
dd 0                            ; NumberOfSymbols
dw optional_header_size         ; SizeOfOptionalHeader
dw 0x0102                       ; Characteristics: EXECUTABLE_IMAGE | 32BIT_MACHINE

; IMAGE_OPTIONAL_HEADER32 (224 bytes)
optional_header:
dw 0x010B                       ; Magic: PE32 (32-bit)
db 0, 0                         ; Major/Minor Linker Version
dd 0                            ; SizeOfCode
dd 0                            ; SizeOfInitializedData
dd 0                            ; SizeOfUninitializedData
dd entry_point                  ; AddressOfEntryPoint (RVA)
dd entry_point                  ; BaseOfCode

dd 0x00400000                   ; ImageBase = 0x00400000

;dd 0x00001000                  ; SectionAlignment
dd 4                            ; SectionAlignment
dd 4                            ; FileAlignment
dw 4, 0                         ; Major/Minor Operating System Version
dw 0, 0                         ; Major/Minor Image Version
dw 4, 0                         ; Major/Minor Subsystem Version
dd 0                            ; Win32VersionValue
dd 268                          ; SizeOfImage
dd pe_header                    ; SizeOfHeaders
dd 0                            ; Checksum

dw 2                            ; Subsystem: IMAGE_SUBSYSTEM_WINDOWS_GUI (Allows compact execution)
dw 0                            ; DllCharacteristics

dd 0x00100000                   ; SizeOfStackReserve
dd 0x00001000                   ; SizeOfStackCommit
dd 0x00100000                   ; SizeOfHeapReserve
dd 0x00001000                   ; SizeOfHeapCommit
dd 0                    	    ; LoaderFlags
dd 2                            ; NumberOfDataDirectories
dd 0, 0                         ; DataDirectory[0]: Export Directory
dd import_directory, import_dir_size ; DataDirectory[1]: Import Directory

optional_header_size = $ - optional_header

; IMPORT DIRECTORY TABLE (IDT)
import_directory:
dd 0                            ; OriginalFirstThunk = 0 (Skipped to save 4 bytes!)
dd 0                            ; TimeDateStamp
dd 0                            ; ForwarderChain
dd szDll                        ; Name RVA -> Points to "msvcrt.dll" string up in DOS header
dd iat_start                    ; FirstThunk RVA -> Points to our raw IAT array
import_dir_size = $ - import_directory
dd 0, 0, 0, 0, 0                ; Null Descriptor

; IMPORT ADDRESS TABLE (IAT) & CODE EXEcUTION SPACE
iat_start:
_printf dd printf_name
_exit   dd exit_name
dd 0                            ; IAT Null Terminator

align 2
printf_name: dw 0
             db 'printf', 0
align 2
exit_name:   dw 0
             db 'exit', 0


;times 268-$ db 0
;times 10 db 0
