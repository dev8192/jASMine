format binary as 'exe'

; IMAGE_DOS_HEADER (64 bytes)
mz_header:
    dw 0x5A4D               ; e_magic: 'MZ'
    times 29 dw 0           ; Zero padding for standard DOS fields
    dd 0x00000040           ; e_lfanew: Tells OS loader that the PE header starts at 0x40

; IMAGE_NT_HEADERS32
pe_signature:
    dd 0x00004550           ; PE signature: 'PE\0\0'

; IMAGE_FILE_HEADER (20 bytes)
coff_header:
    dw 0x014C               ; Machine: Intel 386 (32-bit x86)
    dw 0                    ; NumberOfSections: 0 (No sections needed!)
    dd 0                    ; TimeDateStamp
    dd 0                    ; PointerToSymbolTable
    dd 0                    ; NumberOfSymbols
    dw 224                  ; SizeOfOptionalHeader: Exact size for a 32-bit header
    dw 0x0102               ; Characteristics: 32BIT_MACHINE | EXECUTABLE_IMAGE

; IMAGE_OPTIONAL_HEADER32 (224 bytes)
optional_header:
    dw 0x010B               ; Magic: PE32 (32-bit)
    db 0, 0                 ; Major/MinorLinkerVersion
    dd 0                    ; SizeOfCode
    dd 0                    ; SizeOfInitializedData
    dd 0                    ; SizeOfUninitializedData
    dd entry_point          ; AddressOfEntryPoint: Points directly to code in header!
    dd 0                    ; BaseOfCode
    dd 0                    ; BaseOfData

    ; Windows-Specific Fields
    dd 0x00400000           ; ImageBase
    dd 0x00001000           ; SectionAlignment: MUST be 4KB (0x1000) for modern Windows
    dd 0x00000004           ; FileAlignment: Low alignment mode (4-byte disk step)
    dw 0, 0                 ; Major/MinorOperatingSystemVersion
    dw 0, 0                 ; Major/MinorImageVersion
    dw 4, 0                 ; Major/MinorSubsystemVersion (4.0)
    dd 0                    ; Win32VersionValue
    dd 252                  ; SizeOfImage: Total loaded size in memory
    dd 64 + 4 + 20 + 224    ; SizeOfHeaders: Matches file size exactly (252 bytes)
    dd 0                    ; CheckSum
    dw 0x0003               ; Subsystem: WINDOWS_CUI (Console)
    dw 0                    ; DllCharacteristics
    dd 0, 0                 ; SizeOfStackReserve, SizeOfStackCommit
    dd 0, 0                 ; SizeOfHeapReserve, SizeOfHeapCommit
    dd 0                    ; LoaderFlags
    dd 0                    ; NumberOfRvaAndSizes (0 = No Data Directories array)

; 32-BIT CODE INJECTION (Executing right where the header structure ends)
entry_point = $ - mz_header
    xor eax, eax            ; Clear EAX
    inc eax                 ; EAX = 1 (sys_exit opcode equivalent/cleanup layout depends on environment)
    ret                     ; Pop the return address off the stack to exit cleanly

; Force physical file alignment termination to exactly 252 bytes
times 252 - ($ - mz_header) db 0
