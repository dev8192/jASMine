include 'boilerplate/header.x86.inc'
include 'ast/ast.inc'
include 'ast/ast.text.inc'

MAX_STRING_LENGTH = 256
MAX_BUFFER_SIZE = 2048

proc main uses ebx
    cinvoke puts, '*** main0 ***'
    stdcall create_literal_node, 123
    mov ebx, eax
    test eax, eax
    jnz .print_value
    cinvoke puts, ast__data.err_cannot_create_node
    jmp .finish
.print_value:
    stdcall print_ast_node, ebx
    stdcall ast_literal__print, ebx
    stdcall print_ast_node_type, ebx
    cinvoke printf, fmt_d, dword [ebx + AST_LITERAL.value]
    cinvoke free, ebx
.finish:
    ret
endp

proc main1
    cinvoke puts, '*** main1 ***'
    local root_node:DWORD

    mov dword [global_parser.source_pointer], string_input_call
    stdcall advance_parser_token
    stdcall parse_binary_expression
    mov [root_node], eax
    stdcall codegen_and_print, [root_node]

    stdcall create_literal_node, 10
    test eax, eax
    jnz .add_argument
    cinvoke puts, 'err'
    jmp .finish
.add_argument:
    stdcall call_expr__add_arg, [root_node], eax
    stdcall codegen_and_print, [root_node]
.finish:
    ret
endp

proc main2
    cinvoke puts, '*** main2 ***'
    local root_node:DWORD

    mov dword [global_parser.source_pointer], string_input_math
    stdcall advance_parser_token
    stdcall parse_binary_expression
    mov [root_node], eax
    stdcall codegen_and_print, [root_node]

    stdcall transform_rename_variable, [root_node], string_var1, string_var5
    stdcall codegen_and_print, [root_node]

    ret
endp

proc main3
    cinvoke puts, '*** main3 ***'
    local root_node:DWORD
    mov dword [global_parser.source_pointer], string_input_math_two
    stdcall advance_parser_token
    stdcall parse_binary_expression
    mov [root_node], eax
    stdcall codegen_and_print, [root_node]
    
    lea eax, [root_node]
    stdcall transform_replace_node, eax, string_var1
    stdcall codegen_and_print, [root_node]
    ret
endp

; print_numbers(5, 10, 15)
proc main10
    cinvoke puts, '*** main10 ***'
    local callee_node:DWORD
    local array_pointer:DWORD
    local literal_node:DWORD
    local root_node:DWORD
    mov [root_node], 0
    stdcall create_identifier_node, string_print_numbers
    test eax, eax
    jz .error_allocation
    mov [callee_node], eax
    cinvoke malloc, 12
    test eax, eax
    jz .error_allocation
    mov [array_pointer], eax
    stdcall create_literal_node, 5
    mov edx, [array_pointer]
    mov dword [edx], eax
    stdcall create_literal_node, 10
    mov edx, [array_pointer]
    mov dword [edx + 4], eax
    stdcall create_literal_node, 15
    mov edx, [array_pointer]
    mov dword [edx + 8], eax
    stdcall create_call_node, [callee_node], [array_pointer], 3
    mov [root_node], eax
    jmp .procedure_cleanup
.error_allocation:
    cinvoke printf, string_error_memory
.procedure_cleanup:
    stdcall codegen_and_print, [root_node]
    ret
endp

; 5 + 10 * (var1 - 5)
proc main11
    cinvoke puts, '*** main11 ***'
    local node_five_left:DWORD
    local node_ten:DWORD
    local node_var1:DWORD
    local node_five_right:DWORD
    local node_subtraction:DWORD
    local node_multiplication:DWORD
    local root_node:DWORD
    mov [root_node], 0
    stdcall create_literal_node, 5
    test eax, eax
    jz .error_allocation
    mov [node_five_left], eax
    stdcall create_literal_node, 10
    mov [node_ten], eax
    stdcall create_identifier_node, string_var1
    mov [node_var1], eax
    stdcall create_literal_node, 5
    mov [node_five_right], eax
    stdcall create_binary_node, string_op_minus, [node_var1], [node_five_right]
    test eax, eax
    jz .error_allocation
    mov [node_subtraction], eax
    stdcall create_binary_node, string_op_multiply, [node_ten], [node_subtraction]
    test eax, eax
    jz .error_allocation
    mov [node_multiplication], eax
    stdcall create_binary_node, string_op_plus, [node_five_left], [node_multiplication]
    mov [root_node], eax
    jmp .procedure_cleanup
.error_allocation:
    cinvoke printf, string_error_memory
.procedure_cleanup:
    stdcall codegen_and_print, [root_node]
    ret
endp

include 'boilerplate/footer_data.inc'
include 'ast/ast.data.inc'
global_parser PARSER_STATE

string_format_integer               db "%d", 0

string_input_call                   db "print_numbers(5)", 0
string_input_math                   db "5 + 10 * (var1 - 5)", 0
string_input_math_two               db "5 + 10 * var1", 0

string_var1                         db "var1", 0
string_var2                         db "var2", 0
string_var5                         db "var5", 0
string_print_numbers                db "print_numbers", 0

string_op_plus                      db "+", 0
string_op_minus                     db "-", 0
string_op_multiply                  db "*", 0

string_paren_left                   db "(", 0
string_paren_right                  db ")", 0
string_comma_space                  db ", ", 0
string_space                        db " ", 0

string_error_memory                 db "Error: Memory allocation failed", 10, 0
string_error_parse                  db "Error: Parsing failed", 10, 0
string_error_transform              db "Error: Transformation failed", 10, 0

code_generation_buffer              rb MAX_BUFFER_SIZE

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        malloc,         'malloc',\
        realloc,        'realloc',\
        free,           'free',\
        sprintf,        'sprintf',\
        _itoa,          '_itoa',\
        strcat,         'strcat',\
        strcmp,         'strcmp',\
        _strdup,        '_strdup',\
        printf,         'printf',\
        puts,           'puts'
