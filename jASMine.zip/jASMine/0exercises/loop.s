include 'compiler/header.x86.inc'

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall insert_spaces, data1
    cinvoke puts, eax
    stdcall remove_spaces, data2
    cinvoke puts, eax
    ret
endp

proc main
    cinvoke puts, '*** main2 ***'
    stdcall remove_spaces, data2
    ret
endp

proc insert_spaces p_buf
    mov eax, data2
    ret
endp

proc remove_spaces uses ebx esi edi, p_buf
    mov esi, [p_buf]
    stdcall strlen, esi
    inc eax
    sub esp, eax
    mov edi, esp
    mov ebx, esp
.loop:
    movzx eax, byte [esi]
    cmp eax, 0
    je .exit
    cmp eax, ' '
    je .continue
    mov [edi], eax
    inc edi
.continue:
    inc esi
    jmp .loop
.exit:
    mov [edi], 0
    cinvoke puts, ebx
    ret
endp

include 'compiler/footer_data.inc'
data1:
db '8877665544332211', 10
db '7788556633441122', 10
db '5566778811223344', 10
db '1122334455667788', 0
data2:
db '88 77 66 55 44 33 22 11', 10
db '7788 5566 3344 1122', 10
db '55667788 11223344', 10
db '1122334455667788', 0

include 'compiler/footer_idata.inc'
