format PE
entry start

include 'win32a.inc'

section '.data' data readable writable
    template db '**** **** **** ****', 0
    fmt_s db '%s', 10, 0
    card db '1234567812345678', 0
    masked rb 20

section '.text' code readable executable
start:
    stdcall mask_card_number1, card
    cinvoke printf, fmt_s, masked
    invoke  ExitProcess, 0

proc mask_card_number1 uses ebx esi edi, card_number
    mov esi, template
    mov edi, masked
    mov ecx, 15
.loop:
    mov al, byte [esi]
    mov byte [edi], al
    inc esi
    inc edi
    dec ecx
    jnz .loop

    mov ebx, [card_number]
    mov al, byte [ebx + 12]
    mov byte [masked + 15], al
    mov al, byte [ebx + 13]
    mov [masked + 16], al
    mov al, byte [ebx + 14]
    mov [masked + 17], al
    mov al, byte [ebx + 15]
    mov [masked + 18], al
    ret
endp

proc mask_card_number2 uses ebx esi edi, card_number
    mov esi, template
    mov edi, masked
    mov ecx, 15
    rep movsb

    mov esi, [card_number]
    add esi, 12
    mov ecx, 4
    rep movsb
    ret
endp

section '.idata' import readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf'
