format PE
entry start

include 'win32ax.inc'

section '.data' data readable writeable
    fmt_xn      db '%x', 10, 0
    fmt_un      db '%u', 10, 0

section '.text' code readable executable
start:
    stdcall main
    invoke ExitProcess, 0

proc main1 uses ebx
    cinvoke puts, '*** main1 ***'
    mov ebx, 1024
    cinvoke printf, fmt_xn, ebx
    cinvoke printf, fmt_xn, 10000000000b
    cinvoke printf, fmt_xn, 0000_0000__0000_0000__0000_0100__0000_0000b
    shr ebx, 10
    cinvoke printf, fmt_xn, ebx
    ret
endp

proc main uses ebx
    cinvoke puts, '*** main1 ***'
    mov ebx, 1
    shl ebx, 20
    cinvoke printf, fmt_un, ebx
    cinvoke printf, fmt_un, 100000000000000000000b
    cinvoke printf, fmt_un, 0000_0000__0001_0000__0000_0000__0000_0000b
    ret
endp

section '.idata' import data readable
    library kernel32,       'kernel32.dll',\
            msvcrt,         'msvcrt.dll'
    import  kernel32,\
            ExitProcess,    'ExitProcess'
    import  msvcrt,\
            printf,         'printf',\
            puts,           'puts'
