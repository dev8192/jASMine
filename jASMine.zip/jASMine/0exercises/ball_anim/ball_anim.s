format PE console
entry start

include 'win32ax.inc'

DIAMETER = 50
TIMER_ID = 1
TIMER_INTERVAL = 16

section '.data' data readable writeable
    wc              WNDCLASS
    msg             MSG
    class_name      db 'AnimClass', 0
    window_name     db '1 Second Animation', 0

section '.text' code readable executable
start:
    invoke GetModuleHandle, 0
    mov [wc.hInstance], eax
    mov [wc.lpfnWndProc], window_proc
    invoke LoadCursor, 0, IDC_ARROW
    mov [wc.hCursor], eax
    mov [wc.hbrBackground], COLOR_WINDOW + 1
    mov [wc.lpszClassName], class_name
    invoke RegisterClass, wc

    invoke  CreateWindowEx, 0, class_name, window_name,\
            WS_VISIBLE+WS_OVERLAPPEDWINDOW,\
            CW_USEDEFAULT, CW_USEDEFAULT, 600, 400,\
            0, 0, [wc.hInstance], 0

msg_loop:
    invoke GetMessage, msg, 0, 0, 0
    test eax, eax
    jz end_loop
    invoke TranslateMessage, msg
    invoke DispatchMessage, msg
    jmp msg_loop

end_loop:
    invoke ExitProcess, [msg.wParam]

proc window_proc hwnd, uMsg, wParam, lParam
    cmp [uMsg], WM_PAINT
    je .wm_paint
    cmp [uMsg], WM_TIMER
    je .wm_timer
    cmp [uMsg], WM_CREATE
    je .wm_create
    cmp [uMsg], WM_DESTROY
    je .wm_destroy

.def_proc:
    invoke DefWindowProc, [hwnd], [uMsg], [wParam], [lParam]
    ret

.wm_create:
    invoke SetTimer, [hwnd], TIMER_ID, TIMER_INTERVAL, 0
    xor eax, eax
    ret

.wm_timer:
    invoke InvalidateRect, [hwnd], 0, TRUE
    xor eax, eax
    ret

.wm_paint:
    stdcall on_paint, [hwnd]
    xor eax, eax
    ret

.wm_destroy:
    invoke KillTimer, [hwnd], TIMER_ID
    invoke PostQuitMessage, 0
    xor eax, eax
    ret
endp

proc on_paint1 hwnd
    local ps:PAINTSTRUCT
    invoke BeginPaint, [hwnd], addr ps
    invoke Ellipse, [ps.hdc], 5, 5, 55, 55
    invoke EndPaint, [hwnd], addr ps
    xor eax, eax
    ret
endp

proc on_paint hwnd
    local ps:PAINTSTRUCT
    local rect:RECT
    invoke BeginPaint, [hwnd], addr ps
    invoke GetClientRect, [hwnd], addr rect
    invoke Ellipse, [ps.hdc], [rect.left], [rect.top], [rect.right], [rect.bottom]
    invoke EndPaint, [hwnd], addr ps
    xor eax, eax
    ret
endp

proc on_paint20 uses ebx, hwnd
    invoke BeginPaint, [hwnd], ps
    invoke GetClientRect, [hwnd], rect

    mov ebx, [rect.right]
    sub ebx, 50
    cmp ebx, 0
    jge .calc_time
    xor ebx, ebx

.calc_time:
    invoke GetTickCount
    xor edx, edx
    mov ecx, 2000
    div ecx

    cmp edx, 1000
    jl .moving_right
    mov eax, 2000
    sub eax, edx
    jmp .calc_pos
.moving_right:
    mov eax, edx

.calc_pos:
    imul eax, ebx
    xor edx, edx
    mov ecx, 1000
    div ecx
    push eax

    mov ecx, [rect.bottom]
    sub ecx, 50
    shr ecx, 1

    invoke GetStockObject, BLACK_BRUSH
    invoke SelectObject, [ps.hdc], eax

    pop eax
    mov ebx, eax
    add ebx, DIAMETER
    mov edx, ecx
    add edx, DIAMETER

    invoke Ellipse, [ps.hdc], eax, ecx, ebx, edx

    invoke EndPaint, [hwnd], ps
    ret
endp

section '.idata' import data readable
    library kernel32,           'kernel32.dll',\
            user32,             'user32.dll',\
            gdi32,              'gdi32.dll',\
            msvcrt,             'msvcrt.dll'
    import  kernel32,\
            GetModuleHandle,    'GetModuleHandleA',\
            GetTickCount,       'GetTickCount',\
            ExitProcess,        'ExitProcess'
    import  user32,\
            LoadCursor,         'LoadCursorA',\
            RegisterClass,      'RegisterClassA',\
            CreateWindowEx,     'CreateWindowExA',\
            GetMessage,         'GetMessageA',\
            TranslateMessage,   'TranslateMessage',\
            DispatchMessage,    'DispatchMessageA',\
            DefWindowProc,      'DefWindowProcA',\
            PostQuitMessage,    'PostQuitMessage',\
            SetTimer,           'SetTimer',\
            KillTimer,          'KillTimer',\
            BeginPaint,         'BeginPaint',\
            EndPaint,           'EndPaint',\
            GetClientRect,      'GetClientRect',\
            InvalidateRect,     'InvalidateRect'
    import  gdi32,\
            GetStockObject,     'GetStockObject',\
            SelectObject,       'SelectObject',\
            Ellipse,            'Ellipse'
    import  msvcrt,\
            printf,             'printf',\
            puts,               'puts'
