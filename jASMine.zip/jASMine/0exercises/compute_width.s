include 'boilerplate/header.x86.inc'
include '0exercises/compute_width.text.inc'
include 'util/test_util.inc'
create_test compute_width, 2

proc main1
    cinvoke puts, '*** main1 ***'
    stdcall create_number, 8, 8, 0xFFFF
    stdcall create_number, 1, 15, 0xFFFF
    stdcall create_number, 4, 4, 0xFF
    ret
endp

proc main
    cinvoke puts, '*** main3 ***'
    stdcall compute_width__test, 8, 8, 12   ; 255.99609375
    stdcall compute_width__test, 1, 1, 3    ; 1.5
    stdcall compute_width__test, 1, 4, 5    ; 1.9375
    stdcall compute_width__test, 4, 8, 11   ; 15.99609375
    stdcall compute_width__test, 8, 1, 5    ; 255.5
    ret
endp

include 'boilerplate/footer_data.inc'
include 'util/test_util.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        sprintf,        'sprintf',\
        printf,         'printf',\
        puts,           'puts'
