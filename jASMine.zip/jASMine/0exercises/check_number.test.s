format PE

include 'compiler_old.inc'
include 'win32ax.inc'

stdcall main
invoke ExitProcess, 0

include 'check_number.text.inc'

proc main
    cinvoke puts, '*** main1 ***'
    stdcall check_number, -123
    stdcall check_number, 0
    stdcall check_number, 123
    ret
endp

.data
include 'check_number.data.inc'

.idata
library kernel32,       'kernel32.dll',\
        msvcrt,         'msvcrt.dll'
import  kernel32,\
        ExitProcess,    'ExitProcess'
import  msvcrt,\
        printf,         'printf',\
        puts,           'puts'
